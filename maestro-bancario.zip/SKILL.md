---
name: maestro-bancario
description: Orquestra o fluxo de trabalho para casos de Direito Bancário e Cobrança, acionando as skills especialistas corretas desde a análise inicial até a entrega final do relatório consolidado, cobrindo operações de crédito, execução de títulos, prescrição intercorrente e recursos cíveis.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0.0"
  tags: ["direito-bancario", "cobranca", "execucao", "orquestrador", "workflow"]
---

# Skill: Maestro Bancário (Orquestrador)

## 1. Overview

O **Maestro Bancário** é uma skill orquestradora de alto nível projetada para atuar como o ponto central de comando para a análise e processamento de casos de Direito Bancário, Cobrança e Execução de Títulos. Ele recebe a descrição de uma demanda e coordena um fluxo de trabalho completo, acionando as skills especialistas apropriadas na ordem correta, desde a pesquisa inicial até a produção e revisão de documentos.

Seu objetivo é automatizar a gestão do fluxo de trabalho, garantir que as ferramentas certas sejam usadas para cada etapa e consolidar todos os outputs em um relatório final coeso e integrado, otimizando o tempo e a eficiência do advogado.

## 2. When to Use

Utilize esta skill como ponto de partida para qualquer nova demanda ou caso em Direito Bancário, especialmente quando o trabalho envolve múltiplas etapas, como:

- **Análise de Operações de Crédito:** Desde a análise contratual até a avaliação de risco e estratégia de cobrança.
- **Execução de Títulos de Crédito:** Cobrança de duplicatas, notas promissórias, cheques, com análise de prescrição e recursos.
- **Defesa em Execução:** Análise de vulnerabilidades processuais, embargos à execução, prescrição intercorrente.
- **Recursos Cíveis:** Desde a apelação até REsp/RE, com pesquisa jurisprudencial integrada.
- **Operações Predatórias Bancárias:** Identificação de práticas abusivas, juros ilegais, cláusulas nulas.

## 3. How to Use

O Maestro é invocado com a descrição do caso. Ele então gerencia o fluxo, interagindo com o usuário para obter informações e com outras skills para executar as tarefas.

### Etapa 1: Recepção e Classificação (Input & Triage)

1. **Recepção do Caso:** O usuário inicia a skill com um prompt descrevendo a demanda.
2. **Análise e Validação:** O Maestro analisa a descrição inicial e verifica se possui as informações mínimas para prosseguir:
   - `Tipo de demanda` (cobrança, execução, defesa, recurso, consultivo)
   - `Partes envolvidas`
   - `Títulos/Operações envolvidas`
   - `Tribunal` (se aplicável)
   - `Fase processual` (se aplicável)
3. **Interação com Usuário:** Se informações cruciais estiverem faltando, o Maestro utiliza a ferramenta `message` para solicitá-las antes de continuar.

### Etapa 2: Roteamento e Execução (Routing & Execution)

Com as informações completas, o Maestro seleciona e executa a sequência de skills apropriada:

| Tipo de Demanda | Fluxo de Skills Acionadas |
| :--- | :--- |
| **Cobrança Simples** | `analise-contratos-bancarios` → `analise-risco-bancaria` |
| **Execução de Título** | `prescricao-intercorrente-bancaria` → `analise-contratos-bancarios` → `analise-risco-bancaria` → `peticoes-cobranca-completo` |
| **Defesa em Execução** | `prescricao-intercorrente-bancaria` → `analise-operacoes-predatorias-bancaria` → `embargos-execucao-bancario` → `peticoes-cobranca-completo` |
| **Recurso Cível** | `jurisprudencia-bancaria-pesquisa` → `recursos-civeis-completo` → `analise-risco-bancaria` |
| **Operação Predatória** | `jurisprudencia-bancaria-pesquisa` → `analise-operacoes-predatorias-bancaria` → `analise-risco-bancaria` |

### Etapa 3: Consolidação e Entrega (Consolidation & Delivery)

1. **Agregação:** O Maestro coleta os outputs de todas as skills executadas.
2. **Relatório Final:** As informações são consolidadas em um único relatório integrado, estruturado em Markdown.
3. **Suporte:** Se aplicável, a skill `gestao-prazos-bancaria` é acionada para sugerir um calendário de atividades.
4. **Entrega:** O relatório final e todos os artefatos gerados são entregues ao usuário.

## 4. Dependências

Esta skill depende da existência e do correto funcionamento das seguintes skills especialistas:

- `analise-contratos-bancarios`
- `prescricao-intercorrente-bancaria`
- `analise-risco-bancaria`
- `jurisprudencia-bancaria-pesquisa`
- `recursos-civeis-completo`
- `analise-operacoes-predatorias-bancaria`
- `gestao-prazos-bancaria`
- `monitoramento-jurisprudencia-bancaria`

## 5. Output (Relatório Consolidado)

O output principal é um arquivo Markdown (`relatorio_caso_XXXX.md`) contendo:

- **Sumário do Caso:** Resumo da demanda e informações chave.
- **Fluxo Executado:** Lista das skills acionadas e o porquê.
- **Resultados da Pesquisa:** Seção com os principais precedentes encontrados.
- **Análise Técnica:** Compilação das análises das skills especialistas (riscos, cláusulas, prescrição, etc.).
- **Documentos Produzidos:** Links para as minutas de petições ou pareceres gerados.
- **Próximos Passos:** Sugestões de calendário e ações futuras.

## 6. Limitações

- A eficácia do Maestro depende diretamente da qualidade e precisão das informações fornecidas pelo usuário na etapa de recepção.
- A performance está atrelada à disponibilidade e ao correto funcionamento das skills especialistas que ele orquestra.
- O usuário deve revisar criticamente todos os outputs, especialmente as peças processuais, antes de qualquer uso prático.
