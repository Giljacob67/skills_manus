---
name: monitoramento-jurisprudencia-agraria
description: Monitora continuamente a jurisprudência agrária em tribunais selecionados, identifica precedentes relevantes, alerta sobre mudanças de entendimento e gera relatórios periódicos classificados por impacto.
license: MIT
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0.0"
  tags: ["direito-agrario", "jurisprudencia", "monitoramento", "contencioso"]
---

# Skill: Monitoramento de Jurisprudência Agrária

## 1. Overview

Esta skill realiza um monitoramento sistemático e contínuo da jurisprudência relacionada ao Direito Agrário nos principais tribunais do país (STJ, TJPR, TJSP, TJMG, TJMT, TJGO, TJBA). O objetivo é identificar, analisar e reportar decisões recentes, mudanças de entendimento e novos precedentes sobre temas críticos, fornecendo ao advogado uma ferramenta estratégica para antecipação de riscos e oportunidades.

A skill é projetada para ser executada de forma autônoma (agendada) ou sob demanda, culminando na produção de um relatório analítico.

## 2. When to Use

Utilize esta skill para:

- **Manter-se atualizado** sobre as últimas decisões em matéria agrária sem a necessidade de pesquisa manual extensiva.
- **Detectar mudanças de posicionamento** dos tribunais em teses jurídicas relevantes para a sua prática.
- **Identificar precedentes estratégicos** que possam ser aplicados em casos concretos (leading cases, obiter dicta relevantes).
- **Analisar divergências jurisprudenciais** entre diferentes tribunais, fundamentando recursos ou teses.
- **Produzir inteligência jurídica** para clientes, como parte de um serviço de consultoria preventiva.

## 3. How to Use

A skill opera em um fluxo de trabalho automatizado, que pode ser agendado ou invocado manualmente.

### Gatilhos (Triggers)

- **Agendado:** A skill pode ser configurada para rodar em intervalos definidos (e.g., semanalmente) através da ferramenta `schedule`.
- **Manual:** O usuário pode invocar a skill com um prompt direto, como `/monitoramento-jurisprudencia-agraria "Busque as últimas decisões sobre impenhorabilidade da pequena propriedade rural no STJ e TJPR nos últimos 30 dias."`

### Fluxo de Execução

**Etapa 1: Pesquisa (Search)**
- A skill utiliza a ferramenta `search` (tipos `news` e `research`) para consultar portais de tribunais, diários de justiça eletrônicos e bases de dados jurídicas (e.g., Jusbrasil, Migalhas).
- As queries são construídas a partir dos temas críticos definidos:
  - `impenhorabilidade pequena propriedade rural`
  - `arresto área rural limitação`
  - `CPR Cédula de Produto Rural jurisprudência`
  - `CDCA Certificado de Direitos Creditórios do Agronegócio`
  - `financiamento rural execução judicial`
  - `contrato arrendamento rural inadimplemento`
  - `parceria agrícola rescisão`
  - `operação mata-mata agronegócio`
  - `agiotagem rural mútuo juros`
- A pesquisa é refinada para os tribunais alvo: `site:stj.jus.br`, `site:tjpr.jus.br`, etc.

**Etapa 2: Análise e Classificação (Analysis & Classification)**
- Para cada resultado relevante, a skill utiliza o `browser` para acessar a URL e extrair o inteiro teor da decisão (acórdão, sentença) ou da notícia.
- O conteúdo é analisado para:
  - **Extrair a tese jurídica central:** Qual foi o entendimento firmado?
  - **Verificar aderência aos temas críticos:** A decisão se encaixa em um dos tópicos monitorados?
  - **Identificar o tribunal e a turma/câmara julgadora.**
  - **Avaliar o impacto:** A decisão tem potencial para alterar práticas, criar precedentes ou impactar um grande número de casos? A classificação é feita em três níveis:
    - **Alto:** Mudança de jurisprudência consolidada, decisão de órgão especial, repercussão geral, etc.
    - **Médio:** Reforça entendimento existente, mas com novos fundamentos; aplica tese a um caso atípico.
    - **Baixo:** Decisão de caso isolado, sem grande inovação ou impacto doutrinário.
  - **Sinalizar divergência:** O entendimento diverge de outro tribunal relevante? A skill registra a divergência para análise comparativa.

**Etapa 3: Geração do Relatório (Report Generation)**
- As informações coletadas e analisadas são consolidadas em um relatório estruturado em Markdown.
- O relatório segue o template definido em `assets/report_template.md`.
- O output final é um arquivo `.md` claro, conciso e acionável.

## 4. Output Exemplo (Estrutura do Relatório)

O resultado final é um arquivo Markdown com a seguinte estrutura:

```markdown
# Relatório de Monitoramento de Jurisprudência Agrária

**Período de Análise:** DD/MM/AAAA a DD/MM/AAAA

--- 

## Decisões de Alto Impacto

### 1. Impenhorabilidade da Pequena Propriedade Rural (STJ)

- **Processo:** REsp X.XXX.XXX/XX
- **Tese Firmada:** O STJ reafirmou que a impenhorabilidade da pequena propriedade rural, mesmo que oferecida como garantia hipotecária, é absoluta, exceto para financiamento da própria atividade produtiva.
- **Análise de Impacto:** Consolida a proteção ao pequeno produtor e limita o alcance de garantias em financiamentos não diretamente ligados à produção. Alerta para revisão de contratos de mútuo com garantia real.
- **Link:** [URL da decisão]

---

## Decisões de Médio Impacto

### 1. CPR - Nulidade por Vício de Forma (TJPR)

- **Processo:** Apelação Cível n.º XXXX-XX.XXXX.X.XX.XXXX
- **Tese Firmada:** O TJPR declarou a nulidade de uma Cédula de Produto Rural por ausência de registro no cartório de registro de imóveis competente, conforme exigência legal.
- **Análise de Impacto:** Reforça a necessidade de rigor formal na emissão de títulos do agronegócio. Risco para credores que não cumprem todos os requisitos de validade do título.
- **Link:** [URL da decisão]

---

## Divergências Notáveis

### 1. Arresto em Área Rural: Limites

- **Posição TJSP:** Permite o arresto de parte da produção para garantir a dívida, desde que não inviabilize a subsistência do produtor.
- **Posição TJMT:** Tende a ser mais restritivo, priorizando a continuidade da atividade produtiva e limitando o arresto a percentuais mínimos da safra.
- **Análise:** A divergência abre espaço para discussão em recursos especiais e exige estratégia processual adaptada a cada jurisdição.

```

## 5. Limitações

- A skill depende da disponibilidade e do formato das informações nos sites dos tribunais. Mudanças na estrutura dos portais podem exigir ajustes.
- A análise de "impacto" é uma avaliação técnica baseada em critérios predefinidos, mas a interpretação final e a aplicação ao caso concreto cabem sempre ao advogado.
- A skill não substitui a leitura aprofundada do inteiro teor das decisões mais estratégicas.
