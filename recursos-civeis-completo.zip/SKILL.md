---
name: recursos-civeis-completo
description: Guia técnico e aprofundado sobre recursos processuais cíveis em todos os graus de jurisdição, cobrindo apelação, agravo de instrumento, embargos de declaração, recurso especial, recurso extraordinário, agravo em REsp/RE, embargos de divergência, recurso ordinário constitucional e reclamação, com templates, checklists de admissibilidade e teses específicas do Direito Bancário. Use quando precisar elaborar ou analisar recursos em matéria de cobrança e execução.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Recursos Processuais Cíveis Completo

## INTRODUÇÃO

Esta skill oferece um guia técnico e aprofundado sobre os recursos processuais cíveis aplicáveis em todos os graus de jurisdição, com foco especial em matéria de cobrança, execução de títulos e operações bancárias. O conteúdo é direcionado a advogados com experiência e pressupõe domínio dos institutos fundamentais de direito processual civil.

## SUMÁRIO

**PARTE I - RECURSOS EM SEGUNDO GRAU (TJs e TRFs)**
1. Apelação (Art. 1.009, CPC)
2. Agravo de Instrumento (Art. 1.015, CPC)
3. Agravo Interno (Art. 1.021, CPC)
4. Embargos de Declaração (Art. 1.022, CPC)

**PARTE II - RECURSOS NOS TRIBUNAIS SUPERIORES**
5. Recurso Especial - REsp (Art. 105, III, CF)
6. Recurso Extraordinário - RE (Art. 102, III, CF)
7. Agravo em Recurso Especial/Extraordinário - AREsp/ARE (Art. 1.042, CPC)
8. Embargos de Divergência (Art. 1.043, CPC)
9. Recurso Ordinário Constitucional - ROC (Art. 105, II, CF)
10. Reclamação (Art. 988, CPC)

**PARTE III - MATERIAL DE APOIO**
11. Tabela de Prazos Recursais
12. Checklist Geral de Admissibilidade
13. Súmulas e Teses Relevantes (STJ/STF)
14. Temas Bancários Recorrentes em Recursos

---

## PARTE I - RECURSOS EM SEGUNDO GRAU

### 1. APELAÇÃO (ART. 1.009, CPC)

Recurso ordinário por excelência, manejado contra sentenças para reexame integral da matéria de fato e de direito.

#### 1.1. Cabimento e Hipóteses Legais
- **Regra Geral:** Impugnação de sentenças, sejam terminativas (sem resolução de mérito) ou definitivas (com resolução de mérito).
- **Questões Interlocutórias não Agraváveis:** As decisões interlocutórias que não se enquadram no rol do art. 1.015 do CPC devem ser arguidas em **preliminar de apelação** (art. 1.009, §1º).

#### 1.2. Requisitos Formais
- **Tempestividade:** Prazo de 15 dias úteis (arts. 219 e 1.003, §5º, CPC).
- **Preparo:** Recolhimento das custas recursais, sob pena de deserção (art. 1.007).
- **Regularidade Formal:** Petição dirigida ao juízo *a quo*, mas com razões endereçadas ao tribunal *ad quem*.

#### 1.3. Efeitos
- **Regra Geral:** Efeito devolutivo e suspensivo (*ope legis* - art. 1.012, *caput*).
- **Exceções ao Efeito Suspensivo (art. 1.012, §1º):** A sentença começa a produzir efeitos imediatamente após a publicação em determinadas hipóteses. A concessão de efeito suspensivo à apelação exige requerimento específico ao tribunal.
- **Efeito Translativo:** Permite ao tribunal analisar matérias de ordem pública não suscitadas pelas partes.

#### 1.4. Argumentação Específica (Direito Bancário)
- **Nulidade de Título de Crédito:** Teses de vício formal, desvio de finalidade, ausência de lastro. A apelação pode buscar a reforma de sentença que julgou improcedentes embargos à execução.
- **Juros Abusivos:** Fundamentação com base no Decreto 22.626/33, Resolução CMN 3.517/07, CDC.
- **Capitalização de Juros:** Vedação ao anatocismo (MP 2.170-36/01).
- **Prescrição Intercorrente:** Argumentação sobre inatividade processual conforme art. 921, CPC.

#### 1.5. Jurisprudência Relevante
- **STJ, Súmula 382:** "A capitalização de juros em operações bancárias é permitida, desde que expressamente pactuada."
- **STJ, Súmula 296:** "Os juros moratórios são devidos desde a citação válida."
- **STJ, Tema Repetitivo (Juros Bancários):** Taxa média de mercado como limite para juros em operações bancárias.

---

### 2. AGRAVO DE INSTRUMENTO (ART. 1.015, CPC)

Recurso destinado a impugnar decisões interlocutórias específicas cuja urgência não permite aguardar análise em preliminar de apelação.

#### 2.1. Cabimento e Hipóteses Legais
- **Rol de Taxatividade Mitigada (STJ, Tema 988):** O rol do art. 1.015 do CPC é taxativo, mas admite mitigação quando verificada a urgência.
- **Principais Hipóteses (Direito Bancário):**
  - **Tutelas Provisórias (inc. I):** Deferimento ou indeferimento de liminares em execuções, ações revisionais.
  - **Mérito Parcial do Processo (inc. II):** Decisões que julgam antecipadamente parte do pedido.
  - **Concessão, Modificação ou Revogação do Efeito Suspensivo aos Embargos à Execução (inc. X):** De altíssima relevância em execuções de títulos.

#### 2.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis.
- **Preparo:** Exigível, salvo exceções legais.
- **Formação do Instrumento:** O recurso é dirigido diretamente ao tribunal, instruído com as peças obrigatórias.

#### 2.3. Efeitos
- **Efeito Devolutivo:** Devolve ao tribunal o conhecimento da matéria impugnada.
- **Efeito Suspensivo (*Ope Judicis*):** Não é automático. Deve ser requerido ao relator.
- **Tutela Antecipada Recursal:** O relator pode antecipar a pretensão recursal.

---

## PARTE II - RECURSOS NOS TRIBUNAIS SUPERIORES

### 5. RECURSO ESPECIAL - REsp (ART. 105, III, CF)

Recurso para uniformização da interpretação da lei federal infraconstitucional.

#### 5.1. Cabimento
- **Alínea "a":** Violação de lei federal.
- **Alínea "c":** Divergência jurisprudencial (dissídio jurisprudencial).
- **Alínea "d":** Violação de tratado ou lei federal de organização.

#### 5.2. Requisitos Essenciais
- **Prequestionamento:** A matéria deve ter sido debatida no tribunal de origem (art. 1.040, CPC).
- **Tempestividade:** 15 dias úteis.
- **Fundamentação:** Demonstração clara da violação de lei federal.

#### 5.3. Teses Bancárias Relevantes
- **Juros Bancários:** Aplicação da Res. CMN 3.517/07 como limite de taxa média de mercado.
- **Capitalização de Juros:** Súmula 382/STJ e suas exceções.
- **Prescrição Intercorrente:** Aplicação do art. 921, CPC em execuções de títulos.
- **Nulidade de Títulos:** Requisitos formais de duplicata, nota promissória, cheque.

---

### 6. RECURSO EXTRAORDINÁRIO - RE (ART. 102, III, CF)

Recurso para questões constitucionais.

#### 6.1. Cabimento
- **Alínea "a":** Violação de dispositivo da Constituição Federal.
- **Alínea "b":** Declaração de inconstitucionalidade de lei ou ato normativo federal.
- **Alínea "c":** Julgamento válido de lei ou ato normativo municipal em face da CF.

#### 6.2. Requisitos Essenciais
- **Repercussão Geral:** Demonstração de que a questão constitucional tem repercussão geral (art. 1.035, CPC).
- **Prequestionamento:** A matéria deve ter sido debatida no tribunal de origem.
- **Tempestividade:** 15 dias úteis.

---

## PARTE III - MATERIAL DE APOIO

### 11. TABELA DE PRAZOS RECURSAIS (CPC/2015)

Todos os prazos são contados em **dias úteis**, conforme art. 219 do CPC.

| Recurso | Prazo Legal | Fundamento Legal |
| :--- | :--- | :--- |
| Apelação | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo de Instrumento | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo Interno | 15 dias | Art. 1.003, § 5º, CPC |
| Embargos de Declaração | 5 dias | Art. 1.023, CPC |
| Recurso Especial (REsp) | 15 dias | Art. 1.003, § 5º, CPC |
| Recurso Extraordinário (RE) | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo em REsp/RE (AREsp/ARE) | 15 dias | Art. 1.003, § 5º, CPC |

### 12. CHECKLIST GERAL DE ADMISSIBILIDADE RECURSAL

**1. Cabimento:**
- [ ] O recurso é o meio adequado para impugnar a decisão?

**2. Tempestividade:**
- [ ] O recurso foi interposto dentro do prazo legal?
- [ ] A contagem considerou apenas dias úteis?

**3. Preparo:**
- [ ] O recurso exige preparo? As guias foram preenchidas corretamente?

**4. Regularidade Formal:**
- [ ] A petição está endereçada corretamente?
- [ ] As partes estão devidamente qualificadas?
- [ ] O recurso expõe os fatos e o direito de forma clara?
- [ ] **Dialeticidade:** O recurso impugna especificamente os fundamentos da decisão recorrida?

**5. Legitimidade e Interesse:**
- [ ] O recorrente é parte no processo ou terceiro prejudicado?
- [ ] O recorrente sofreu sucumbência com a decisão?

---

### 14. TEMAS BANCÁRIOS RECORRENTES EM RECURSOS

#### 14.1. Juros Abusivos em Operações Bancárias

A Resolução CMN 3.517/07 estabelece que a taxa média de mercado é o parâmetro para avaliar se juros em operações bancárias são abusivos. A Súmula 382/STJ permite capitalização de juros, mas com ressalvas. O STJ tem entendido que juros significativamente acima da taxa média de mercado podem ser revisados judicialmente com base no CDC.

#### 14.2. Prescrição Intercorrente em Execução de Títulos

O art. 921, CPC estabelece que a execução extingue-se quando não há movimentação processual por mais de 1 ano (prescrição intercorrente). A jurisprudência do STJ tem consolidado que eventos como citação válida, protesto do título e reconhecimento de dívida interrompem a prescrição ordinária, mas não necessariamente a intercorrente.

#### 14.3. Nulidade de Títulos de Crédito

A duplicata deve conter requisitos formais específicos (Lei 5.474/68). A nota promissória segue a Lei Uniforme de Genebra. O cheque é regulado pela Lei 7.357/85. A ausência de requisitos essenciais pode ensejar a nulidade do título e, consequentemente, da execução.

#### 14.4. Capitalização de Juros

A Súmula 382/STJ permite capitalização em operações bancárias, desde que expressamente pactuada. Porém, há discussão sobre a aplicação em operações de crédito pessoa física e sobre a periodicidade de capitalização.

#### 14.5. Embargos à Execução

Os embargos à execução (art. 914, CPC) permitem arguir nulidade do título, excesso de execução (juros abusivos, capitalização indevida), prescrição intercorrente, entre outras matérias. O prazo é de 15 dias contados da juntada do mandado de citação.

---

## REFERÊNCIAS NORMATIVAS

| Diploma | Dispositivos Relevantes |
| :--- | :--- |
| Constituição Federal/88 | Arts. 102 (II, III), 105 (II, III) |
| CPC/2015 (Lei 13.105/15) | Arts. 203, 219, 224, 485, 487, 833 (VIII), 914-920, 921, 988, 989, 995, 997, 1.003, 1.007, 1.009 a 1.013, 1.015, 1.017, 1.019, 1.021 a 1.026, 1.030, 1.035, 1.040, 1.042, 1.043 |
| Decreto 22.626/33 | Lei da Usura — limitação de juros |
| Lei 5.474/68 | Duplicata |
| Lei 7.357/85 | Cheque |
| Lei Uniforme de Genebra | Nota Promissória |
| Lei 9.514/97 | Alienação Fiduciária |
| MP 2.170-36/01 | Capitalização de juros |
| Resolução CMN 3.517/07 | Taxa média de mercado para operações bancárias |

---

**FIM DA SKILL `recursos-civeis-completo` v1.0**
