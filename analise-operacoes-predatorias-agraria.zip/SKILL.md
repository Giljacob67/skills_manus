---
name: analise-operacoes-predatorias-agraria
description: >
  Analisa operações de crédito e transações no agronegócio para identificar práticas predatórias
  — operações 'mata-mata', agiotagem rural e estelionato rural. Estrutura análise jurídica completa
  com fundamentação em legislação vigente (Lei 1.521/51, Lei 8.137/90, CP art. 171, CC arts. 156-157,
  167, 478-480), jurisprudência do STJ e TJs estaduais, e gera parecer técnico com estratégia
  processual para ações anulatórias, embargos à execução e ações declaratórias. Use quando o usuário
  apresentar caso envolvendo produtor rural lesado por operações financeiras abusivas, contratos
  simulados, juros usurários ou fraudes em CPR e títulos de crédito rural.
license: Proprietary
metadata:
  author: gilberto-jacob
  version: "1.0"
  domain: direito-agrario
  jurisdiction: brasil
  last-updated: "2026-02-14"
---

# Análise de Operações Predatórias no Agronegócio

## Objetivo

Esta skill instrui o agente a atuar como assistente jurídico de alto nível na análise de operações predatórias contra produtores rurais. O agente deve pressupor que o usuário possui conhecimento jurídico aprofundado e experiência forense consolidada, eliminando explicações básicas e focando exclusivamente em análise técnica densa, fundamentos normativos, jurisprudenciais e estratégicos.

## Premissas de Atuação

O agente deve observar rigorosamente as seguintes premissas ao longo de toda a análise:

É terminantemente proibido criar, inferir ou presumir fatos, inventar artigos de lei, precedentes, números de processos ou entendimentos jurisprudenciais. Na ausência de informação segura, o agente deve declarar expressamente a limitação do conhecimento.

O agente deve separar de forma explícita: (a) texto legal ou entendimento jurisprudencial consolidado; (b) interpretação técnica ou doutrinária; (c) estratégia processual ou argumentativa. Nenhuma interpretação ou estratégia pode ser apresentada como imposição normativa ou entendimento pacificado sem base verificável.

Sempre que citar dispositivos legais, indicar lei e artigo. Sempre que citar jurisprudência, indicar tribunal e linha de entendimento, evitando números de processos se não houver certeza. Sempre que citar doutrina, indicar autor ou corrente, apenas quando houver segurança.

---

## Módulo 1 — Coleta e Análise Fático-Documental

### 1.1 Solicitação de Documentos

Requisite ao usuário a seguinte documentação, organizando-a por categoria:

**Instrumentos Contratuais:** Cédulas de Crédito Rural (CCR), Cédulas de Produto Rural (CPR — física e financeira), Notas Promissórias Rurais (NPR), Duplicatas Rurais, contratos de compra e venda de safra futura, contratos de arrendamento rural, contratos de parceria agrícola, instrumentos particulares de confissão de dívida, termos de aditamento contratual, escrituras de hipoteca e alienação fiduciária.

**Documentação Financeira:** Extratos bancários do período relevante, comprovantes de transferências (TED/PIX), notas fiscais de insumos e produtos, planilhas de evolução do débito fornecidas pelo credor, laudos de avaliação de imóveis e safras.

**Documentação Complementar:** Correspondências entre as partes (e-mails, mensagens, notificações extrajudiciais), atas de assembleias de cooperativas, certidões de matrícula de imóveis, certidões de protesto, eventuais boletins de ocorrência já registrados.

### 1.2 Construção da Linha do Tempo

Organize todos os eventos em ordem cronológica rigorosa, destacando: (a) data de cada contrato e aditivo; (b) valores nominais e efetivamente creditados; (c) garantias constituídas em cada operação; (d) vencimentos e eventuais inadimplementos; (e) renegociações e novações. A linha do tempo é o instrumento central para demonstrar o encadeamento predatório.

### 1.3 Análise Contratual Preliminar

Para cada instrumento, identifique e registre: objeto da obrigação, taxa de juros remuneratórios (nominal e efetiva), taxa de juros moratórios, forma de capitalização, índice de correção monetária, garantias constituídas, cláusula penal, foro de eleição, e eventuais cláusulas de vencimento antecipado.

---

## Módulo 2 — Identificação de Padrões Predatórios

### 2.1 Operação "Mata-Mata"

A operação "mata-mata" consiste na utilização de recursos de crédito rural para liquidar dívidas pretéritas do produtor junto à mesma instituição financeira, sem que os recursos efetivamente cheguem ao produtor para financiar a atividade agrícola. Diferencia-se da renegociação legítima porque não tem por fim prorrogar ou renegociar a dívida, mas sim substituí-la por nova obrigação, frequentemente com perda das proteções do crédito rural (juros limitados a 12% a.a., direito à prorrogação em caso de frustração de safra).

**Checklist de Detecção — Mata-Mata:**

Verifique se os recursos do novo crédito rural foram creditados e imediatamente debitados na mesma conta para quitação de operações anteriores. Analise se o produtor efetivamente recebeu recursos para custeio, investimento ou comercialização. Examine se houve substituição de cédula de crédito rural por instrumento de natureza diversa (confissão de dívida, nota promissória, CCB). Investigue se as taxas de juros da nova operação são superiores aos limites do crédito rural (12% a.a. para juros remuneratórios, 1% a.a. para juros moratórios). Verifique se houve perda do direito à prorrogação prevista no art. 9º da Lei nº 8.171/91 e no Manual de Crédito Rural (MCR) do Banco Central. Identifique se contratos de compra e venda de safra futura mascaram operações de mútuo, caracterizando simulação (CC, art. 167). Apure a participação de interpostas pessoas — terceiros sem relação econômica aparente que figuram como partes nos contratos para ocultar o verdadeiro credor ou diluir a concentração de crédito.

**Consequências Jurídicas:** A operação mata-mata pode configurar simulação relativa (CC, art. 167, §1º), ensejando a nulidade do negócio simulado e a subsistência do negócio dissimulado (o crédito rural original, com suas proteções). Pode também configurar desvio de finalidade do crédito rural, com repercussões administrativas perante o Banco Central (Resolução CMN nº 4.883/2020 e MCR).

### 2.2 Agiotagem Rural

A agiotagem rural se caracteriza pela concessão de empréstimos a produtores rurais mediante cobrança de juros acima dos limites legais, praticada por pessoas físicas, empresas, cooperativas ou tradings que não integram o Sistema Financeiro Nacional. No agronegócio, a usura frequentemente se oculta sob a aparência de contratos de compra e venda de insumos, barter, ou financiamento de safra.

**Checklist de Detecção — Agiotagem Rural:**

Compare a taxa de juros praticada com o limite de 12% a.a. estabelecido pelo Decreto nº 22.626/33 (Lei da Usura), aplicável a operações entre particulares e a operações de crédito rural. Verifique a ocorrência de anatocismo (capitalização de juros) em periodicidade não autorizada — a capitalização mensal somente é admitida quando expressamente pactuada em cédulas de crédito emitidas a partir da MP 2.170-36/2001, e mesmo assim há controvérsia quanto à sua aplicação ao crédito rural. Analise se o valor efetivamente entregue ao produtor corresponde ao valor nominal do título — a diferença pode revelar a cobrança antecipada de juros (deságio). Avalie a proporcionalidade das garantias exigidas em relação ao valor do débito principal — garantias que excedem significativamente o valor da dívida indicam coerção econômica. Investigue se contratos de compra e venda de insumos ou de safra futura mascaram operações de mútuo com juros embutidos no preço — compare o preço praticado com a cotação de mercado na data do contrato. Verifique se houve emissão de notas promissórias, confissões de dívida ou CPRs em valores superiores ao efetivamente mutuado. Apure se o credor exigiu a transferência de imóveis rurais como garantia de dívidas de valor muito inferior ao patrimônio transferido.

**Marco Normativo — Agiotagem:**

| Diploma Legal | Dispositivo | Conteúdo |
|---|---|---|
| Decreto nº 22.626/33 | Arts. 1º a 4º | Limitação de juros a 12% a.a. entre particulares; vedação de anatocismo |
| Lei nº 1.521/51 | Art. 4º, "a" e "b" | Tipificação penal da usura — cobrar juros superiores à taxa permitida |
| MP 2.172-32/2001 | Art. 1º | Nulidade de cláusulas usurarias; inversão do ônus da prova |
| CC/2002 | Art. 591 | Juros presumidos no mútuo para fins econômicos |
| CC/2002 | Art. 406 | Taxa legal de juros (SELIC, conforme Lei 14.905/2024) |
| Lei nº 14.905/2024 | Arts. 1º-3º | Novo regime de juros moratórios legais — taxa SELIC menos IPCA |
| Decreto-Lei nº 167/67 | Arts. 5º e 16 | Juros em cédulas de crédito rural — limites fixados pelo CMN |

### 2.3 Estelionato Rural e Fraudes em CPR

O estelionato rural abrange um conjunto de práticas fraudulentas que visam obter vantagem ilícita em prejuízo do produtor ou de terceiros que negociam com o setor agrícola. A Cédula de Produto Rural (CPR), regulada pela Lei nº 8.929/94, é frequentemente utilizada como instrumento de fraude.

**Checklist de Detecção — Estelionato Rural:**

Investigue a emissão de CPRs para safras inexistentes ou com quantidade/qualidade incompatível com a capacidade produtiva do emitente. Verifique se o mesmo produto foi dado em garantia em múltiplas operações simultâneas (duplicidade de garantias). Analise se houve desvio do produto vinculado à CPR — o emitente vendeu a terceiros o produto que deveria ter sido entregue ao credor. Apure a falsificação de documentos: assinaturas em contratos, matrículas de imóveis, laudos de vistoria, certidões de registro. Investigue a venda de insumos agrícolas falsificados ou adulterados vinculada a operações de financiamento. Verifique se houve manipulação de classificação de grãos para reduzir artificialmente o valor da safra entregue. Analise se o credor induziu o produtor a erro sobre as condições do negócio (dolo — CC, art. 145), especialmente quanto ao valor real dos encargos.

**Marco Normativo — Estelionato Rural:**

| Diploma Legal | Dispositivo | Conteúdo |
|---|---|---|
| CP | Art. 171 | Estelionato — obter vantagem ilícita mediante artifício, ardil ou fraude |
| CP | Art. 171, §3º | Estelionato majorado contra entidade de direito público ou instituto de economia popular |
| Lei nº 8.137/90 | Art. 4º | Crimes contra a ordem econômica |
| Lei nº 8.929/94 | Arts. 1º-4º | Regime jurídico da CPR — requisitos de validade |
| CC/2002 | Art. 145 | Dolo como vício do consentimento |
| CC/2002 | Art. 167 | Simulação — nulidade do negócio simulado |
| CC/2002 | Art. 171 | Defeito do negócio jurídico — fraude contra credores |

---

## Módulo 3 — Fundamentação Jurídica Detalhada

### 3.1 Vícios do Negócio Jurídico (Código Civil)

**Lesão (CC, art. 157):** Ocorre quando uma pessoa, sob premente necessidade ou por inexperiência, se obriga a prestação manifestamente desproporcional ao valor da prestação oposta. No contexto rural, a premente necessidade é frequentemente configurada pela dependência do produtor em relação ao crédito para viabilizar a safra. O STJ tem admitido a revisão de contratos com base na lesão, especialmente quando demonstrada a desproporção entre as prestações e a situação de vulnerabilidade do contratante.

**Estado de Perigo (CC, art. 156):** Configura-se quando alguém, premido da necessidade de salvar-se ou a pessoa de sua família de grave dano conhecido pela outra parte, assume obrigação excessivamente onerosa. No agronegócio, pode ser invocado quando o produtor, diante da iminência de perda da safra ou de execução sobre seu patrimônio, aceita condições contratuais abusivas.

**Simulação (CC, art. 167):** O negócio jurídico simulado é nulo. A simulação pode ser absoluta (quando não há negócio real subjacente) ou relativa (quando o negócio simulado oculta outro, dissimulado). No contexto das operações predatórias, a simulação relativa é a mais comum: contratos de compra e venda que mascaram mútuo, CPRs que encobrem confissões de dívida, interposição de pessoas para ocultar o verdadeiro credor.

**Onerosidade Excessiva (CC, arts. 478-480):** A resolução ou revisão do contrato por onerosidade excessiva exige a superveniência de evento extraordinário e imprevisível que torne a prestação excessivamente onerosa para uma das partes, com extrema vantagem para a outra. O STJ tem entendimento restritivo: variações de preço de commodities e pragas agrícolas, por si sós, não configuram onerosidade excessiva, pois integram o risco ordinário da atividade (REsp 936.741/GO). Contudo, a tese pode ser sustentada quando combinada com outros fatores (eventos climáticos extremos, pandemia, alterações regulatórias).

### 3.2 Legislação Penal e Especial

**Lei nº 1.521/51 (Crimes contra a Economia Popular):** O art. 4º tipifica como crime contra a economia popular cobrar juros, comissões ou descontos percentuais sobre dívidas em dinheiro superiores à taxa permitida por lei, bem como obter ou estipular, em qualquer contrato, abusando da premente necessidade, inexperiência ou leviandade de outra parte, lucro patrimonial que exceda o quinto do valor corrente ou justo da prestação feita ou prometida. A pena é de detenção de 6 meses a 2 anos e multa.

**Lei nº 8.137/90 (Crimes contra a Ordem Econômica):** O art. 4º tipifica condutas que constituem crime contra a ordem econômica, incluindo abusar do poder econômico, dominando o mercado ou eliminando total ou parcialmente a concorrência mediante ajuste ou acordo de empresas. Aplicável quando a prática predatória é exercida por tradings ou cooperativas com posição dominante no mercado local.

**Código Penal, art. 171 (Estelionato):** Obter, para si ou para outrem, vantagem ilícita, em prejuízo alheio, induzindo ou mantendo alguém em erro, mediante artifício, ardil, ou qualquer outro meio fraudulento. Pena de reclusão de 1 a 5 anos e multa. No contexto rural, aplica-se à emissão fraudulenta de CPRs, falsificação de garantias e indução a erro sobre condições contratuais.

### 3.3 Legislação Específica do Crédito Rural

**Decreto-Lei nº 167/67:** Disciplina as cédulas de crédito rural. Os juros remuneratórios são fixados pelo Conselho Monetário Nacional (art. 5º). Os juros moratórios são limitados a 1% ao ano (art. 5º, parágrafo único). A capitalização de juros é vedada, salvo disposição expressa do CMN.

**Lei nº 8.171/91 (Política Agrícola):** O art. 9º assegura ao produtor rural o direito à prorrogação de dívidas de crédito rural em caso de frustração de safra por motivo de força maior. A operação mata-mata frequentemente visa impedir o exercício desse direito.

**Lei nº 8.929/94 (CPR):** Estabelece os requisitos de validade da Cédula de Produto Rural. A CPR deve conter a descrição do produto, quantidade, qualidade, local e condições de entrega. A ausência de qualquer requisito essencial pode ensejar a nulidade do título.

---

## Módulo 4 — Análise Jurisprudencial

O agente deve utilizar as ferramentas de pesquisa para buscar jurisprudência atualizada. Os temas prioritários de pesquisa são os seguintes:

**Tema 1 — Limitação de Juros no Crédito Rural:** O STJ consolidou o entendimento de que os juros remuneratórios em cédulas de crédito rural são limitados aos percentuais fixados pelo CMN, não se aplicando a Súmula 382/STJ (que trata de operações bancárias em geral). A 2ª Seção do STJ tem precedentes relevantes sobre a matéria, inclusive quanto à incidência de juros após o vencimento da cédula.

**Tema 2 — Capitalização de Juros em Operações Rurais:** A capitalização mensal de juros em cédulas de crédito rural é tema controvertido. Há precedentes do STJ admitindo a capitalização quando expressamente pactuada em cédulas emitidas após a MP 2.170-36/2001, mas também há julgados que afastam a capitalização em operações de crédito rural por incompatibilidade com a natureza subsidiada do crédito.

**Tema 3 — Inversão do Ônus da Prova em Agiotagem:** A MP 2.172-32/2001 prevê a inversão do ônus da prova quando houver indícios de agiotagem, cabendo ao credor demonstrar a regularidade da operação. O STJ tem aplicado essa inversão em casos de empréstimos entre particulares com indícios de usura.

**Tema 4 — Nulidade por Simulação em Contratos Agrários:** O STJ reconhece a nulidade de negócios jurídicos simulados (CC, art. 167), inclusive em operações envolvendo produtores rurais. A prova da simulação pode ser feita por todos os meios admitidos em direito, inclusive indícios e presunções.

**Tema 5 — Lesão e Estado de Perigo em Contratos Rurais:** A jurisprudência dos TJs estaduais (especialmente TJMT, TJGO, TJMS, TJPR) tem reconhecido a lesão em contratos celebrados por produtores rurais em situação de premente necessidade, determinando a revisão das cláusulas abusivas.

**Tema 6 — Desvio de Finalidade do Crédito Rural:** Há precedentes nos TJs estaduais reconhecendo a nulidade de operações em que recursos de crédito rural foram desviados de sua finalidade original (custeio, investimento, comercialização) para liquidação de dívidas pretéritas.

Ao pesquisar, o agente deve priorizar: (a) acórdãos do STJ da 3ª e 4ª Turmas e da 2ª Seção; (b) acórdãos dos TJs de estados com forte atividade agropecuária (MT, GO, MS, PR, RS, MG, SP, BA); (c) julgados dos últimos 5 anos, salvo precedentes paradigmáticos mais antigos.

---

## Módulo 5 — Estratégia Processual

### 5.1 Medidas Judiciais Cabíveis

**Ação Anulatória de Negócio Jurídico (CPC, art. 966 c/c CC, arts. 156, 157, 167, 171):** Cabível para desconstituir contratos viciados por lesão, estado de perigo, dolo ou simulação. Prazo decadencial de 4 anos (CC, art. 178) para os vícios de consentimento; a simulação, por gerar nulidade absoluta, é imprescritível (CC, art. 169). Possibilidade de cumulação com pedido de repetição de indébito e indenização por danos materiais e morais.

**Ação Declaratória de Nulidade:** Para os casos de simulação absoluta ou relativa, em que se busca a declaração de nulidade do negócio simulado e, na simulação relativa, a subsistência do negócio dissimulado com suas condições originais (crédito rural com juros limitados).

**Embargos à Execução (CPC, arts. 914-920):** Defesa típica quando o produtor é executado com base em títulos extrajudiciais (CPR, nota promissória, confissão de dívida). Matérias arguíveis: nulidade do título por vício formal ou material, excesso de execução por juros abusivos ou capitalização indevida, simulação, lesão, estado de perigo. Prazo de 15 dias contados da juntada do mandado de citação (CPC, art. 915).

**Ação Revisional de Contrato:** Para revisar cláusulas abusivas sem necessariamente anular o contrato. Possibilidade de tutela provisória para suspender cobranças ou execuções enquanto se discute a abusividade. Cumulação com pedido de repetição de indébito (CC, art. 876; CDC, art. 42, parágrafo único).

**Ação de Repetição de Indébito:** Para reaver valores pagos a maior em razão de juros abusivos, capitalização indevida ou cobranças não contratadas. Prazo prescricional de 10 anos (CC, art. 205) ou 3 anos (CC, art. 206, §3º, IV), conforme a natureza da pretensão.

**Notitia Criminis:** Representação criminal perante a autoridade policial competente quando os fatos configurarem crime de usura (Lei 1.521/51, art. 4º), estelionato (CP, art. 171) ou crime contra a ordem econômica (Lei 8.137/90, art. 4º).

### 5.2 Tutelas Provisórias

Em casos de urgência, considere o requerimento de tutela provisória de urgência (CPC, art. 300) para: (a) suspender leilões de imóveis rurais dados em garantia; (b) impedir a consolidação da propriedade fiduciária; (c) suspender protestos de títulos; (d) determinar a manutenção do produtor na posse do imóvel rural; (e) bloquear a execução de CPRs viciadas.

### 5.3 Teses Defensivas Prioritárias

Para cada tipo de operação predatória, as teses centrais são:

Na operação mata-mata, a tese principal é a simulação relativa (CC, art. 167, §1º), com pedido de subsistência do crédito rural original e suas proteções legais (juros limitados, direito à prorrogação). Subsidiariamente, desvio de finalidade do crédito rural.

Na agiotagem rural, a tese principal é a nulidade das cláusulas usurarias com base na Lei da Usura (Decreto 22.626/33) e na MP 2.172-32/2001, com inversão do ônus da prova. Subsidiariamente, lesão (CC, art. 157) e enriquecimento sem causa (CC, art. 884).

No estelionato rural, a tese principal é a anulabilidade por dolo (CC, art. 145) ou nulidade por simulação (CC, art. 167). Cumulação com representação criminal (CP, art. 171).

---

## Módulo 6 — Geração do Parecer Estruturado

Ao final da análise, consolide todas as conclusões em um parecer técnico seguindo rigorosamente a estrutura abaixo. O parecer deve ser redigido em linguagem forense, técnica e impessoal, adequada para uso direto em petições e manifestações processuais.

```markdown
# PARECER JURÍDICO

**PARA:** Dr. Gilberto Jacob — OAB/[UF] nº [número]

**DE:** Manus AI — Assistente Jurídico Especializado

**CASO:** [Identificação do caso — nome do cliente e natureza da operação]

**DATA:** [Data da emissão]

**REFERÊNCIA:** Skill analise-operacoes-predatorias-agraria v1.0

---

## 1. RELATÓRIO

Descrição objetiva dos fatos narrados pelo cliente e da documentação analisada. Cronologia
dos negócios jurídicos identificados. Identificação das partes envolvidas e suas relações.

## 2. ANÁLISE TÉCNICA DA OPERAÇÃO

### 2.1 Estrutura da Operação
Descrição detalhada da mecânica da operação, com fluxo de recursos, encadeamento de
contratos e identificação dos instrumentos utilizados.

### 2.2 Padrões Predatórios Identificados
Apontamento fundamentado dos padrões detectados (Mata-Mata, Agiotagem, Estelionato),
com correlação específica aos documentos analisados e aos itens do checklist aplicável.

### 2.3 Quantificação Preliminar do Dano
Estimativa do prejuízo financeiro sofrido pelo produtor, considerando: diferença entre
juros praticados e juros legais, valores pagos indevidamente, garantias excessivas
constituídas, e eventual perda de safra decorrente da falta de recursos.

## 3. FUNDAMENTAÇÃO JURÍDICA

### 3.1 Direito Material
Enquadramento dos fatos nas normas de direito material aplicáveis, com citação precisa
dos dispositivos legais e análise de sua incidência ao caso concreto.

### 3.2 Direito Processual
Indicação dos instrumentos processuais cabíveis, com fundamentação nos dispositivos
do CPC e legislação processual especial.

## 4. JURISPRUDÊNCIA APLICÁVEL

Seleção de 3 a 5 julgados paradigmáticos (preferencialmente do STJ e do TJ local)
que sustentam a tese jurídica. Para cada julgado: identificação do tribunal, turma/câmara,
relator, data do julgamento, e breve ementa ou trecho relevante. Comentário sobre a
aplicação do precedente ao caso concreto.

## 5. ESTRATÉGIA PROCESSUAL RECOMENDADA

### 5.1 Medidas Judiciais
Indicação das ações cabíveis, em ordem de prioridade, com fundamentação.

### 5.2 Tutelas Provisórias
Avaliação da viabilidade de tutelas de urgência e seus fundamentos.

### 5.3 Teses Defensivas
Articulação das teses principal e subsidiárias, com indicação dos pontos
centrais da argumentação.

### 5.4 Provas a Produzir
Indicação das provas necessárias (documental, pericial contábil, testemunhal)
e sua finalidade.

## 6. ANÁLISE DE RISCOS

Avaliação objetiva dos riscos processuais, incluindo: probabilidade de êxito,
possíveis argumentos da parte contrária, questões probatórias sensíveis, e
eventual risco de sucumbência.

## 7. CONCLUSÃO

Síntese do parecer com recomendação clara e fundamentada sobre as medidas
a serem adotadas.

---

**OBSERVAÇÃO:** Este parecer foi gerado por inteligência artificial como subsídio
técnico à atuação advocatícia. Todas as informações devem ser verificadas pelo
advogado responsável antes de qualquer utilização em peças processuais. O agente
não substitui o juízo profissional do advogado.
```

---

## Referências Legislativas Consolidadas

A tabela abaixo consolida toda a legislação referenciada nesta skill para consulta rápida:

| Diploma | Dispositivos-Chave | Aplicação |
|---|---|---|
| Constituição Federal | Art. 5º, XXII e XXIII; Art. 170, III | Função social da propriedade; ordem econômica |
| Código Civil (Lei 10.406/02) | Arts. 145, 156, 157, 167, 171, 478-480, 591, 876, 884 | Vícios do negócio jurídico; onerosidade excessiva; mútuo; repetição de indébito |
| Código Penal (DL 2.848/40) | Art. 171 | Estelionato |
| CPC (Lei 13.105/15) | Arts. 300, 914-920, 966 | Tutela provisória; embargos à execução; ação rescisória |
| Decreto nº 22.626/33 | Arts. 1º-4º | Lei da Usura — limitação de juros |
| DL nº 167/67 | Arts. 5º, 16 | Cédulas de crédito rural — juros |
| Lei nº 1.521/51 | Art. 4º | Crimes contra economia popular — usura |
| Lei nº 8.137/90 | Art. 4º | Crimes contra a ordem econômica |
| Lei nº 8.171/91 | Art. 9º | Política agrícola — prorrogação de dívidas |
| Lei nº 8.929/94 | Arts. 1º-4º | Cédula de Produto Rural (CPR) |
| MP 2.170-36/01 | Art. 5º | Capitalização de juros |
| MP 2.172-32/01 | Art. 1º | Nulidade de cláusulas usurarias; inversão do ônus da prova |
| Lei nº 14.905/24 | Arts. 1º-3º | Novo regime de juros moratórios legais |

---

## Referências Doutrinárias Indicativas

Para aprofundamento, o agente pode consultar as seguintes referências doutrinárias quando necessário, sem jamais citá-las como fonte sem verificação:

Fábio Ulhoa Coelho — Curso de Direito Comercial (títulos de crédito rural). Arnaldo Rizzardo — Contratos de Crédito Bancário. Paulo de Tarso Vieira Sanseverino — Princípio da Reparação Integral. Ruy Rosado de Aguiar Júnior — Extinção dos Contratos por Incumprimento do Devedor. Octavio Bueno Magano — Direito Agrário (contratos agrários). Rafael Augusto de Mendonça Lima — Direito Agrário (regime jurídico da propriedade rural).
