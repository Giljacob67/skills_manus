# Endpoints DATAJUD — Referência Completa

## Autenticação

Todas as requisições devem incluir:

```
Authorization: APIKey cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==
Content-Type: application/json
```

A chave pública é atualizada periodicamente pelo CNJ. Se retornar erro 401/403, verificar a chave vigente em `https://datajud-wiki.cnj.jus.br/api-publica/acesso/`.

## Endpoints por Tribunal

| Tribunal | Alias | Endpoint |
|:---------|:------|:---------|
| STJ | `api_publica_stj` | `https://api-publica.datajud.cnj.jus.br/api_publica_stj/_search` |
| STF | `api_publica_stf` | `https://api-publica.datajud.cnj.jus.br/api_publica_stf/_search` |
| TJPR | `api_publica_tjpr` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjpr/_search` |
| TJSP | `api_publica_tjsp` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjsp/_search` |
| TJMG | `api_publica_tjmg` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjmg/_search` |
| TJBA | `api_publica_tjba` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjba/_search` |
| TJMT | `api_publica_tjmt` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjmt/_search` |
| TJGO | `api_publica_tjgo` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjgo/_search` |

## Campos Disponíveis

| Campo | Tipo | Uso na Pesquisa Agrária |
|:------|:-----|:------------------------|
| `numeroProcesso` | text/keyword | Busca direta por número CNJ |
| `classe.nome` | text/keyword | Filtrar por classe (Recurso Especial, Apelação, Agravo) |
| `classe.codigo` | long | Filtrar por código TPU da classe |
| `assuntos.nome` | text/keyword | Filtrar por assunto TPU (campo principal para temas agrários) |
| `assuntos.codigo` | long | Filtrar por código TPU do assunto |
| `orgaoJulgador.nome` | text/keyword | Filtrar por vara/câmara |
| `dataAjuizamento` | datetime | Filtrar por período |
| `movimentos.nome` | text/keyword | Identificar fase processual |
| `tribunal` | text/keyword | Identificar tribunal de origem |
| `grau` | text/keyword | Filtrar por instância (G1, G2, JE) |

## Priorização de Consulta

1. **STJ** — Fonte primária. Buscar sempre.
2. **TJPR, TJMT, TJGO, TJBA** — TJs com maior volume de litígios agrários. Buscar em paralelo.
3. **TJSP, TJMG** — TJs de grande porte. Buscar se necessário.
4. **STF** — Buscar apenas se envolver questão constitucional.

## Limitações

- Retorna apenas metadados processuais (classe, assunto, movimentos). Não contém ementas nem inteiro teor.
- Limite de 10.000 registros por consulta. Para resultados acima, usar paginação via `search_after`.
- A chave de API é pública e pode ser alterada pelo CNJ a qualquer momento.
