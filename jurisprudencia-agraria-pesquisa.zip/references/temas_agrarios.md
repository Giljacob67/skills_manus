# Temas Agrários Prioritários — Termos de Busca

## 1. Impenhorabilidade da Pequena Propriedade Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `impenhorabilidade pequena propriedade rural`, `art. 5 XXVI CF propriedade rural` |
| Termos secundários | `módulo fiscal impenhorabilidade`, `bem de família rural`, `penhora propriedade rural familiar` |
| Assuntos TPU | `Impenhorabilidade`, `Penhora`, `Propriedade Rural` |
| Dispositivos-chave | CF art. 5º, XXVI; Lei 8.009/90; STF Tema 961 |

## 2. CPR — Cédula de Produto Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `cédula de produto rural nulidade`, `CPR execução` |
| Termos secundários | `CPR vício formal`, `CPR lastro`, `CPR financeira registro`, `CPR agiotagem` |
| Assuntos TPU | `Cédula de Produto Rural`, `Títulos de Crédito` |
| Dispositivos-chave | Lei 8.929/94, arts. 1º-4º |

## 3. CDCA — Certificado de Direitos Creditórios do Agronegócio

| Campo | Termos |
|:------|:-------|
| Termos primários | `CDCA agronegócio`, `certificado direitos creditórios agronegócio` |
| Termos secundários | `título agronegócio execução`, `lastro CDCA` |
| Assuntos TPU | `Títulos do Agronegócio` |
| Dispositivos-chave | Lei 11.076/04 |

## 4. Financiamento Rural — Juros e Limitações

| Campo | Termos |
|:------|:-------|
| Termos primários | `crédito rural juros limitação`, `financiamento rural execução` |
| Termos secundários | `cédula crédito rural juros CMN`, `juros moratórios crédito rural`, `capitalização juros rural` |
| Assuntos TPU | `Crédito Rural`, `Juros`, `Cédula de Crédito Rural` |
| Dispositivos-chave | DL 167/67, arts. 5º e 16; Súmula 298/STJ |

## 5. Arrendamento Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `arrendamento rural inadimplemento`, `contrato arrendamento rural rescisão` |
| Termos secundários | `arrendamento rural preferência`, `arrendamento rural benfeitorias`, `arrendamento rural renovação` |
| Assuntos TPU | `Arrendamento Rural`, `Contratos Agrários` |
| Dispositivos-chave | Lei 4.504/64, arts. 92, 95; Dec. 59.566/66 |

## 6. Parceria Agrícola

| Campo | Termos |
|:------|:-------|
| Termos primários | `parceria agrícola rescisão`, `contrato parceria rural` |
| Termos secundários | `parceria agrícola partilha`, `parceria rural inadimplemento` |
| Assuntos TPU | `Parceria Agrícola`, `Contratos Agrários` |
| Dispositivos-chave | Lei 4.504/64, art. 96; Dec. 59.566/66 |

## 7. Operação Mata-Mata

| Campo | Termos |
|:------|:-------|
| Termos primários | `operação mata-mata agronegócio`, `desvio finalidade crédito rural` |
| Termos secundários | `renovação crédito rural incorporação encargos`, `anatocismo crédito rural` |
| Assuntos TPU | `Crédito Rural`, `Nulidade` |
| Dispositivos-chave | Lei 8.171/91, art. 9º; CC art. 167 |

## 8. Agiotagem Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `agiotagem rural mútuo juros`, `usura rural` |
| Termos secundários | `juros abusivos produtor rural`, `mútuo entre particulares juros`, `Lei da Usura rural` |
| Assuntos TPU | `Usura`, `Mútuo`, `Juros` |
| Dispositivos-chave | Decreto 22.626/33; Lei 1.521/51, art. 4º; MP 2.172-32/01 |

## 9. Usucapião Rural (Pro Labore)

| Campo | Termos |
|:------|:-------|
| Termos primários | `usucapião rural pro labore`, `usucapião especial rural` |
| Termos secundários | `usucapião constitucional rural 50 hectares`, `posse produtiva rural` |
| Assuntos TPU | `Usucapião`, `Usucapião Especial Rural` |
| Dispositivos-chave | CF art. 191; CC art. 1.239 |

## 10. Desapropriação para Reforma Agrária

| Campo | Termos |
|:------|:-------|
| Termos primários | `desapropriação reforma agrária função social`, `desapropriação imóvel rural` |
| Termos secundários | `indenização desapropriação TDA`, `produtividade imóvel rural desapropriação` |
| Assuntos TPU | `Desapropriação`, `Reforma Agrária` |
| Dispositivos-chave | CF arts. 184-186; Lei 8.629/93 |

## 11. Loteamentos Rurais

| Campo | Termos |
|:------|:-------|
| Termos primários | `loteamento rural parcelamento solo`, `loteamento rural viabilidade` |
| Termos secundários | `módulo rural parcelamento`, `loteamento chácaras rural`, `Lei 6.766 rural` |
| Assuntos TPU | `Parcelamento do Solo`, `Loteamento` |
| Dispositivos-chave | Lei 6.766/79; Lei 4.504/64; Lei 5.709/71 |

## 12. Alienação Fiduciária de Imóvel Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `alienação fiduciária imóvel rural`, `consolidação propriedade rural` |
| Termos secundários | `execução extrajudicial imóvel rural`, `leilão imóvel rural fiduciária` |
| Assuntos TPU | `Alienação Fiduciária`, `Propriedade Rural` |
| Dispositivos-chave | Lei 9.514/97 |

## 13. Penhor Rural

| Campo | Termos |
|:------|:-------|
| Termos primários | `penhor rural agrícola pecuário`, `penhor safra` |
| Termos secundários | `garantia real rural`, `penhor cédula rural` |
| Assuntos TPU | `Penhor Rural`, `Garantias Reais` |
| Dispositivos-chave | CC arts. 1.438-1.446; DL 167/67 |
