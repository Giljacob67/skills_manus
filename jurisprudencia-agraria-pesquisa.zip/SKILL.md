---
name: jurisprudencia-agraria-pesquisa
description: >
  Pesquisa avançada de jurisprudência em Direito Agrário brasileiro, integrando
  API DATAJUD (Elasticsearch) com web scraping de JusBrasil e sites de tribunais.
  Cobre STF, STJ e TJs estaduais (TJPR, TJSP, TJMG, TJBA, TJMT, TJGO).
  Prioriza automaticamente STJ → TJs especializados → JusBrasil.
  Produz síntese crítica dos precedentes, mapeamento de tendências
  (consolidado vs. divergente vs. superado) e conclusão estratégica.
  Usar quando o usuário solicitar pesquisa de jurisprudência, precedentes,
  entendimentos de tribunais, ou análise jurisprudencial sobre temas agrários,
  incluindo: impenhorabilidade de pequena propriedade rural, limitação de arresto
  em área rural, CPR, CDCA, financiamento rural, arrendamento, parceria agrícola,
  operações mata-mata, agiotagem rural, loteamentos rurais, usucapião rural,
  desapropriação para reforma agrária, contratos agrários, penhor rural,
  alienação fiduciária de imóvel rural, e temas conexos de Direito do Agronegócio.
license: Proprietary
metadata:
  author: Gilberto Jacob / Manus AI
  version: "1.0"
  domain: direito-agrario
  country: BR
---

# Pesquisa de Jurisprudência Agrária

Skill de pesquisa jurisprudencial multifonte, otimizada para Direito Agrário brasileiro. Integra consulta estruturada via API DATAJUD com web scraping inteligente, produzindo análise crítica e mapeamento de tendências.

## 1. Análise da Solicitação

Antes de iniciar qualquer busca, extrair da mensagem do usuário:

- **Tema jurídico central** — Identificar o instituto agrário (ex: "impenhorabilidade da pequena propriedade rural", "nulidade de CPR por vício de consentimento").
- **Termos de busca primários** — Palavras-chave e expressões jurídicas exatas para uso nas queries.
- **Termos de busca secundários** — Sinônimos, variações e termos correlatos que ampliem a cobertura.
- **Filtros** — Tribunais específicos, período temporal, turma/câmara, relator.
- **Objetivo** — Verificar se o usuário quer um panorama geral, confirmação de tese específica, ou mapeamento de divergência.

Consultar `references/temas_agrarios.md` para identificar o enquadramento temático e os termos de busca recomendados para o tema.

## 2. Pesquisa via API DATAJUD

A API DATAJUD é baseada em Elasticsearch e fornece metadados processuais (não inteiro teor). Usar como fonte primária para identificar processos relevantes e obter números para busca posterior do inteiro teor.

### 2.1 Endpoints por Tribunal

| Tribunal | Alias | Endpoint Completo |
|:---------|:------|:------------------|
| STJ | `api_publica_stj` | `https://api-publica.datajud.cnj.jus.br/api_publica_stj/_search` |
| STF | `api_publica_stf` | `https://api-publica.datajud.cnj.jus.br/api_publica_stf/_search` |
| TJPR | `api_publica_tjpr` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjpr/_search` |
| TJSP | `api_publica_tjsp` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjsp/_search` |
| TJMG | `api_publica_tjmg` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjmg/_search` |
| TJBA | `api_publica_tjba` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjba/_search` |
| TJMT | `api_publica_tjmt` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjmt/_search` |
| TJGO | `api_publica_tjgo` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjgo/_search` |

### 2.2 Autenticação e Headers

Todas as requisições devem incluir:

```
Authorization: APIKey cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==
Content-Type: application/json
```

**Nota:** A chave pública é atualizada periodicamente pelo CNJ. Se a requisição retornar erro 401/403, verificar a chave vigente em `https://datajud-wiki.cnj.jus.br/api-publica/acesso/`.

### 2.3 Campos Disponíveis para Busca

| Campo | Tipo | Uso na Pesquisa Agrária |
|:------|:-----|:------------------------|
| `numeroProcesso` | text/keyword | Busca direta por número CNJ |
| `classe.nome` | text/keyword | Filtrar por classe (Recurso Especial, Apelação, Agravo) |
| `classe.codigo` | long | Filtrar por código TPU da classe |
| `assuntos.nome` | text/keyword | Filtrar por assunto TPU (campo principal para temas agrários) |
| `assuntos.codigo` | long | Filtrar por código TPU do assunto |
| `orgaoJulgador.nome` | text/keyword | Filtrar por vara/câmara |
| `dataAjuizamento` | datetime | Filtrar por período |
| `movimentos.nome` | text/keyword | Identificar fase processual |
| `tribunal` | text/keyword | Identificar tribunal de origem |
| `grau` | text/keyword | Filtrar por instância (G1, G2, JE) |

### 2.4 Ordem de Consulta (Priorização)

Executar as consultas na seguinte ordem, interrompendo quando houver resultados suficientes (mínimo 5 precedentes relevantes, ideal 10-20):

1. **STJ** — Fonte primária. Buscar sempre.
2. **TJPR, TJMT, TJGO, TJBA** — TJs com maior volume de litígios agrários. Buscar em paralelo.
3. **TJSP, TJMG** — TJs de grande porte com jurisprudência relevante. Buscar se necessário.
4. **STF** — Buscar apenas se o tema envolver questão constitucional (ex: art. 5º, XXVI, CF — impenhorabilidade; art. 184-191, CF — reforma agrária).

### 2.5 Construção de Queries

**Modelo base para busca por assunto agrário:**

```json
{
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              { "match_phrase": { "assuntos.nome": "{{TERMO_PRINCIPAL}}" } },
              { "match": { "assuntos.nome": "{{TERMOS_SECUNDARIOS}}" } }
            ],
            "minimum_should_match": 1
          }
        }
      ],
      "filter": [
        { "range": { "dataAjuizamento": { "gte": "{{DATA_INICIO}}" } } }
      ]
    }
  },
  "size": 100,
  "sort": [
    { "dataAjuizamento": { "order": "desc" } }
  ],
  "_source": [
    "numeroProcesso", "classe", "assuntos", "orgaoJulgador",
    "dataAjuizamento", "tribunal", "grau", "movimentos"
  ]
}
```

Substituir `{{TERMO_PRINCIPAL}}`, `{{TERMOS_SECUNDARIOS}}` e `{{DATA_INICIO}}` conforme o tema. Se o usuário não especificar período, usar os últimos 5 anos como padrão.

**Modelo para busca por número de processo:**

```json
{
  "query": {
    "match": {
      "numeroProcesso": "{{NUMERO_SEM_FORMATACAO}}"
    }
  }
}
```

### 2.6 Execução via Shell

```bash
curl -s -X POST "https://api-publica.datajud.cnj.jus.br/api_publica_stj/_search" \
  -H "Authorization: APIKey cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==" \
  -H "Content-Type: application/json" \
  -d @/home/ubuntu/query_datajud.json \
  | python3 -m json.tool > /home/ubuntu/datajud_stj_results.json
```

Repetir para cada tribunal, salvando em arquivos separados (`datajud_tjpr_results.json`, etc.).

### 2.7 Processamento dos Resultados DATAJUD

Após receber os resultados, extrair e salvar em arquivo intermediário:

```python
import json

with open("/home/ubuntu/datajud_stj_results.json") as f:
    data = json.load(f)

processos = []
for hit in data.get("hits", {}).get("hits", []):
    src = hit["_source"]
    processos.append({
        "numero": src.get("numeroProcesso"),
        "tribunal": src.get("tribunal"),
        "classe": src.get("classe", {}).get("nome"),
        "assuntos": [a.get("nome") for a in src.get("assuntos", []) if isinstance(a, dict)],
        "orgao": src.get("orgaoJulgador", {}).get("nome"),
        "data": src.get("dataAjuizamento"),
        "grau": src.get("grau")
    })

# Salvar para uso posterior
with open("/home/ubuntu/processos_relevantes.json", "w") as f:
    json.dump(processos, f, indent=2, ensure_ascii=False)
```

**Limitação importante:** O DATAJUD fornece apenas metadados processuais (classe, assunto, movimentos). Não contém ementas nem inteiro teor de decisões. Os números de processo obtidos aqui servem como insumo para a busca do inteiro teor no Passo 3.

## 3. Busca do Inteiro Teor (JusBrasil + Sites dos Tribunais)

### 3.1 Busca no JusBrasil

O JusBrasil é a fonte principal para obter ementas e inteiro teor. Realizar buscas via navegador (browser tools).

**URLs de busca:**

| Tipo de Busca | URL |
|:--------------|:----|
| Busca geral | `https://www.jusbrasil.com.br/jurisprudencia/busca?q={{TERMOS}}` |
| Filtro por tribunal | Adicionar `&tribunal={{SIGLA}}` à URL |
| Busca por número | `https://www.jusbrasil.com.br/jurisprudencia/busca?q={{NUMERO_PROCESSO}}` |

**Procedimento:**

1. Navegar para a URL de busca do JusBrasil com os termos-chave do tema agrário.
2. Aplicar filtros de tribunal (STJ, TJPR, TJSP, TJMG, TJBA, TJMT, TJGO) e período.
3. Para cada resultado relevante, abrir a página do acórdão e extrair: ementa, relatório, voto, dispositivo.
4. Salvar o conteúdo extraído em `/home/ubuntu/jurisprudencia/` com nomenclatura padronizada: `{tribunal}_{numero_processo}.md`.
5. Para processos identificados via DATAJUD, buscar diretamente pelo número no JusBrasil.

**Critérios de relevância para seleção de resultados:**

- Presença dos termos-chave no corpo da ementa ou do voto.
- Tribunal pertencente à lista prioritária.
- Data de julgamento recente (preferir últimos 5 anos, mas incluir precedentes paradigmáticos mais antigos).
- Classe processual relevante (Recurso Especial, Apelação, Agravo de Instrumento, Embargos de Divergência).
- Citação de dispositivos legais agrários (Estatuto da Terra, Lei 8.629/93, Lei 4.504/64, Código Civil arts. 1.239-1.240, Lei 8.171/91, etc.).

### 3.2 Busca Direta nos Sites dos Tribunais (Fallback)

Usar quando o JusBrasil não retornar resultados suficientes ou para validação cruzada.

| Tribunal | URL de Jurisprudência |
|:---------|:----------------------|
| STJ | `https://scon.stj.jus.br/SCON/` |
| STF | `https://jurisprudencia.stf.jus.br/pages/search` |
| TJPR | `https://portal.tjpr.jus.br/jurisprudencia/` |
| TJSP | `https://esaj.tjsp.jus.br/cjsg/consultaCompleta.do` |
| TJMG | `https://www5.tjmg.jus.br/jurisprudencia/` |
| TJBA | `https://jurisprudencia.tjba.jus.br/` |
| TJMT | `https://jurisprudencia.tjmt.jus.br/` |
| TJGO | `https://www.tjgo.jus.br/jurisprudencia/` |

### 3.3 Busca no STJ via SCON (Complementar ao DATAJUD)

O sistema SCON do STJ permite busca por texto livre em ementas e permite filtros avançados. Usar como complemento ao DATAJUD quando necessário buscar por termos específicos no corpo das decisões.

URL: `https://scon.stj.jus.br/SCON/pesquisar.jsp`

Navegar via browser, inserir os termos de busca no campo de pesquisa livre, e filtrar por órgão julgador e período.

## 4. Síntese Crítica e Mapeamento de Tendências

### 4.1 Fichamento Estruturado

Para cada acórdão selecionado, registrar em `/home/ubuntu/jurisprudencia/fichamento.md`:

```markdown
## [Tribunal] - [Número do Processo]

**Classe:** [Recurso Especial / Apelação / etc.]
**Relator(a):** [Nome]
**Órgão Julgador:** [Turma/Câmara]
**Data do Julgamento:** [DD/MM/AAAA]
**Resultado:** [Provido / Improvido / Parcialmente Provido]

### Tese Jurídica Central
[Resumo da tese em 2-3 frases]

### Fundamentação Principal
[Dispositivos legais, precedentes citados, ratio decidendi]

### Trecho-Chave
> "[Citação direta do trecho mais relevante do acórdão]"

### Classificação
- **Status:** [Consolidado / Divergente / Isolado / Superado]
- **Precedente Qualificado:** [Sim/Não — se Recurso Repetitivo, IRDR, Súmula]
- **Relevância para o Caso:** [Alta / Média / Baixa]
```

### 4.2 Mapeamento de Tendências

Após o fichamento de todos os acórdãos, analisar o conjunto para identificar:

**Entendimentos consolidados** — Teses aplicadas de forma uniforme por múltiplos órgãos julgadores e em diferentes períodos. Indicar se há súmula, recurso repetitivo ou IRDR que cristalize o entendimento.

**Divergências ativas** — Teses conflitantes entre tribunais diferentes (divergência externa) ou entre turmas/câmaras do mesmo tribunal (divergência interna). Explicar as premissas de cada corrente.

**Evolução temporal** — Mudanças de entendimento ao longo do tempo, especialmente se houve superação de tese anterior (overruling) ou distinção (distinguishing).

**Lacunas** — Temas sobre os quais não há jurisprudência consolidada, indicando risco de imprevisibilidade.

### 4.3 Regras de Classificação de Status

| Status | Critério |
|:-------|:---------|
| **Consolidado** | Tese aplicada em 3+ acórdãos recentes do mesmo tribunal sem divergência, ou objeto de súmula/repetitivo/IRDR |
| **Majoritário** | Tese aplicada pela maioria dos julgados, mas com decisões em sentido contrário |
| **Divergente** | Existem linhas jurisprudenciais conflitantes com força argumentativa equivalente |
| **Minoritário** | Tese aplicada em poucos julgados, contrária ao entendimento predominante |
| **Isolado** | Decisão única ou rara, sem confirmação por outros julgados |
| **Superado** | Tese que foi expressamente abandonada pelo tribunal em julgados posteriores |

## 5. Elaboração do Relatório Final

Gerar o relatório em `/home/ubuntu/relatorio_jurisprudencial.md` com a seguinte estrutura:

### 5.1 Estrutura do Relatório

```markdown
# Relatório de Pesquisa Jurisprudencial
## [Tema Pesquisado]

**Data da Pesquisa:** [DD/MM/AAAA]
**Fontes Consultadas:** [DATAJUD, JusBrasil, SCON/STJ, etc.]
**Tribunais Pesquisados:** [Lista]
**Período:** [Intervalo temporal]

---

## 1. Síntese Executiva
[Parágrafo resumindo os principais achados em linguagem direta]

## 2. Quadro de Precedentes

| # | Tribunal | Processo | Relator(a) | Data | Tese Central | Status |
|:--|:---------|:---------|:-----------|:-----|:-------------|:-------|
| 1 | STJ | REsp ... | Min. ... | ... | ... | Consolidado |
| 2 | TJPR | AC ... | Des. ... | ... | ... | Divergente |

## 3. Análise Crítica

### 3.1 Entendimentos Consolidados
[Análise discursiva com citações dos acórdãos]

### 3.2 Divergências Identificadas
[Análise das correntes conflitantes]

### 3.3 Evolução Jurisprudencial
[Análise temporal, se aplicável]

## 4. Conclusão Estratégica
[Recomendações argumentativas com base na jurisprudência mapeada,
indicando teses mais seguras e riscos das teses minoritárias]

## 5. Referências
[Lista completa dos acórdãos citados com links, quando disponíveis]
```

### 5.2 Diretrizes de Redação

- Linguagem forense, técnica, precisa e impessoal.
- Adequada para uso direto em petições, pareceres e manifestações.
- Separar rigorosamente: texto legal/jurisprudencial consolidado, interpretação doutrinária, e estratégia argumentativa.
- Citar dispositivos legais com lei e artigo. Citar jurisprudência com tribunal, classe, número e relator.
- Não inventar números de processos, entendimentos ou dados normativos. Se a informação não for verificável, declarar expressamente a limitação.
- Usar blocos de citação (`>`) para trechos literais dos acórdãos.

## 6. Regras Especiais

### 6.1 Limitações da API DATAJUD

A API DATAJUD retorna apenas metadados processuais. Não contém ementas, votos ou inteiro teor. Os dados servem para identificar processos e filtrar por assunto/classe, mas o conteúdo decisório deve ser obtido via JusBrasil ou sites dos tribunais.

A chave de API é pública e pode ser alterada pelo CNJ a qualquer momento. Sempre verificar se a chave está vigente antes de reportar falha na API.

O limite é de 10.000 registros por consulta. Para resultados acima desse limite, usar paginação via `search_after`.

### 6.2 Tratamento de Erros

Se a API DATAJUD estiver indisponível, prosseguir diretamente para a busca no JusBrasil e sites dos tribunais.

Se o JusBrasil bloquear o acesso ou exigir login, informar o usuário e sugerir takeover do browser para autenticação, ou prosseguir com busca nos sites dos tribunais.

Se nenhuma fonte retornar resultados, informar o usuário explicitamente e sugerir reformulação dos termos de busca.

### 6.3 Salvamento Progressivo

Salvar resultados intermediários em `/home/ubuntu/jurisprudencia/` à medida que forem obtidos, para evitar perda de dados em caso de interrupção. Estrutura de diretório:

```
/home/ubuntu/jurisprudencia/
├── datajud/           # JSONs brutos do DATAJUD
├── acordaos/          # Inteiro teor extraído
├── fichamento.md      # Fichamento estruturado
└── relatorio_jurisprudencial.md  # Relatório final
```

## Recursos da Skill

- **`references/temas_agrarios.md`** — Lista de temas agrários prioritários com termos de busca recomendados para cada tema. Consultar sempre no Passo 1 para identificar os melhores termos de busca.
- **`references/endpoints_datajud.md`** — Referência completa dos endpoints DATAJUD por tribunal, incluindo aliases e campos disponíveis.
