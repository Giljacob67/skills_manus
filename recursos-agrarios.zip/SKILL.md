---
name: recursos-agrarios
description: Guia técnico e aprofundado sobre recursos processuais cíveis aplicáveis ao contencioso em Direito Agrário, cobrindo apelação, agravo de instrumento, embargos de declaração, recurso especial, recurso extraordinário, agravo em REsp/RE, embargos de divergência, ROC e reclamação, com templates, checklists de admissibilidade e teses agrárias específicas. Use quando o usuário precisar elaborar ou analisar recursos em matéria agrária.
---

# Skill: Recursos Processuais no Direito Agrário (`recursos-agrarios`)

## INTRODUÇÃO

Esta skill oferece um guia técnico e aprofundado sobre os recursos processuais cíveis aplicáveis ao contencioso em Direito Agrário. O conteúdo é direcionado a advogados com experiência e pressupõe domínio dos institutos fundamentais de direito processual civil. O foco reside na aplicação estratégica, nos requisitos de admissibilidade e nas teses materiais específicas do agronegócio.

---

## SUMÁRIO

**PARTE I - RECURSOS EM SEGUNDO GRAU (TJs e TRFs)**
1. Apelação (Art. 1.009, CPC)
2. Agravo de Instrumento (Art. 1.015, CPC)
3. Agravo Interno (Art. 1.021, CPC)
4. Embargos de Declaração (Art. 1.022, CPC)

**PARTE II - RECURSOS NOS TRIBUNAIS SUPERIORES**
5. Recurso Especial - REsp (Art. 105, III, CF)
6. Recurso Extraordinário - RE (Art. 102, III, CF)
7. Agravo em Recurso Especial/Extraordinário - AREsp/ARE (Art. 1.042, CPC)
8. Embargos de Divergência (Art. 1.043, CPC)
9. Recurso Ordinário Constitucional - ROC (Art. 105, II, CF)
10. Reclamação (Art. 988, CPC)

**PARTE III - MATERIAL DE APOIO**
11. Tabela de Prazos Recursais
12. Checklist Geral de Admissibilidade
13. Súmulas e Teses Relevantes

---

## PARTE I - RECURSOS EM SEGUNDO GRAU

### 1. APELAÇÃO (ART. 1.009, CPC)

Recurso ordinário por excelência, manejado contra sentenças (art. 203, §1º, CPC) para reexame integral da matéria de fato e de direito.

#### 1.1. Cabimento e Hipóteses Legais
- **Regra Geral:** Impugnação de sentenças, sejam terminativas (sem resolução de mérito, art. 485) ou definitivas (com resolução de mérito, art. 487).
- **Questões Interlocutórias não Agraváveis:** As decisões interlocutórias que não se enquadram no rol do art. 1.015 do CPC devem ser arguidas em **preliminar de apelação** (art. 1.009, §1º). A ausência de arguição acarreta a preclusão.

#### 1.2. Requisitos Formais
- **Tempestividade:** Prazo de 15 dias úteis (arts. 219 e 1.003, §5º, CPC).
- **Preparo:** Recolhimento das custas recursais, sob pena de deserção (art. 1.007). Comprovação no ato de interposição. A insuficiência no preparo autoriza a intimação para complementação em 5 dias (art. 1.007, §2º).
- **Regularidade Formal:** Petição dirigida ao juízo *a quo*, mas com razões endereçadas ao tribunal *ad quem*. Deve conter nomes e qualificação das partes, exposição do fato e do direito, razões do pedido de reforma ou de decretação de nulidade, e o pedido de nova decisão (art. 1.010, I a IV).

#### 1.3. Efeitos
- **Regra Geral:** Efeito devolutivo e suspensivo (*ope legis* - art. 1.012, *caput*).
- **Exceções ao Efeito Suspensivo (art. 1.012, §1º):** A sentença começa a produzir efeitos imediatamente após a publicação quando, por exemplo, confirma, concede ou revoga tutela provisória. Nesses casos, a concessão de efeito suspensivo à apelação exige requerimento específico ao tribunal (art. 1.012, §§3º e 4º), demonstrando a probabilidade de provimento do recurso ou, sendo relevante a fundamentação, houver risco de dano grave ou de difícil reparação.
- **Efeito Translativo:** Permite ao tribunal analisar matérias de ordem pública não suscitadas pelas partes (ex: condições da ação, pressupostos processuais).

#### 1.4. Estrutura da Peça (Template)

`PETIÇÃO DE INTERPOSIÇÃO`
- Endereçamento ao juízo de primeiro grau.
- Qualificação das partes (apelante e apelado).
- Indicação do recurso (Apelação) com fundamento no art. 1.009 do CPC.
- Requerimento de recebimento, processamento e remessa ao tribunal.
- Comprovação do preparo e porte de remessa e retorno.

`RAZÕES RECURSAIS`
- Endereçamento ao Tribunal de Justiça ou Tribunal Regional Federal.
- Breve síntese do processo e da decisão recorrida.
- **Preliminares (art. 1.009, §1º):**
  - Arguição de nulidades (sentença *citra*, *ultra*, *extra petita*; cerceamento de defesa).
  - Arguição de questões interlocutórias não agraváveis.
- **Mérito Recursal:**
  - Divisão em tópicos para cada tese de reforma.
  - Exposição clara do erro de julgamento (*error in judicando*) ou erro de procedimento (*error in procedendo*).
  - Fundamentação jurídica e jurisprudencial robusta.
- **Requerimentos:**
  - Conhecimento e provimento do recurso.
  - Acolhimento das preliminares para anular a sentença.
  - No mérito, a reforma integral ou parcial da decisão.
  - Inversão do ônus da sucumbência.

#### 1.5. Argumentação Específica (Direito Agrário)
- **Impenhorabilidade da Pequena Propriedade Rural:** Tese de ordem pública (art. 5º, XXVI, CF). Argumentar com base na definição de pequena propriedade (área de até 4 módulos fiscais), exploração familiar e ausência de outra propriedade rural. Citar o Tema 961 do STF.
- **Nulidade de Títulos de Crédito (CPR, CDCA):** Foco em vícios formais, desvio de finalidade, ausência de lastro no produto, ou prática de agiotagem. A apelação pode buscar a reforma de sentença que julgou improcedentes embargos à execução.
- **Revisão de Contratos Agrários:** Com base na onerosidade excessiva, aplicação do Código de Defesa do Consumidor (se o produtor for destinatário final fático e econômico), limitação de juros remuneratórios em crédito rural (Decreto-Lei 167/67) e nulidade de cláusulas de renúncia a direitos (Estatuto da Terra).
- **Função Social da Propriedade:** Em ações possessórias ou de desapropriação, demonstrar o cumprimento da função social (produtividade, respeito ao meio ambiente, observância das leis trabalhistas) como fato impeditivo, modificativo ou extintivo do direito do autor.

#### 1.6. Jurisprudência Relevante
- **STJ, REsp 1.913.204/SP:** A impenhorabilidade da pequena propriedade rural é norma de ordem pública, podendo ser arguida em qualquer momento processual, inclusive em sede de apelação, desde que antes da arrematação.
- **STJ, Súmula 298:** "O alongamento de dívida originada de crédito rural não constitui faculdade da instituição financeira, mas, direito do devedor nos termos da lei."
- **STF, Tema 961:** "É impenhorável a pequena propriedade rural familiar constituída de mais de 01 (um) terreno, desde que contínuos e com área total inferior a 04 (quatro) módulos fiscais do município de localização."

#### 1.7. Contrarrazões de Apelação
- **Prazo:** 15 dias úteis (art. 1.010, §1º).
- **Estrutura:** Similar às razões, mas com o objetivo de rebater os argumentos do apelante e pleitear a manutenção da sentença.
- **Técnica:** Impugnação específica de todos os pontos do recurso. Em preliminares, arguir a intempestividade, deserção ou violação à dialeticidade recursal. No mérito, reforçar os fundamentos da sentença e a correção do julgamento.
- **Apelação Adesiva (art. 997, §1º):** Se houver sucumbência recíproca, o apelado pode, no prazo das contrarrazões, interpor recurso adesivo, subordinado ao recurso principal.

#### 1.8. Erros Comuns a Evitar
- **Inovação Recursal:** Trazer fatos ou fundamentos jurídicos não discutidos em primeira instância. A apelação devolve ao tribunal o conhecimento da matéria *suscitada e discutida* (art. 1.013, §1º).
- **Falta de Dialeticidade:** Não impugnar especificamente os fundamentos da sentença, limitando-se a repetir argumentos da petição inicial ou da contestação. O recurso deve demonstrar o porquê de a decisão estar equivocada.
- **Deixar de Arguir Questões Interlocutórias não Agraváveis:** A preclusão consuma-se se a matéria não for suscitada em preliminar de apelação.


### 2. AGRAVO DE INSTRUMENTO (ART. 1.015, CPC)

Recurso destinado a impugnar decisões interlocutórias específicas, cuja urgência não permite aguardar a análise em preliminar de apelação.

#### 2.1. Cabimento e Hipóteses Legais
- **Rol de Taxatividade Mitigada (STJ, Tema 988):** O rol do art. 1.015 do CPC é taxativo, mas admite mitigação quando verificada a urgência decorrente da inutilidade do julgamento da questão no recurso de apelação.
- **Principais Hipóteses (Direito Agrário):**
  - **Tutelas Provisórias (inc. I):** Deferimento ou indeferimento de liminares em ações possessórias, revisionais de contrato, ou para sustar efeitos de protesto de CPR.
  - **Mérito Parcial do Processo (inc. II):** Decisões que julgam antecipadamente parte do pedido (ex: declaração de nulidade de uma cláusula contratual).
  - **Rejeição da Alegação de Convenção de Arbitragem (inc. III):** Relevante em contratos agrários com cláusula compromissória.
  - **Incidente de Desconsideração da Personalidade Jurídica (inc. IV):** Comum em execuções contra grupos econômicos do agronegócio.
  - **Rejeição do Pedido de Gratuidade da Justiça ou Acolhimento do Pedido de sua Revogação (inc. V).**
  - **Exibição ou Posse de Documento ou Coisa (inc. VI):** Crucial para acesso a contratos, extratos de financiamento, etc.
  - **Exclusão de Litisconsorte (inc. VII).**
  - **Admissão ou Inadmissão de Intervenção de Terceiros (inc. IX).**
  - **Concessão, Modificação ou Revogação do Efeito Suspensivo aos Embargos à Execução (inc. X):** De altíssima relevância em execuções de títulos rurais.
  - **Outros casos expressos em lei.**

#### 2.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis.
- **Preparo:** Exigível, salvo exceções legais.
- **Formação do Instrumento:** O recurso é dirigido diretamente ao tribunal. Deve ser instruído com as peças obrigatórias (art. 1.017, I) e facultativas (art. 1.017, III) para a compreensão da controvérsia. A ausência de peça obrigatória pode levar ao não conhecimento do recurso. Em processos eletrônicos, a formação do instrumento é dispensada (art. 1.017, §5º).

#### 2.3. Efeitos
- **Efeito Devolutivo:** Devolve ao tribunal o conhecimento da matéria impugnada.
- **Efeito Suspensivo (*Ope Judicis*):** Não é automático. Deve ser requerido pelo agravante ao relator, que poderá concedê-lo se demonstrar a probabilidade de provimento do recurso e o risco de dano grave, de difícil ou impossível reparação (art. 995, parágrafo único, e art. 1.019, I).
- **Tutela Antecipada Recursal:** O relator pode, a requerimento do agravante, antecipar a pretensão recursal, concedendo o que foi negado em primeira instância.

#### 2.4. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao Tribunal.
- Qualificação das partes e seus advogados.
- Indicação do recurso (Agravo de Instrumento) e da decisão agravada.
- **Exposição do Fato e do Direito:** Síntese da controvérsia e da decisão interlocutória.
- **Admissibilidade:** Demonstrar o cabimento do recurso em uma das hipóteses do art. 1.015 ou a aplicação da tese da taxatividade mitigada (Tema 988/STJ).
- **Razões da Reforma:** Argumentação jurídica para a reforma da decisão.
- **Pedido de Efeito Suspensivo ou Tutela Antecipada Recursal:** Em tópico destacado, demonstrar os requisitos do *fumus boni iuris* e *periculum in mora*.
- **Requerimentos:**
  - Concessão do efeito suspensivo/tutela antecipada.
  - Conhecimento e provimento do recurso para reformar a decisão agravada.
  - Intimação do agravado para contrarrazões.

#### 2.5. Argumentação Específica (Direito Agrário)
- **Tutela de Urgência para Manutenção na Posse:** Demonstrar a probabilidade do direito (contrato de arrendamento vigente, por exemplo) e o perigo de dano (risco de perda da safra).
- **Suspensão de Atos Expropriatórios:** Em execução de CPR, pedir efeito suspensivo ao agravo que ataca a decisão que negou a suspensão dos embargos, argumentando a impenhorabilidade da pequena propriedade rural ou a nulidade do título.
- **Produção de Prova Pericial:** Se o juiz indefere a perícia contábil para apurar juros abusivos em contrato de financiamento, o agravo pode ser fundamentado na tese da taxatividade mitigada (Tema 988), alegando que a ausência da prova tornará inútil a apelação futura (cerceamento de defesa).

#### 2.6. Jurisprudência Relevante
- **STJ, Tema Repetitivo 988:** "O rol do art. 1.015 do CPC é de taxatividade mitigada, por isso admite a interposição de agravo de instrumento quando verificada a urgência decorrente da inutilidade do julgamento da questão no recurso de apelação."
- **STJ, REsp 1.752.049/PR:** A decisão que define a competência é interlocutória e desafia agravo de instrumento com base na interpretação extensiva do art. 1.015, III, do CPC.

#### 2.7. Contraminuta (Contrarrazões)
- **Prazo:** 15 dias úteis para responder (art. 1.019, II).
- **Objetivo:** Rebater os argumentos do agravante, defender a manutenção da decisão de primeira instância e, se for o caso, impugnar o pedido de efeito suspensivo.

#### 2.8. Erros Comuns a Evitar
- **Interpor Agravo Fora das Hipóteses Legais:** Sem justificar a urgência conforme o Tema 988, o recurso não será conhecido.
- **Má Formação do Instrumento:** Em processos físicos, a ausência de peças essenciais (procurações, decisão agravada, certidão de intimação) é vício fatal.
- **Confundir Pedido de Efeito Suspensivo com Tutela Antecipada:** O primeiro visa suspender a eficácia da decisão; o segundo, obter um provimento que foi negado.


### 3. AGRAVO INTERNO (ART. 1.021, CPC)

Recurso destinado a submeter ao órgão colegiado a análise de uma decisão proferida monocraticamente pelo relator.

#### 3.1. Cabimento e Hipóteses Legais
- **Regra Geral:** Contra qualquer decisão monocrática do relator em tribunal (art. 1.021, *caput*).
- **Exemplos:**
  - Decisão que não conhece, nega ou dá provimento a recurso (art. 932, III a V).
  - Decisão que concede ou indefere efeito suspensivo ou tutela antecipada em agravo de instrumento ou apelação.
  - Decisão que julga o mérito de recursos em conformidade com súmula ou precedente qualificado.

#### 3.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis.
- **Preparo:** Em regra, não há preparo, salvo disposição específica em regimento interno.
- **Dialeticidade Específica:** A petição deve **impugnar especificadamente** os fundamentos da decisão monocrática agravada (art. 1.021, §1º). A mera repetição de argumentos do recurso anterior leva à inadmissibilidade.

#### 3.3. Efeitos
- **Efeito Devolutivo:** Devolve ao colegiado a matéria decidida monocraticamente.
- **Não possui efeito suspensivo *ope legis*.**

#### 3.4. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao relator da decisão agravada.
- Qualificação das partes.
- **Da Decisão Agravada:** Breve resumo da decisão monocrática.
- **Das Razões para a Reforma (Impugnação Específica):**
  - Tópico demonstrando o equívoco da decisão monocrática (*error in judicando* ou *error in procedendo*).
  - Confrontar diretamente cada fundamento da decisão do relator com os argumentos e provas que o infirmam.
- **Requerimentos:**
  - Pedido de retratação do relator (art. 1.021, §2º).
  - Caso não haja retratação, que o recurso seja levado a julgamento pelo órgão colegiado para ser conhecido e provido, reformando-se a decisão monocrática.

#### 3.5. Argumentação Específica (Direito Agrário)
- **Inaplicabilidade de Precedente:** Se o relator nega seguimento a um REsp com base em precedente, o agravo interno deve demonstrar a distinção (*distinguishing*) entre o caso concreto e o paradigma invocado, ou a superação (*overruling*) do entendimento.
- **Revisão de Tutela Recursal:** Contra decisão que indefere efeito suspensivo a um agravo de instrumento em execução rural. O agravo interno deve reforçar a presença do *periculum in mora* (risco de expropriação de bem essencial à atividade produtiva) e do *fumus boni iuris* (tese de nulidade do título).

#### 3.6. Jurisprudência Relevante
- **STJ, AgInt no AREsp 1.800.000/SP:** O agravo interno que não ataca especificamente os fundamentos da decisão agravada é inadmissível, por violação ao princípio da dialeticidade.
- **STJ, Súmula 182:** É inviável o agravo do art. 545 do CPC/73 (correspondente ao agravo interno em REsp/RE) que deixa de atacar especificamente os fundamentos da decisão agravada. (Aplicável por analogia).

#### 3.7. Contrarrazões
- **Prazo:** 15 dias úteis para o agravado apresentar sua resposta (art. 1.021, §2º).
- **Objetivo:** Sustentar a manutenção da decisão monocrática, rebatendo os argumentos do agravo interno.

#### 3.8. Erros Comuns a Evitar
- **Falta de Impugnação Específica:** O erro mais comum e fatal. É a principal causa de não conhecimento do recurso.
- **Pedir o Impossível:** Tentar rediscutir fatos e provas se a decisão monocrática aplicou corretamente uma súmula (ex: Súmula 7/STJ).
- **Multa por Recurso Protelatório:** Se o agravo interno for declarado manifestamente inadmissível ou improcedente em votação unânime, o órgão colegiado condenará o agravante a pagar ao agravado multa entre 1% e 5% do valor atualizado da causa (art. 1.021, §4º).


### 4. EMBARGOS DE DECLARAÇÃO (ART. 1.022, CPC)

Recurso de fundamentação vinculada, destinado a sanar vícios de omissão, contradição, obscuridade ou erro material em qualquer decisão judicial.

#### 4.1. Cabimento e Hipóteses Legais
- **Omissão:** A decisão deixa de se manifestar sobre ponto ou questão sobre o qual deveria ter se pronunciado. Inclui as teses firmadas em julgamento de casos repetitivos ou em incidente de assunção de competência aplicáveis ao caso (art. 1.022, parágrafo único, II).
- **Contradição:** Existência de proposições inconciliáveis entre si na própria decisão (ex: fundamentação aponta para um resultado, mas o dispositivo conclui de forma oposta).
- **Obscuridade:** Falta de clareza na redação, tornando o comando judicial ininteligível.
- **Erro Material:** Equívocos de digitação, erros de cálculo, etc.
- **Prequestionamento:** Os embargos são a via adequada para forçar a manifestação do tribunal sobre matéria que se pretende levar aos tribunais superiores (REsp/RE). A simples interposição já satisfaz o requisito do prequestionamento, ainda que os embargos sejam inadmitidos ou rejeitados (prequestionamento ficto - art. 1.025 do CPC).

#### 4.2. Requisitos Formais
- **Tempestividade:** 5 dias úteis (art. 1.023, CPC).
- **Preparo:** Isento de preparo.
- **Fundamentação Vinculada:** A petição deve indicar precisamente o vício (omissão, contradição, obscuridade ou erro material) e o ponto da decisão em que ele se encontra.

#### 4.3. Efeitos
- **Efeito Interruptivo:** A interposição dos embargos de declaração interrompe o prazo para a interposição de outros recursos, para qualquer das partes (art. 1.026, *caput*).
- **Efeitos Infringentes (Modificativos):** Excepcionalmente, o acolhimento dos embargos pode levar à alteração do resultado do julgamento. Nesses casos, o embargado deve ser intimado para se manifestar em 5 dias, em respeito ao contraditório (art. 1.023, §2º).

#### 4.4. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao juízo prolator da decisão embargada.
- Qualificação das partes.
- **Do Cabimento:** Indicar o vício (omissão, contradição, etc.) e o dispositivo legal (art. 1.022).
- **Da Demonstração do Vício:**
  - Transcrever o trecho da decisão que contém o vício.
  - Apontar de forma clara e objetiva a omissão, contradição ou obscuridade.
- **Do Prequestionamento (se for o caso):** Indicar o dispositivo de lei federal ou constitucional sobre o qual o tribunal não se manifestou e que é essencial para o futuro REsp/RE.
- **Requerimentos:**
  - Conhecimento e provimento dos embargos para sanar o vício.
  - Atribuição de efeitos infringentes (se aplicável).
  - Prequestionamento explícito da matéria.

#### 4.5. Argumentação Específica (Direito Agrário)
- **Omissão sobre Tese de Impenhorabilidade:** Se o acórdão de apelação ignora a alegação de impenhorabilidade da pequena propriedade rural, os embargos são essenciais para forçar a manifestação e prequestionar a matéria constitucional (art. 5º, XXVI, CF) e legal (art. 833, VIII, CPC).
- **Contradição na Análise de Contrato:** O acórdão afirma que o contrato é de parceria agrícola, mas aplica regras de arrendamento rural na fixação de valores. A contradição interna justifica os embargos.
- **Obscuridade sobre o Alcance da Decisão:** A decisão determina a "revisão do saldo devedor" em um financiamento rural, mas não especifica qual taxa de juros deve ser aplicada, gerando obscuridade que impede o cumprimento.

#### 4.6. Jurisprudência Relevante
- **STJ, Súmula 356/STF (aplicável por analogia):** "O ponto omisso da decisão, sobre o qual não foram opostos embargos declaratórios, não pode ser objeto de recurso extraordinário, por faltar o requisito do prequestionamento."
- **STJ, REsp 1.764.874/SP:** A contradição que autoriza os embargos de declaração é a interna, verificada entre as proposições e conclusões do próprio julgado, não a contradição entre a decisão e a prova dos autos ou o entendimento da parte.

#### 4.7. Contrarrazões
- **Prazo:** 5 dias úteis, apenas se os embargos puderem ter efeitos infringentes (art. 1.023, §2º).
- **Objetivo:** Sustentar a inexistência do vício apontado e a impossibilidade de modificação do julgado.

#### 4.8. Erros Comuns a Evitar
- **Rediscussão do Mérito:** Utilizar os embargos como uma nova apelação para tentar reverter um resultado desfavorável. O recurso tem finalidade de integração, não de substituição da decisão.
- **Não Apontar o Vício Claramente:** A fundamentação genérica leva à rejeição dos embargos.
- **Embargos Protelatórios:** A oposição de embargos manifestamente protelatórios sujeita a parte a uma multa de até 2% sobre o valor da causa. Na reiteração, a multa pode ser elevada a até 10% (art. 1.026, §§2º e 3º).


---

## PARTE II - RECURSOS NOS TRIBUNAIS SUPERIORES

### 5. RECURSO ESPECIAL (REsp) (ART. 105, III, CF)

Recurso de natureza extraordinária, direcionado ao Superior Tribunal de Justiça (STJ), destinado a uniformizar a interpretação da legislação federal infraconstitucional.

#### 5.1. Cabimento e Hipóteses Legais
- **Decisão Recorrida:** Acórdãos de Tribunais de Justiça (TJs) ou Tribunais Regionais Federais (TRFs) proferidos em única ou última instância.
- **Fundamentação Vinculada (art. 105, III, alíneas 'a', 'b' e 'c'):**
  - **Alínea 'a' (Violação de Lei Federal):** O acórdão recorrido contraria tratado ou lei federal, ou nega-lhes vigência. A violação deve ser direta, e não reflexa.
  - **Alínea 'b' (Ato de Governo Local):** O acórdão julga válido ato de governo local contestado em face de lei federal.
  - **Alínea 'c' (Dissídio Jurisprudencial):** O acórdão confere a lei federal interpretação divergente da que lhe haja atribuído outro tribunal.

#### 5.2. Requisitos de Admissibilidade
- **Prequestionamento:** A matéria federal controvertida deve ter sido expressamente debatida e decidida pelo tribunal *a quo*. A oposição de embargos de declaração é fundamental para suprir a omissão (Súmula 211/STJ). O prequestionamento ficto (art. 1.025, CPC) é admitido.
- **Impossibilidade de Reexame de Fatos e Provas (Súmula 7/STJ):** "A pretensão de simples reexame de prova não enseja recurso especial." O REsp não é uma terceira instância para reavaliar o conjunto fático-probatório.
- **Impossibilidade de Análise de Cláusulas Contratuais (Súmula 5/STJ):** "A simples interpretação de cláusula contratual não enseja recurso especial."
- **Demonstração Analítica do Dissídio (Alínea 'c'):** O recorrente deve comprovar a divergência mediante certidão, cópia ou citação do repositório de jurisprudência, mencionando as circunstâncias que identificam ou assemelham os casos confrontados (cotejo analítico).
- **Tempestividade:** 15 dias úteis.
- **Preparo:** Exigível.

#### 5.3. Efeitos
- **Apenas Efeito Devolutivo.** A concessão de efeito suspensivo é excepcional (*ope judicis*) e requer medida cautelar ou pedido incidental, demonstrando *fumus boni iuris* e *periculum in mora*.

#### 5.4. Estrutura da Peça (Template)

`PETIÇÃO DE INTERPOSIÇÃO`
- Endereçamento ao Presidente ou Vice-Presidente do tribunal de origem.

`RAZÕES RECURSAIS`
- Endereçamento ao STJ.
- **Exposição do Fato e do Direito:** Síntese da demanda e do acórdão recorrido.
- **Da Admissibilidade:**
  - **Do Prequestionamento:** Demonstrar que a matéria foi debatida no acórdão.
  - **Do Cabimento:** Indicar a alínea constitucional ('a', 'b' ou 'c').
- **Das Razões da Reforma:**
  - **(Alínea 'a'):** Apontar o dispositivo de lei federal violado e explicar como a decisão o contrariou.
  - **(Alínea 'c'):** Realizar o cotejo analítico, transcrevendo trechos dos acórdãos paradigma e recorrido para demonstrar a divergência.
- **Requerimentos:**
  - Admissão, conhecimento e provimento do recurso para reformar o acórdão.

#### 5.5. Argumentação Específica (Direito Agrário)
- **Violação ao Estatuto da Terra (Lei 4.504/64):** Apontar contrariedade a artigos que regem contratos de arrendamento e parceria, como os que estabelecem direitos irrenunciáveis do arrendatário.
- **Violação à Lei do Crédito Rural (Decreto-Lei 167/67):** Argumentar que o acórdão recorrido permitiu a cobrança de juros capitalizados em periodicidade não permitida ou não pactuada, ou que negou o direito ao alongamento da dívida (Súmula 298/STJ).
- **Dissídio sobre Impenhorabilidade:** Demonstrar que o TJ local adotou interpretação restritiva sobre a impenhorabilidade da pequena propriedade rural, enquanto o STJ ou outro tribunal possui entendimento mais amplo e favorável ao produtor.

#### 5.6. Jurisprudência Relevante
- **STJ, Súmula 7:** Impede o reexame de provas.
- **STJ, Súmula 5:** Impede a interpretação de cláusulas contratuais.
- **STJ, Súmula 211:** "Inadmissível recurso especial quanto à questão que, a despeito da oposição de embargos declaratórios, não foi apreciada pelo Tribunal a quo."
- **STJ, Corte Especial, EREsp 1.156.323-SP:** A Terceira Turma, alinhando-se à jurisprudência da Quarta Turma, passou a admitir a capitalização de juros em contratos de mútuo rural em periodicidade inferior à semestral, desde que expressamente pactuada.

#### 5.7. Contrarrazões
- **Prazo:** 15 dias úteis.
- **Objetivo:** Atacar os pressupostos de admissibilidade do REsp (falta de prequestionamento, Súmula 7, Súmula 5) e, no mérito, defender a manutenção do acórdão.

#### 5.8. Erros Comuns a Evitar
- **Tentar Reexaminar Provas:** A principal causa de inadmissão. O recurso deve se ater à questão de direito.
- **Prequestionamento Deficiente:** Não opor embargos de declaração para sanar omissão do tribunal de origem.
- **Cotejo Analítico Malfeito:** Na alínea 'c', não basta transcrever ementas. É preciso demonstrar a similitude fática e a diferença de teses jurídicas entre os julgados.


### 6. RECURSO EXTRAORDINÁRIO (RE) (ART. 102, III, CF)

Recurso de natureza excepcional, direcionado ao Supremo Tribunal Federal (STF), com a finalidade de guardar a Constituição Federal.

#### 6.1. Cabimento e Hipóteses Legais
- **Decisão Recorrida:** Acórdãos de única ou última instância que decidam causa.
- **Requisito Geral - Repercussão Geral (Art. 1.035, CPC):** O recorrente deve demonstrar a existência de questões constitucionais relevantes do ponto de vista econômico, político, social ou jurídico, que ultrapassem os interesses subjetivos da causa.
  - A repercussão geral é presumida quando o recurso impugnar decisão que contrarie súmula ou jurisprudência dominante do STF.
  - Há temas com repercussão geral já reconhecida em matéria agrária (ex: impenhorabilidade da pequena propriedade rural, desapropriação).
- **Fundamentação Vinculada (art. 102, III, alíneas):**
  - **Alínea 'a':** Contrariar dispositivo da Constituição.
  - **Alínea 'b':** Declarar a inconstitucionalidade de tratado ou lei federal.
  - **Alínea 'c':** Julgar válida lei ou ato de governo local contestado em face da Constituição.
  - **Alínea 'd':** Julgar válida lei local contestada em face de lei federal.

#### 6.2. Requisitos de Admissibilidade
- **Preliminar Formal de Repercussão Geral:** A petição do RE deve conter um tópico fundamentado sobre a existência da repercussão geral, sob pena de não conhecimento.
- **Prequestionamento:** A questão constitucional deve ter sido ventilada no acórdão recorrido.
- **Impossibilidade de Análise de Legislação Infraconstitucional:** A ofensa à Constituição deve ser direta e frontal, e não meramente reflexa (dependente da análise de lei federal).
- **Súmula 279/STF:** "Para simples reexame de prova, não cabe recurso extraordinário."

#### 6.3. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao STF.
- **Da Repercussão Geral:** Tópico obrigatório e fundamentado, demonstrando a relevância da questão constitucional.
- **Do Cabimento:** Indicar a alínea constitucional.
- **Do Prequestionamento:** Demonstrar o debate da matéria no acórdão.
- **Das Razões da Reforma:** Apontar o dispositivo constitucional violado e a forma como o acórdão o ofendeu.
- **Requerimentos:** Admissão, conhecimento e provimento do recurso.

#### 6.4. Argumentação Específica (Direito Agrário)
- **Violação ao Art. 5º, XXVI, CF (Impenhorabilidade):** Principal tese constitucional em matéria agrária. O RE é cabível quando o acórdão nega a impenhorabilidade da pequena propriedade rural trabalhada pela família.
- **Violação à Função Social da Propriedade (Art. 5º, XXIII, e Art. 186, CF):** Em ações de desapropriação, questionar a validade do decreto expropriatório se a propriedade cumpre sua função social.
- **Violação ao Devido Processo Legal (Art. 5º, LIV):** Em casos de cerceamento de defesa flagrante com contornos constitucionais.

#### 6.5. Jurisprudência Relevante
- **STF, Tema 961:** "É impenhorável a pequena propriedade rural familiar constituída de mais de 01 (um) terreno, desde que contínuos e com área total inferior a 04 (quatro) módulos fiscais do município de localização."
- **STF, Súmula 279:** Veda o reexame de provas.
- **STF, Súmula 356:** Exige o prequestionamento.

#### 6.6. Erros Comuns a Evitar
- **Ausência da Preliminar de Repercussão Geral:** Vício formal que leva à inadmissão sumária.
- **Ofensa Reflexa à Constituição:** Argumentar violação à CF que depende, primeiro, da análise de uma lei federal. Nesse caso, o recurso cabível seria o REsp.
- **Tentar Reexaminar Fatos:** Assim como no REsp, é vedado pelo STF.


### 7. AGRAVO EM RECURSO ESPECIAL / EXTRAORDINÁRIO (AREsp / ARE) (ART. 1.042, CPC)

Recurso cabível contra a decisão do presidente ou vice-presidente do tribunal de origem que inadmite o Recurso Especial ou o Recurso Extraordinário.

#### 7.1. Cabimento
- **Regra:** Contra decisão de inadmissibilidade que nega seguimento ao REsp ou RE.
- **Exceção (Não Cabimento):** Não cabe o agravo do art. 1.042 quando a decisão de inadmissão se fundamenta na aplicação de entendimento firmado em regime de repercussão geral ou em julgamento de recursos repetitivos (art. 1.042, *caput*). Nesse caso, o recurso cabível é o **Agravo Interno** para o próprio tribunal de origem (art. 1.030, §2º).

#### 7.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis.
- **Processamento:** A petição é dirigida ao presidente do tribunal de origem, mas as razões são endereçadas ao STJ (no AREsp) ou ao STF (no ARE). O agravo é processado nos próprios autos, sem necessidade de formação de instrumento.
- **Dialeticidade:** O agravante deve **impugnar especificamente** todos os fundamentos da decisão de inadmissibilidade. A falta de impugnação de um fundamento autônomo e suficiente para manter a decisão acarreta o não conhecimento do agravo (Súmula 182/STJ).

#### 7.3. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao STJ ou STF.
- **Síntese da Demanda:** Breve resumo do caso, do acórdão recorrido, do REsp/RE interposto e da decisão de inadmissão.
- **Da Impugnação Específica aos Fundamentos da Inadmissão:**
  - Criar um tópico para cada fundamento da decisão agravada (ex: "Do Equívoco na Aplicação da Súmula 7/STJ", "Do Prequestionamento Devidamente Realizado").
  - Demonstrar, ponto a ponto, por que a decisão de inadmissão está incorreta.
- **Requerimentos:**
  - Conhecimento e provimento do agravo para determinar a subida (o processamento) do Recurso Especial/Extraordinário.
  - Subsidiariamente, que o próprio agravo seja conhecido e provido para, desde logo, reformar o acórdão recorrido (art. 1.042, §4º).

#### 7.4. Argumentação Específica (Direito Agrário)
- **Afastamento da Súmula 7/STJ:** Argumentar que o REsp não busca o reexame de provas, mas sim a **revaloração jurídica** de um fato incontroverso nos autos. Por exemplo, se o acórdão afirma que a propriedade tem 5 módulos fiscais (fato), mas a classifica como pequena propriedade rural, a discussão é de direito (enquadramento legal), não de fato.
- **Demonstração do Prequestionamento:** Provar que a matéria foi debatida, transcrevendo os trechos pertinentes do acórdão recorrido ou dos embargos de declaração opostos.

#### 7.5. Erros Comuns a Evitar
- **Falta de Impugnação Específica:** É o vício mais comum. Se a decisão de inadmissão tem três fundamentos, os três devem ser atacados. Deixar um de fora invalida o recurso.
- **Interpor o Agravo Errado:** Confundir o AREsp/ARE com o Agravo Interno do art. 1.030, §2º. Se a inadmissão se baseia em repetitivo/repercussão geral, o recurso é o Agravo Interno.


### 8. EMBARGOS DE DIVERGÊNCIA (ART. 1.043, CPC)

Recurso cabível no âmbito do STJ e do STF para uniformizar a jurisprudência interna do próprio tribunal, quando há divergência de teses jurídicas entre seus órgãos fracionários.

#### 8.1. Cabimento
- **No STJ e no STF:** Contra acórdão de órgão fracionário que, em recurso extraordinário ou em recurso especial, divergir do julgamento de qualquer outro órgão do mesmo tribunal.
- **Objeto da Divergência:** A divergência deve ser sobre o **mérito** do recurso. Divergências em juízo de admissibilidade (ex: um acórdão conhece do recurso e outro não, por aplicação da Súmula 7) não autorizam os embargos, salvo se a própria admissibilidade for o mérito do recurso (art. 1.043, §3º).
- **Acórdãos em Confronto:** A divergência pode ocorrer entre Turmas diferentes, entre Turma e Seção, ou entre Turma e a Corte Especial/Plenário.

#### 8.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis.
- **Comprovação da Divergência (Cotejo Analítico):** O embargante deve provar a divergência com cópia ou citação de repositório oficial do acórdão paradigma e realizar o cotejo analítico, demonstrando a similitude fática e a tese jurídica diversa adotada no acórdão embargado.
- **Súmula 315/STJ:** "Não cabem embargos de divergência no âmbito do agravo de instrumento que não admite recurso especial."
- **Súmula 316/STJ:** "Cabem embargos de divergência contra acórdão que, em agravo regimental, decide o recurso especial."

#### 8.3. Estrutura da Peça (Template)

`RAZÕES RECURSAIS`
- Endereçamento ao relator do acórdão embargado.
- **Demonstração da Divergência:**
  - Apresentar o acórdão embargado e a tese jurídica por ele adotada.
  - Apresentar o acórdão paradigma e a tese jurídica conflitante.
  - **Do Cotejo Analítico:** Tópico específico para confrontar os dois julgados, mostrando a identidade de situações fáticas e a solução jurídica distinta.
- **Requerimentos:**
  - Admissão e provimento dos embargos para que prevaleça a tese do acórdão paradigma.

#### 8.4. Argumentação Específica (Direito Agrário)
- **Divergência sobre Capitalização de Juros:** Uma Turma do STJ entende que a capitalização de juros em CPR exige pactuação expressa e a outra Turma dispensa. Se o acórdão embargado adotou a tese mais restritiva, os embargos de divergência podem ser opostos com base no precedente da outra Turma.
- **Divergência sobre Prazo Prescricional:** Divergência entre as Turmas de Direito Privado do STJ sobre o prazo prescricional para a pretensão de cobrança de dívida fundada em contrato de arrendamento rural.

#### 8.5. Erros Comuns a Evitar
- **Divergência Superada:** Invocar como paradigma um julgado cuja tese já foi superada pela jurisprudência atual do tribunal (Súmula 168/STJ).
- **Falta de Similitude Fática:** Os casos confrontados devem ser factualmente semelhantes para que a divergência de teses jurídicas seja relevante.
- **Cotejo Analítico Deficiente:** Limitar-se a transcrever ementas sem demonstrar analiticamente a divergência.


### 9. RECURSO ORDINÁRIO CONSTITUCIONAL (ROC) (ART. 105, II, E ART. 102, II, CF)

Recurso com devolução ampla da matéria fática e jurídica, similar à apelação, cabível em hipóteses taxativas contra decisões denegatórias de *mandado de segurança*, *habeas data* e *habeas corpus*.

#### 9.1. Cabimento
- **Para o STJ (Art. 105, II, CF):**
  - Contra decisões denegatórias de *mandado de segurança* decididos em única instância pelos TRFs ou TJs, quando a decisão for denegatória.
  - Contra decisões denegatórias de *habeas corpus* ou *habeas data* decididos em única ou última instância pelos TRFs ou TJs.
- **Para o STF (Art. 102, II, CF):**
  - Contra decisões denegatórias de *habeas corpus*, *mandado de segurança*, *habeas data* e *mandado de injunção* decididos em única instância pelos Tribunais Superiores (STJ, TSM, TST, STM), quando a decisão for denegatória.

#### 9.2. Requisitos Formais
- **Tempestividade:** 15 dias úteis (para MS, HD, MI).
- **Preparo:** Exigível.
- **Regularidade Formal:** Petição de interposição dirigida ao presidente do tribunal de origem, com razões endereçadas ao STJ ou STF.

#### 9.3. Estrutura da Peça
- Semelhante à apelação, com ampla devolutividade. O recorrente pode impugnar tanto a matéria de direito quanto os fatos da causa.

#### 9.4. Argumentação Específica (Direito Agrário)
- **Mandado de Segurança:** É a hipótese mais comum no Direito Agrário. O ROC é cabível contra acórdão de TJ/TRF que denega a segurança impetrada por um produtor rural. Exemplo: MS contra ato de autoridade que recusa a emissão de guia de transporte animal (GTA) ou que bloqueia o cadastro ambiental rural (CAR) ilegalmente. Se o TJ denega a ordem, a parte pode interpor ROC para o STJ, discutindo o mérito do ato coator.

#### 9.5. Erros Comuns a Evitar
- **Confundir com REsp/RE:** O ROC tem hipóteses de cabimento muito restritas e não se confunde com os recursos especiais/extraordinários. Se a decisão do TJ concede a segurança, o recurso cabível pela parte contrária (a autoridade coatora) será o REsp ou o RE, e não o ROC.
- **Interpor contra decisão que não é de única instância:** O mandado de segurança deve ter sido de competência originária do tribunal.


### 10. RECLAMAÇÃO (ART. 988, CPC)

Medida destinada a preservar a competência de um tribunal, garantir a autoridade de suas decisões ou assegurar a observância de precedente qualificado.

#### 10.1. Cabimento
- **Preservar a competência do tribunal:** Quando um juízo de instância inferior usurpa a competência de um tribunal superior.
- **Garantir a autoridade das decisões do tribunal:** Quando uma decisão judicial proferida pelo tribunal é descumprida na origem.
- **Observância de precedente:** Para garantir a observância de acórdão proferido em julgamento de incidente de resolução de demandas repetitivas (IRDR) ou de incidente de assunção de competência (IAC).
- **Observância de Súmula Vinculante e de decisão do STF em controle concentrado de constitucionalidade (art. 988, III).**
- **Observância de acórdão proferido em julgamento de RE ou REsp repetitivos (art. 988, IV).**

#### 10.2. Requisitos e Processamento
- **Prazo:** Não há prazo preclusivo, mas a demora pode enfraquecer o argumento de urgência.
- **Instrução:** A petição inicial deve ser instruída com prova documental e dirigida ao presidente do tribunal cuja competência ou autoridade se busca preservar.
- **Relator:** Ao despachar a reclamação, o relator poderá suspender o processo principal ou o ato impugnado para evitar dano irreparável (art. 989, II).

#### 10.3. Argumentação Específica (Direito Agrário)
- **Descumprimento de Decisão do STJ/STF:** Se o STJ, em um REsp, concede efeito suspensivo a uma execução e o juiz de primeira instância pratica atos de constrição de bens, cabe reclamação diretamente no STJ para garantir a autoridade da decisão.
- **Inobservância de Tese de Recurso Repetitivo:** Se um TJ afasta a impenhorabilidade da pequena propriedade rural contrariando tese firmada pelo STF em repercussão geral (Tema 961), a reclamação pode ser a via para cassar a decisão e adequá-la ao precedente.

#### 10.4. Erros Comuns a Evitar
- **Usar como Sucedâneo Recursal:** A reclamação não pode ser utilizada como um atalho para rediscutir o mérito de uma decisão para a qual existe recurso próprio. A jurisprudência é rigorosa em não admitir a reclamação como substituta de recursos.
- **Falta de Esgotamento das Instâncias Ordinárias:** Para as hipóteses de inobservância de precedente qualificado (incisos III e IV do art. 988), a reclamação só será admitida se esgotadas as instâncias ordinárias (art. 988, §5º, II).


---

## PARTE III - MATERIAL DE APOIO

### 11. TABELA DE PRAZOS RECURSAIS (CPC/2015)

Todos os prazos são contados em **dias úteis**, conforme art. 219 do CPC. A contagem exclui o dia do começo e inclui o dia do vencimento (art. 224).

| Recurso | Prazo Legal | Fundamento Legal |
| :--- | :--- | :--- |
| Apelação | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo de Instrumento | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo Interno | 15 dias | Art. 1.003, § 5º, CPC |
| Embargos de Declaração | 5 dias | Art. 1.023, CPC |
| Recurso Especial (REsp) | 15 dias | Art. 1.003, § 5º, CPC |
| Recurso Extraordinário (RE) | 15 dias | Art. 1.003, § 5º, CPC |
| Agravo em REsp/RE (AREsp/ARE) | 15 dias | Art. 1.003, § 5º, CPC |
| Embargos de Divergência | 15 dias | Art. 1.003, § 5º, CPC |
| Recurso Ordinário Constitucional | 15 dias | Art. 1.003, § 5º, CPC |

**Observação:** O prazo para as contrarrazões é, em regra, o mesmo do recurso correspondente (ex: 15 dias para contrarrazões de apelação).

### 12. CHECKLIST GERAL DE ADMISSIBILIDADE RECURSAL

Este checklist serve como guia rápido para verificação dos requisitos comuns a todos os recursos.

**1. Cabimento:**
- [ ] O recurso é o meio adequado para impugnar a decisão? (Ex: Apelação contra sentença; Agravo de Instrumento contra interlocutória do art. 1.015).

**2. Tempestividade:**
- [ ] O recurso foi interposto dentro do prazo legal?
- [ ] A contagem considerou apenas dias úteis?
- [ ] Houve feriado local ou suspensão de expediente que prorrogue o prazo?

**3. Preparo:**
- [ ] O recurso exige preparo?
- [ ] As guias de custas foram preenchidas corretamente?
- [ ] O comprovante de pagamento foi juntado no ato da interposição?
- [ ] Se o preparo foi insuficiente, houve intimação para complementar?

**4. Regularidade Formal:**
- [ ] A petição está endereçada corretamente?
- [ ] As partes estão devidamente qualificadas?
- [ ] O recurso expõe os fatos e o direito de forma clara?
- [ ] O pedido de reforma ou anulação está explícito?
- [ ] **Dialeticidade:** O recurso impugna especificamente os fundamentos da decisão recorrida?

**5. Legitimidade e Interesse:**
- [ ] O recorrente é parte no processo ou terceiro prejudicado?
- [ ] O recorrente sofreu sucumbência (prejuízo) com a decisão?

**6. Inexistência de Fato Impeditivo ou Extintivo:**
- [ ] Houve renúncia ao direito de recorrer?
- [ ] Houve aquiescência (aceitação) da decisão?
- [ ] Houve desistência do recurso?

**Requisitos Específicos (REsp/RE):**
- [ ] **Prequestionamento:** A matéria foi debatida no tribunal de origem?
- [ ] **Repercussão Geral (RE):** A preliminar foi devidamente fundamentada?
- [ ] **Súmulas Impeditivas:** O recurso não esbarra nas Súmulas 5 ou 7 do STJ, ou 279 do STF?
- [ ] **Dissídio Jurisprudencial:** O cotejo analítico foi realizado corretamente?

### 13. SÚMULAS E TESES RELEVANTES (STF/STJ)

**Impenhorabilidade e Propriedade Rural:**
- **STF, Tema 961:** "É impenhorável a pequena propriedade rural familiar constituída de mais de 01 (um) terreno, desde que contínuos e com área total inferior a 04 (quatro) módulos fiscais..."
- **STJ, Súmula 7:** "A pretensão de simples reexame de prova não enseja recurso especial."
- **STF, Súmula 279:** "Para simples reexame de prova, não cabe recurso extraordinário."

**Crédito e Contratos Agrários:**
- **STJ, Súmula 298:** "O alongamento de dívida originada de crédito rural não constitui faculdade da instituição financeira, mas, direito do devedor nos termos da lei."
- **STJ, Súmula 5:** "A simples interpretação de cláusula contratual não enseja recurso especial."
- **STJ, Súmula 282/STF:** "É inadmissível o recurso extraordinário, quando não ventilada, na decisão recorrida, a questão federal suscitada."
- **STJ, Súmula 356/STF:** "O ponto omisso da decisão, sobre o qual não foram opostos embargos declaratórios, não pode ser objeto de recurso extraordinário, por faltar o requisito do prequestionamento."

**Processual:**
- **STJ, Súmula 182:** "É inviável o agravo do art. 545 do CPC que deixa de atacar especificamente os fundamentos da decisão agravada."
- **STJ, Súmula 211:** "Inadmissível recurso especial quanto à questão que, a despeito da oposição de embargos declaratórios, não foi apreciada pelo Tribunal a quo."
- **STJ, Tema Repetitivo 988:** "O rol do art. 1.015 do CPC é de taxatividade mitigada..."


### 14. TEMAS AGRÁRIOS RECORRENTES EM RECURSOS

#### 14.1. Impenhorabilidade da Pequena Propriedade Rural

A proteção constitucional da pequena propriedade rural (art. 5º, XXVI, CF) constitui uma das teses mais relevantes em recursos no contencioso agrário. A propriedade deve ser de até 4 módulos fiscais do município de localização e trabalhada pela família. O STF, no Tema 961, consolidou que a impenhorabilidade alcança propriedades constituídas de mais de um terreno, desde que contínuos e com área total inferior a 4 módulos fiscais. A Lei 8.009/90 complementa a proteção ao estendê-la ao imóvel rural que serve de residência e sustento da família. A matéria é de ordem pública, podendo ser arguida em qualquer grau de jurisdição.

#### 14.2. Nulidade de CPR e CDCA

A Cédula de Produto Rural (Lei 8.929/94) e o Certificado de Direitos Creditórios do Agronegócio (Lei 11.076/04) são títulos executivos extrajudiciais que frequentemente geram litígios. As teses recursais mais comuns incluem: ausência de lastro no produto (CPR emitida sem correspondência com produção real), desvio de finalidade (CPR utilizada como instrumento de financiamento disfarçado), vícios formais (ausência de requisitos essenciais do art. 3º da Lei 8.929/94), e prática de agiotagem. A CPR financeira (art. 4º-A) exige registro em sistema de registro e liquidação financeira de ativos autorizado pelo Banco Central, sob pena de nulidade.

#### 14.3. Juros Abusivos em Financiamento Rural

O crédito rural é regulado pelo Decreto-Lei 167/67 e pelo Manual de Crédito Rural (MCR) do Banco Central. As taxas de juros são controladas e fixadas pelo Conselho Monetário Nacional. A cobrança de juros acima dos limites legais ou a capitalização em periodicidade não pactuada são vícios frequentemente arguidos em recursos. A Súmula 298/STJ garante o direito do devedor ao alongamento da dívida rural, não sendo faculdade da instituição financeira. As operações "mata-mata" (concessão de novo crédito para quitar o anterior, com incorporação de encargos ao principal) são consideradas abusivas pela jurisprudência, pois geram anatocismo ilegal e onerosidade excessiva.

#### 14.4. Revisão de Contratos Agrários (Arrendamento e Parceria)

Os contratos de arrendamento e parceria rural são regidos pelo Estatuto da Terra (Lei 4.504/64) e pelo Decreto 59.566/66. As normas protetivas são de ordem pública e irrenunciáveis. A 3ª Turma do STJ tem entendido que as normas protetivas do arrendamento rural não se aplicam ao arrendatário que é empresa rural de grande porte (REsp 1.447.082/SP). O direito de preferência do arrendatário na alienação do imóvel (art. 92, §3º, Estatuto da Terra) é tema recorrente. A nulidade de cláusula de renúncia à indenização por benfeitorias necessárias e úteis é pacífica na jurisprudência do STJ.

#### 14.5. Operações Mata-Mata e Agiotagem Rural

A prática de renovação sucessiva de contratos de crédito rural com incorporação de encargos vencidos ao principal (operação "mata-mata") configura anatocismo ilegal. A jurisprudência do STJ reconhece a nulidade dessas operações e determina o recálculo do saldo devedor com expurgo dos encargos ilegais. A agiotagem rural, praticada por pessoas físicas ou jurídicas não autorizadas a operar no sistema financeiro, é crime (Lei 7.492/86, art. 16) e gera a nulidade dos contratos. Em sede recursal, a tese deve ser articulada com pedido de perícia contábil para apuração dos valores efetivamente devidos.

#### 14.6. Desapropriação e Indenização

A desapropriação para fins de reforma agrária (art. 184, CF) exige o descumprimento da função social da propriedade (art. 186, CF). A Súmula 354/STJ estabelece que "a invasão do imóvel é causa de suspensão do processo expropriatório para fins de reforma agrária." O STF, no julgamento da ADI 2.213, fixou parâmetros sobre a relação entre esbulho possessório e desapropriação. A indenização prévia e justa em títulos da dívida agrária (TDA) é garantia constitucional, e a discussão sobre o valor justo da indenização é tema frequente em recursos, especialmente quanto à inclusão de cobertura vegetal, benfeitorias e potencial de exploração econômica.

#### 14.7. Usucapião Rural (Pro Labore)

A usucapião especial rural (art. 191, CF; art. 1.239, CC) exige posse mansa e pacífica, por 5 anos ininterruptos, de área não superior a 50 hectares, tornando-a produtiva por seu trabalho ou de sua família, e desde que não seja proprietário de outro imóvel rural ou urbano. O STJ tem entendido que a comprovação do trabalho produtivo é requisito essencial e que a mera posse passiva não satisfaz a exigência constitucional. A usucapião rural não pode incidir sobre terras públicas (Súmula 340/STF).

#### 14.8. Função Social da Propriedade Rural

A função social da propriedade rural é cumprida quando atende, simultaneamente, aos requisitos do art. 186 da CF: aproveitamento racional e adequado; utilização adequada dos recursos naturais e preservação do meio ambiente; observância das disposições que regulam as relações de trabalho; e exploração que favoreça o bem-estar dos proprietários e trabalhadores. O STF decidiu que o cumprimento da função social é requisito para que um imóvel produtivo não seja desapropriado para fins de reforma agrária. A produtividade, isoladamente, não basta para afastar a desapropriação se os demais requisitos não forem atendidos.

### 15. JURISPRUDÊNCIA DO STJ ORGANIZADA POR TURMA

#### 15.1. 3ª Turma (Direito Privado)

| Tema | Precedente | Tese |
| :--- | :--- | :--- |
| Arrendamento Rural - Normas Protetivas | REsp 1.447.082/SP | Normas protetivas do arrendamento rural não se aplicam ao arrendatário empresa rural de grande porte |
| Arrendamento Rural - Direito de Retenção | REsp 2.080.023/MG | Limites ao direito de retenção do arrendatário rural por benfeitorias |
| Contratos Agrários - Benfeitorias | REsp 1.336.293/RS | Nulidade da cláusula de renúncia à indenização por benfeitorias necessárias e úteis |
| CPR - Endosso | REsp 1.635.613/PR | Efeitos do endosso em preto da CPR e responsabilidade do endossante |
| Capitalização de Juros | EREsp 1.156.323/SP | Admissibilidade da capitalização de juros em periodicidade inferior à semestral, desde que expressamente pactuada |

#### 15.2. 4ª Turma (Direito Privado)

| Tema | Precedente | Tese |
| :--- | :--- | :--- |
| Impenhorabilidade Rural | REsp 1.913.204/SP | Impenhorabilidade da pequena propriedade rural é norma de ordem pública |
| Crédito Rural - Alongamento | Súmula 298 | Alongamento de dívida rural é direito do devedor, não faculdade do banco |
| Operações Mata-Mata | REsp (diversos) | Nulidade de operações de renovação com incorporação de encargos ao principal |
| Usucapião Rural | REsp (diversos) | Comprovação do trabalho produtivo como requisito essencial da usucapião pro labore |

#### 15.3. 1ª e 2ª Turmas (Direito Público)

| Tema | Precedente | Tese |
| :--- | :--- | :--- |
| Desapropriação - Invasão | Súmula 354/STJ | Invasão do imóvel suspende o processo expropriatório para reforma agrária |
| Desapropriação - Indenização Justa | REsp (diversos) | Indenização deve incluir cobertura vegetal, benfeitorias e potencial econômico |
| ITR - Imunidade | REsp (diversos) | Pequenas glebas rurais exploradas pelo proprietário que não possua outro imóvel são imunes ao ITR (art. 153, §4º, II, CF) |

### 16. TEMPLATES DE ESTRUTURA RECURSAL

#### 16.1. Template Genérico de Recurso

```
EXCELENTÍSSIMO(A) SENHOR(A) [JUIZ/DESEMBARGADOR/MINISTRO]

[QUALIFICAÇÃO DAS PARTES]

[TIPO DE RECURSO] que interpõe [RECORRENTE], nos autos da
[AÇÃO], em face de [RECORRIDO], pelos fatos e fundamentos
a seguir expostos.

I - DA TEMPESTIVIDADE
[Demonstrar que o recurso está dentro do prazo legal]

II - DO CABIMENTO
[Indicar o fundamento legal do recurso]

III - SÍNTESE DA DEMANDA E DA DECISÃO RECORRIDA
[Resumo objetivo do caso e da decisão impugnada]

IV - DAS PRELIMINARES (se aplicável)
[Nulidades, questões processuais]

V - DAS RAZÕES PARA A REFORMA
V.1 - [Primeiro fundamento de reforma]
V.2 - [Segundo fundamento de reforma]
V.3 - [Terceiro fundamento de reforma]

VI - DO PREQUESTIONAMENTO (se REsp/RE)
[Indicação dos dispositivos legais/constitucionais]

VII - DOS REQUERIMENTOS
[Pedidos específicos de reforma/anulação]

[LOCAL, DATA]
[ADVOGADO - OAB]
```

#### 16.2. Template Específico para REsp em Matéria Agrária

```
EXCELENTÍSSIMO(A) SENHOR(A) PRESIDENTE DO TRIBUNAL DE JUSTIÇA
DO ESTADO DE [UF]

[QUALIFICAÇÃO]

RECURSO ESPECIAL, com fundamento no art. 105, III, alínea(s)
[a/b/c], da Constituição Federal.

I - DA TEMPESTIVIDADE

II - DO CABIMENTO
[Indicar a alínea e o dispositivo de lei federal violado]

III - DO PREQUESTIONAMENTO
[Demonstrar que a matéria foi debatida no acórdão]

IV - SÍNTESE DA DEMANDA

V - DO ACÓRDÃO RECORRIDO

VI - DAS RAZÕES PARA A REFORMA

VI.1 - DA VIOLAÇÃO AO ART. [X] DA LEI [Y]
[Argumentação jurídica]

VI.2 - DO DISSÍDIO JURISPRUDENCIAL (se alínea 'c')
[Cotejo analítico com acórdão paradigma]

VII - DOS REQUERIMENTOS
Ante o exposto, requer:
a) a admissão e o processamento do presente Recurso Especial;
b) a intimação do recorrido para contrarrazões;
c) o conhecimento e o provimento do recurso para reformar
   o v. acórdão recorrido, [especificar o resultado pretendido].

[LOCAL, DATA]
[ADVOGADO - OAB]
```

---

## REFERÊNCIAS NORMATIVAS

| Diploma | Dispositivos Relevantes |
| :--- | :--- |
| Constituição Federal/88 | Arts. 5º (XXIII, XXVI, LIV), 102 (II, III), 105 (II, III), 153 (§4º), 184, 185, 186, 191 |
| CPC/2015 (Lei 13.105/15) | Arts. 203, 219, 224, 485, 487, 833 (VIII), 932, 988, 989, 995, 997, 1.003, 1.007, 1.009 a 1.013, 1.015, 1.017, 1.019, 1.021 a 1.026, 1.030, 1.035, 1.042, 1.043 |
| Estatuto da Terra (Lei 4.504/64) | Arts. 92, 95, 96 |
| Decreto 59.566/66 | Regulamenta contratos agrários |
| Decreto-Lei 167/67 | Crédito rural |
| Lei 8.009/90 | Impenhorabilidade do bem de família |
| Lei 8.629/93 | Reforma agrária |
| Lei 8.929/94 | Cédula de Produto Rural (CPR) |
| Lei 11.076/04 | CDCA e outros títulos do agronegócio |
| Código Civil/2002 | Arts. 1.239 (usucapião rural), 421 (função social do contrato) |

---

**FIM DA SKILL `recursos-agrarios` v1.0**
