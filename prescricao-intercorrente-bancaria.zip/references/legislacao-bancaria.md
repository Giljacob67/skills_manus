# Legislação-Chave para Prescrição Intercorrente Bancária

## Prescrição Intercorrente em Execução

| Diploma | Dispositivo | Conteúdo |
|:--------|:-----------|:---------|
| CPC/2015 | Art. 921 | Prescrição intercorrente: execução extingue-se quando não há movimentação processual por mais de 1 ano |
| CPC/2015 | Art. 921, §1º | Eventos que suspendem a prescrição intercorrente (citação válida, protesto, reconhecimento de dívida) |
| CPC/2015 | Art. 202 | Interrupção da prescrição ordinária |
| CC/2002 | Arts. 189-206 | Regime geral de prescrição |

## Títulos de Crédito — Requisitos Formais

| Título | Lei | Dispositivos | Requisitos Essenciais |
|:-------|:----|:-----------|:----------------------|
| **Duplicata** | Lei 5.474/68 | Arts. 2º, 3º, 15 | Indicação de sacador, sacado, valor, data de vencimento, série, número sequencial, descrição da mercadoria/serviço |
| **Nota Promissória** | Lei Uniforme de Genebra | Arts. 75-84 | Promessa incondicional de pagamento, nome do beneficiário, data, assinatura do emitente |
| **Cheque** | Lei 7.357/85 | Arts. 1º-2º | Ordem de pagamento à vista, nome do banco, data, valor, assinatura do emitente |

## Juros — Limitações Legais

| Diploma | Dispositivo | Conteúdo |
|:--------|:-----------|:---------|
| Decreto 22.626/33 | Arts. 1º-4º | Limitação de juros a 12% a.a. entre particulares; vedação de anatocismo |
| MP 2.170-36/01 | Art. 5º | Nulidade de cláusulas usurarias; capitalização de juros permitida em operações bancárias, desde que expressamente pactuada |
| Res. CMN 3.517/07 | Art. 1º | Taxa média de mercado como parâmetro de abusividade em operações bancárias |
| CDC/1990 | Arts. 39, 51 | Práticas abusivas e cláusulas abusivas em contratos de consumo |

## Procedimento de Execução

| Fase | CPC | Descrição |
|:-----|:----|:----------|
| Ajuizamento | Arts. 774-780 | Requisitos da petição inicial de execução |
| Citação | Arts. 820-828 | Procedimento de citação do devedor |
| Embargos à Execução | Arts. 914-920 | Defesa do executado; prazo de 15 dias úteis |
| Penhora | Arts. 829-866 | Procedimento de penhora de bens |
| Hasta Pública | Arts. 867-902 | Alienação dos bens penhorados |
| Extinção | Arts. 921-924 | Hipóteses de extinção da execução |

## Prescrição Ordinária de Títulos de Crédito

| Título | Prazo | Fundamento |
|:-------|:------|:-----------|
| Duplicata | 3 anos | Lei 5.474/68, art. 26 |
| Nota Promissória | 3 anos | Lei Uniforme de Genebra, art. 75 |
| Cheque | 6 meses | Lei 7.357/85, art. 59 |
| Crédito Bancário | 3-5 anos | Conforme natureza da operação (CC, arts. 189-206) |

## Jurisprudência Consolidada (STJ)

| Tema | Súmula/Precedente | Conteúdo |
|:-----|:------------------|:---------|
| Prescrição Intercorrente | Jurisprudência pacífica | Prescrição intercorrente é aplicável em execução de títulos após 1 ano de inatividade processual |
| Capitalização de Juros | Súmula 382 | Capitalização de juros em operações bancárias é permitida, desde que expressamente pactuada |
| Juros Abusivos | Jurisprudência pacífica | Taxa média de mercado (Res. CMN 3.517/07) é parâmetro para avaliar abusividade |
| Embargos à Execução | Jurisprudência pacífica | Prazo para oposição é de 15 dias úteis contados da juntada do mandado de citação |
