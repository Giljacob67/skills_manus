---
name: prescricao-intercorrente-bancaria
description: Calcula e analisa prescrição intercorrente em execuções de títulos de crédito bancário, considerando o CPC, prazos de inatividade processual, suspensões legais e particularidades de cada título (duplicata, nota promissória, cheque). Gera parecer técnico com estratégia de defesa ou cobrança.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Prescrição Intercorrente Bancária

## Visão Geral

A skill `prescricao-intercorrente-bancaria` é uma ferramenta técnica de alta precisão para análise e cálculo de prescrição intercorrente em execuções de títulos de crédito. Desenvolvida para advogados que atuam na área de cobrança e execução, a skill automatiza a contagem de prazos de inatividade processual, identifica eventos que suspendem ou interrompem a prescrição, e fornece parecer técnico fundamentado sobre a viabilidade de defesa ou cobrança baseada em prescrição intercorrente.

## Workflow Principal

O fluxo de trabalho foi desenhado para ser direto e eficiente, partindo da entrada de dados mínimos para a entrega de um resultado completo e fundamentado.

1. **Iniciação e Coleta de Dados:** O usuário invoca a skill e fornece os dados essenciais: número do processo, tribunal, data de ajuizamento da execução, data da última movimentação processual, natureza do título (duplicata, nota promissória, cheque), e cópia da petição inicial e últimos movimentos.

2. **Análise de Inatividade Processual:** A skill examina o processo para identificar períodos de inatividade (ausência de movimentação processual) conforme o art. 921 do CPC. Calcula o período decorrido desde a última movimentação até a data atual.

3. **Verificação de Suspensões e Interrupções:** A skill verifica se houve eventos que suspendem a prescrição intercorrente (art. 921, §1º, CPC) ou que interrompem a prescrição ordinária (art. 202, CC), como:
   - Citação válida do devedor
   - Protesto do título
   - Reconhecimento da dívida
   - Atos processuais válidos

4. **Cálculo do Prazo:** Com base no CPC e nas particularidades do título, a skill realiza o cálculo preciso do prazo de inatividade e identifica a data de consumação da prescrição intercorrente (se aplicável).

5. **Geração de Parecer Técnico:** A skill apresenta um parecer detalhado contendo:
   - Análise da inatividade processual
   - Eventos que suspendem ou interrompem a prescrição
   - Data de consumação da prescrição intercorrente
   - Fundamentação legal e jurisprudencial
   - Recomendação estratégica (defesa ou cobrança)

6. **Integração com Agenda (Opcional):** Mediante autorização, a skill utiliza o Google Calendar para criar um evento alertando sobre a data de consumação da prescrição.

## Capacidades Detalhadas

- **Cálculo de Inatividade Processual:** Identifica períodos sem movimentação processual conforme art. 921, CPC, considerando suspensões legais.
- **Análise de Eventos de Suspensão/Interrupção:** Verifica citação, protesto, reconhecimento de dívida e outros eventos que afetam a prescrição.
- **Diferenciação por Tipo de Título:** Aplica regras específicas para duplicata (Lei 5.474/68), nota promissória (Lei Uniforme de Genebra), e cheque (Lei 7.357/85).
- **Cálculo Preciso de Prazos:** Realiza contagem exata considerando o CPC e calendários forenses.
- **Parecer Técnico Fundamentado:** Elabora parecer adequado para uso em petições, pareceres e manifestações processuais.
- **Integração com Google Calendar:** Automatiza a criação de eventos com alertas sobre datas críticas de prescrição.

## Exemplos de Uso

**Exemplo 1: Análise de Prescrição Intercorrente em Execução de Duplicata**

> **Usuário:** "Preciso analisar prescrição intercorrente. Execução de duplicata ajuizada em 15/03/2023, última movimentação em 12/08/2024 (juntada de parecer do MP). Processo nº 0012345-67.2023.8.26.0100 (TJSP)."

> **Resultado da Skill (síntese):**
> ```
> **Análise de Prescrição Intercorrente**
> 
> *   **Título:** Duplicata (Lei 5.474/68)
> *   **Data de Ajuizamento:** 15/03/2023
> *   **Última Movimentação:** 12/08/2024 (Juntada de parecer do MP)
> *   **Período de Inatividade:** 12/08/2024 a [data atual] = [X] dias
> 
> **Análise de Eventos:**
> *   Citação válida: [Sim/Não]
> *   Protesto do título: [Sim/Não]
> *   Reconhecimento de dívida: [Sim/Não]
> 
> *   **Prescrição Intercorrente Consumada em:** [DD/MM/AAAA]
> *   **Status:** [Consumada / Próxima de consumação / Não consumada]
> 
> **Recomendação:** [Defesa / Cobrança / Cautela]
> ```

## Melhores Práticas e Considerações

- **Verificação Dupla:** Embora a skill seja projetada para alta precisão, a conferência humana do status processual no sistema do tribunal permanece como prática de segurança indispensável.
- **Dados de Entrada:** A precisão depende da exatidão dos dados fornecidos, especialmente da data da última movimentação processual.
- **Atualização de Informações:** Movimentações processuais não capturadas em tempo real podem afetar o cálculo. Fique atento aos comunicados do tribunal.
- **Uso Estratégico:** A prescrição intercorrente é ferramenta defensiva poderosa, mas deve ser articulada com outras defesas no mérito.
