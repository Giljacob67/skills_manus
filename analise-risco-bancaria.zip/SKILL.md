---
name: analise-risco-bancaria
description: Executa análise de risco jurídico em operações bancárias, cobrança e execução de títulos, classificando probabilidade e impacto, identificando vulnerabilidades processuais e contratuais, e recomendando estratégias de mitigação com geração de parecer estruturado.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Análise de Risco Bancária

## Visão Geral

Esta skill atua como uma ferramenta de diagnóstico jurídico, especializada na análise e quantificação de riscos em operações bancárias, cobrança e execução de títulos de crédito. Seu objetivo é fornecer ao advogado uma avaliação técnica, estruturada e fundamentada sobre as vulnerabilidades e potenciais impactos financeiros ou operacionais de um determinado caso, contrato ou operação.

## Workflow Principal

O processo de análise de risco é conduzido em etapas sequenciais para garantir uma avaliação completa e precisa.

1. **Ativação e Input de Dados:** O usuário invoca a skill e fornece o escopo da análise (processo judicial, contrato, operação de cobrança, etc.). É fundamental o fornecimento de documentos pertinentes (cópia do processo, contrato, títulos, extratos).

2. **Processamento e Análise Preliminar:** A skill processa os documentos e o contexto fornecido para identificar os pontos críticos. Mapeia os fatos, as relações jurídicas e as teses centrais.

3. **Identificação e Classificação de Riscos:** Cada risco potencial é identificado e classificado segundo uma matriz de probabilidade (Alta, Média, Baixa) e impacto (Alto, Médio, Baixo). A classificação é fundamentada em análise normativa e jurisprudencial.

4. **Geração dos Produtos de Análise:** Com base na classificação, a skill gera:
    - Uma **Matriz de Riscos** visual, que oferece um panorama rápido dos pontos mais críticos.
    - Um **Parecer de Risco Estruturado**, detalhando cada risco, sua fundamentação, as vulnerabilidades identificadas e as estratégias de mitigação recomendadas.

5. **Entrega e Validação:** Os artefatos são entregues ao usuário para validação técnica.

## Capacidades Detalhadas

- **Classificar riscos por probabilidade e impacto:** Utiliza um framework qualitativo para categorizar a severidade de cada risco.
- **Identificar vulnerabilidades processuais:** Realiza uma varredura técnica em busca de fragilidades como prescrição, prescrição intercorrente, nulidades, cerceamento de defesa.
- **Analisar risco de perda em cobrança/execução:** Avalia a probabilidade de um resultado desfavorável com base na solidez das teses e na jurisprudência.
- **Mapear riscos contratuais:** Analisa instrumentos contratuais para identificar cláusulas de alto risco, ambiguidades, gatilhos de inadimplemento.
- **Recomendar estratégias de mitigação:** Para cada risco identificado, propõe ações concretas e fundamentadas.
- **Produzir matriz de riscos visual:** Consolida a análise em um formato de tabela ou gráfico.
- **Gerar parecer de risco estruturado:** Elabora um documento técnico completo com resumo, metodologia, descrição de riscos e recomendações.

## Exemplos de Uso

### Exemplo 1: Análise de Risco em Execução de Nota Promissória

**Prompt do Usuário:**
`Analise o risco de êxito da execução de nota promissória. Anexe a cópia integral do processo de execução. Objetivo: avaliar a probabilidade de êxito, identificar vulnerabilidades processuais e gerar um parecer de risco para apresentar ao cliente.`

**Resultado Esperado:**
Um parecer estruturado contendo:
1. **Síntese do Caso:** Execução de nota promissória com alegação de vício de emissão.
2. **Matriz de Riscos:** Risco 1 (Alto/Alto): Nulidade da nota promissória por vício formal. Risco 2 (Médio/Médio): Prescrição intercorrente.
3. **Detalhamento dos Riscos:** Análise aprofundada com jurisprudência do STJ e TJ local.
4. **Estratégias de Mitigação:** Recomendações para reforçar a cobrança ou defesa.

## Melhores Práticas

- **Qualidade do Input:** A precisão da análise é diretamente proporcional à qualidade dos documentos fornecidos.
- **Ferramenta de Suporte:** Esta skill é uma ferramenta de apoio à decisão e não substitui o julgamento do advogado.
- **Escopo da Análise:** Defina claramente o escopo. Se o objetivo é analisar apenas prescrição intercorrente, informe isso à skill.
- **Confidencialidade:** A skill opera no ambiente seguro do Manus, garantindo a confidencialidade das informações.
