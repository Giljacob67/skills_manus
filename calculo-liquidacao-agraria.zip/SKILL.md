---
name: "calculo-liquidacao-agraria"
description: "Realiza cálculos complexos de liquidação e indenizações em contencioso agrário, abrangendo perdas e danos, juros, correção monetária, multas, benfeitorias e lucros cessantes, com validação de conformidade à jurisprudência do STJ."
license: "Proprietary - Uso exclusivo de Gilberto Jacob"
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: calculo-liquidacao-agraria

## Visão Geral

Esta skill fornece um framework técnico-jurídico para a apuração de valores em disputas contratuais e indenizatórias no agronegócio. Seu objetivo é estruturar cálculos de liquidação complexos, desde a aplicação de encargos moratórios até a quantificação de lucros cessantes e benfeitorias, sempre com foco na precisão técnica e na conformidade com a jurisprudência consolidada, especialmente do Superior Tribunal de Justiça (STJ). A ferramenta foi desenhada para gerar planilhas e relatórios detalhados que sirvam como fundamento para petições de liquidação de sentença, embargos à execução e pareceres técnicos.

## Workflow Principal

O uso da skill segue um processo estruturado para garantir a precisão e a rastreabilidade dos cálculos:

1.  **Definição do Escopo do Cálculo**: O usuário especifica a natureza da obrigação (e.g., rescisão de arrendamento, execução de CPR, indenização por danos) e os parâmetros de cálculo (valor principal, datas de vencimento e citação, índices de correção, taxas de juros, etc.).
2.  **Coleta de Dados**: O assistente solicita os documentos e informações essenciais, como contratos, laudos de avaliação de benfeitorias, relatórios de produtividade agrícola e decisões judiciais que fixaram os parâmetros da condenação.
3.  **Execução dos Cálculos Modulares**: Com base nos dados fornecidos, o assistente executa os módulos de cálculo necessários:
    *   Atualização monetária e juros de mora.
    *   Apuração de multas e cláusulas penais.
    *   Quantificação de indenizações por benfeitorias.
    *   Estimativa de lucros cessantes.
4.  **Validação Jurisprudencial**: O assistente realiza uma verificação cruzada dos métodos de cálculo (e.g., vedação ao anatocismo, aplicação de índices de correção) com teses firmadas pelo STJ em casos análogos.
5.  **Geração do Relatório de Liquidação**: Ao final, a skill consolida os resultados em uma planilha detalhada, acompanhada de um relatório técnico que descreve a metodologia, as fontes de dados e a fundamentação normativa e jurisprudencial para cada item apurado.

## Capacidades Detalhadas

*   **Calcular perdas e danos em ações de rescisão contratual rural**: Apura valores devidos em contratos de arrendamento, parceria agrícola, compra e venda de safra, entre outros, considerando o inadimplemento e suas consequências patrimoniais diretas.
*   **Aplicar juros legais e correção monetária**: Executa cálculos de atualização de débitos utilizando diversos indexadores (SELIC, TR, INPC, IGP-M) e taxas de juros (legais ou contratuais), conforme determinado pelo título executivo ou pela legislação aplicável.
*   **Calcular multas contratuais e cláusulas penais**: Realiza a incidência de penalidades previstas em contrato, observando eventuais limitações legais ou reduções equitativas determinadas judicialmente.
*   **Estruturar planilhas de liquidação para embargos à execução**: Monta planilhas claras e objetivas, demonstrando o valor incontroverso do débito e o excesso de execução, com detalhamento de cada rubrica (principal, juros, multas, etc.).
*   **Validar conformidade com jurisprudência STJ**: Compara a metodologia de cálculo empregada com o entendimento do STJ sobre temas críticos como a taxa de juros aplicável na ausência de pactuação, a impossibilidade de capitalização de juros (anatocismo) fora das hipóteses legais e os índices de correção monetária adequados para cada tipo de obrigação.
*   **Calcular indenizações por benfeitorias**: Quantifica o valor de benfeitorias úteis, necessárias e voluptuárias em imóveis rurais, com base em laudos de avaliação e critérios de depreciação, para fins de retenção ou indenização.
*   **Calcular lucros cessantes em operações agrícolas**: Estima a perda de receita futura decorrente de atos ilícitos ou inadimplemento contratual, como a frustração de safras ou a impossibilidade de colheita, utilizando dados históricos de produtividade e projeções de mercado.

## Exemplos de Uso

**Cenário 1: Embargos à Execução de CPR Financeira**

*   **Usuário**: "Preciso estruturar o cálculo para embargos à execução de uma CPR-F. O valor principal é de R$ 2.000.000,00, vencida em 30/05/2025. O exequente aplicou juros de 1% a.m. capitalizados mensalmente e correção pelo IGP-M. A citação ocorreu em 10/02/2026. Valide a metodologia e apure o valor que entendo devido, considerando a taxa SELIC para juros e correção, conforme jurisprudência do STJ para títulos de crédito não-bancários."
*   **Resultado Esperado**: A skill gera uma planilha comparativa. A primeira coluna mostra o cálculo do exequente, destacando a capitalização mensal de juros. A segunda coluna apresenta o cálculo correto, aplicando a taxa SELIC de forma simples (sem capitalização) desde o vencimento até a citação, e a partir daí, apenas a SELIC. O relatório anexo fundamenta a ilegalidade da capitalização de juros fora do sistema financeiro nacional e a aplicação da SELIC, citando precedentes do STJ.

**Cenário 2: Liquidação de Sentença em Ação de Rescisão de Arrendamento**

*   **Usuário**: "Prepare a liquidação de sentença em ação de rescisão de arrendamento rural. A decisão condenou o arrendatário ao pagamento de aluguéis atrasados, multa contratual de 10%, e indenização por lucros cessantes pela não colheita da safrinha de milho. Anexei o contrato, a planilha de débitos e o laudo pericial que estimou a produtividade da área em 120 sacas/ha e o preço do milho em R$ 55,00/saca."
*   **Resultado Esperado**: O assistente entrega uma planilha consolidada com três seções: 1) Débito de aluguéis, atualizado monetariamente pelo INPC e com juros de mora de 1% a.m. desde cada vencimento; 2) Multa contratual calculada sobre o débito atualizado; 3) Valor dos lucros cessantes, calculado multiplicando a área arrendada pela produtividade e pelo preço da saca, com correção monetária desde a data da colheita frustrada. O relatório final detalha cada etapa do cálculo e as premissas adotadas.

## Melhores Práticas e Considerações

*   **Precisão dos Inputs**: A qualidade do resultado depende diretamente da precisão dos dados fornecidos. Sempre informe valores nominais, datas (vencimento, citação, ajuizamento), índices e taxas de forma clara e completa.
*   **Documentação de Suporte**: Para cálculos de benfeitorias e lucros cessantes, a existência de laudos periciais, notas fiscais e relatórios técnicos é fundamental. A skill utilizará os dados desses documentos como base.
*   **Especificidade Jurisprudencial**: Ao solicitar validação jurisprudencial, indique o tribunal e, se possível, a tese ou o tema repetitivo de interesse para refinar a análise.
*   **Natureza da Ferramenta**: Esta skill é uma ferramenta de apoio técnico e não substitui a análise jurídica do caso concreto. Os cálculos são executados com base nos parâmetros fornecidos e na legislação/jurisprudência de referência, cabendo ao advogado a interpretação e a aplicação estratégica dos resultados.
