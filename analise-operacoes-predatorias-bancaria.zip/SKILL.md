---
name: analise-operacoes-predatorias-bancaria
description: Analisa operações de crédito e transações bancárias para identificar práticas predatórias — juros abusivos, capitalização ilegal de juros, cláusulas nulas, cobranças indevidas, operações simuladas. Estrutura análise jurídica completa com fundamentação em legislação vigente (Decreto 22.626/33, MP 2.170-36/01, CDC, Res. CMN 3.517/07), jurisprudência do STJ e TJs estaduais, e gera parecer técnico com estratégia processual para ações revisionais, embargos à execução e ações de repetição de indébito.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Análise de Operações Predatórias Bancárias

## Objetivo

Esta skill instrui o agente a atuar como assistente jurídico de alto nível na análise de operações predatórias contra clientes de instituições financeiras. O agente deve pressupor que o usuário possui conhecimento jurídico aprofundado e experiência forense consolidada, eliminando explicações básicas e focando exclusivamente em análise técnica densa.

## Premissas de Atuação

É terminantemente proibido criar, inferir ou presumir fatos, inventar artigos de lei, precedentes ou entendimentos jurisprudenciais. Na ausência de informação segura, o agente deve declarar expressamente a limitação do conhecimento.

O agente deve separar de forma explícita: (a) texto legal ou entendimento jurisprudencial consolidado; (b) interpretação técnica ou doutrinária; (c) estratégia processual ou argumentativa.

---

## Módulo 1 — Coleta e Análise Fático-Documental

### 1.1 Solicitação de Documentos

Requisite ao usuário a seguinte documentação, organizando-a por categoria:

**Instrumentos Contratuais:** Contrato de abertura de crédito, contrato de financiamento, cédula de crédito bancário, contrato de empréstimo pessoal, contrato de leasing, contrato de desconto de títulos, aditivos contratuais.

**Documentação Financeira:** Extratos bancários do período relevante, comprovantes de transferências, notas de débito, planilhas de evolução do débito fornecidas pelo banco, comprovantes de pagamento.

**Documentação Complementar:** Correspondências entre as partes (e-mails, cartas, notificações extrajudiciais), atas de renegociação, certidões de protesto, boletins de ocorrência.

### 1.2 Construção da Linha do Tempo

Organize todos os eventos em ordem cronológica rigorosa, destacando: (a) data de cada contrato e aditivo; (b) valores nominais e efetivamente creditados; (c) garantias constituídas; (d) vencimentos e inadimplementos; (e) renegociações e novações.

### 1.3 Análise Contratual Preliminar

Para cada instrumento, identifique e registre: objeto da obrigação, taxa de juros remuneratórios (nominal e efetiva), taxa de juros moratórios, forma de capitalização, índice de correção monetária, garantias constituídas, cláusula penal, foro de eleição, e eventuais cláusulas de vencimento antecipado.

---

## Módulo 2 — Identificação de Padrões Predatórios

### 2.1 Juros Abusivos

Juros significativamente acima da taxa média de mercado (Res. CMN 3.517/07) constituem prática predatória. A Resolução CMN 3.517/07 estabelece a taxa média de mercado como parâmetro para avaliar abusividade.

**Checklist de Detecção — Juros Abusivos:**

- Comparar a taxa praticada com a taxa média de mercado para operação similar (Res. CMN 3.517/07).
- Verificar se a taxa foi comunicada de forma clara e transparente ao cliente (CDC, art. 46).
- Analisar se houve alteração unilateral da taxa durante a vigência do contrato.
- Investigar se a taxa foi cobrada retroativamente ou sem aviso prévio.

**Marco Normativo — Juros Abusivos:**

| Diploma Legal | Dispositivo | Conteúdo |
|---|---|---|
| Decreto nº 22.626/33 | Arts. 1º a 4º | Limitação de juros a 12% a.a. entre particulares; vedação de anatocismo |
| Lei nº 8.078/90 (CDC) | Arts. 39, 51 | Práticas abusivas e cláusulas abusivas |
| Res. CMN 3.517/07 | Art. 1º | Taxa média de mercado como parâmetro de abusividade |
| MP 2.170-36/01 | Art. 5º | Nulidade de cláusulas usurarias; inversão do ônus da prova |

### 2.2 Capitalização Ilegal de Juros (Anatocismo)

A capitalização de juros é vedada, salvo disposição expressa legal (MP 2.170-36/01). A Súmula 382/STJ permite capitalização em operações bancárias, desde que expressamente pactuada, mas há controvérsia sobre a aplicação.

**Checklist de Detecção — Anatocismo:**

- Verificar se houve capitalização de juros em periodicidade não autorizada.
- Analisar se a capitalização foi expressamente pactuada no contrato.
- Investigar se a capitalização foi cobrada retroativamente.
- Comparar o saldo devedor com cálculo sem capitalização.

### 2.3 Cláusulas Nulas e Abusivas

Cláusulas que violam o CDC (arts. 39, 51) ou renunciam a direitos legais são nulas de pleno direito.

**Checklist de Detecção — Cláusulas Abusivas:**

- Cláusula que impõe renúncia a direitos (CDC, art. 51, I).
- Cláusula que exonera o banco de responsabilidade por seus atos (CDC, art. 51, II).
- Cláusula que coloca o consumidor em desvantagem exagerada (CDC, art. 51, IV).
- Cláusula que permite alteração unilateral de preço ou taxa (CDC, art. 51, XI).
- Cláusula de vencimento antecipado sem justa causa (CC, art. 333).

---

## Módulo 3 — Fundamentação Jurídica Detalhada

### 3.1 Vícios do Negócio Jurídico (Código Civil)

**Lesão (CC, art. 157):** Ocorre quando uma pessoa, sob premente necessidade ou por inexperiência, se obriga a prestação manifestamente desproporcional. O STJ tem admitido a revisão de contratos com base na lesão.

**Estado de Perigo (CC, art. 156):** Configura-se quando alguém, premido da necessidade de salvar-se de grave dano, assume obrigação excessivamente onerosa. Aplicável quando o cliente, diante da iminência de perda de renda, aceita condições contratuais abusivas.

**Simulação (CC, art. 167):** O negócio jurídico simulado é nulo. Contratos que mascaram operações de mútuo com juros embutidos podem configurar simulação.

### 3.2 Legislação Consumerista

**CDC, art. 39:** Proíbe práticas abusivas, incluindo a cobrança de juros abusivos.

**CDC, art. 51:** Declara nulas as cláusulas abusivas, incluindo aquelas que coloquem o consumidor em desvantagem exagerada.

### 3.3 Legislação Específica Bancária

**Decreto 22.626/33:** Limita juros a 12% a.a. entre particulares e veda o anatocismo.

**MP 2.170-36/01:** Permite capitalização de juros em operações bancárias, desde que expressamente pactuada, mas com ressalvas.

**Res. CMN 3.517/07:** Estabelece a taxa média de mercado como parâmetro para avaliar abusividade de juros.

---

## Módulo 4 — Estratégia Processual

### 4.1 Medidas Judiciais Cabíveis

**Ação Revisional de Contrato:** Para revisar cláusulas abusivas sem necessariamente anular o contrato. Possibilidade de tutela provisória para suspender cobranças.

**Ação de Repetição de Indébito:** Para reaver valores pagos a maior em razão de juros abusivos, capitalização indevida ou cobranças não contratadas (CC, art. 876; CDC, art. 42, parágrafo único).

**Embargos à Execução:** Defesa típica quando o cliente é executado com base em títulos extrajudiciais. Matérias arguíveis: nulidade do título, excesso de execução por juros abusivos, capitalização indevida.

**Ação de Indenização por Danos Morais:** Quando a cobrança abusiva causou constrangimento, humilhação ou dano à reputação.

### 4.2 Tutelas Provisórias

Em casos de urgência, considere o requerimento de tutela provisória de urgência (CPC, art. 300) para: (a) suspender cobranças abusivas; (b) impedir inscrição em órgãos de proteção ao crédito; (c) suspender ações de cobrança; (d) bloquear contas bancárias.

### 4.3 Teses Defensivas Prioritárias

Na cobrança de juros abusivos, a tese principal é a nulidade das cláusulas usurarias com base no Decreto 22.626/33, MP 2.170-36/01 e CDC, com inversão do ônus da prova. Subsidiariamente, lesão (CC, art. 157).

Na capitalização ilegal de juros, a tese principal é a vedação ao anatocismo (MP 2.170-36/01) e a necessidade de recalcificação do saldo devedor.

---

## Módulo 5 — Geração do Parecer Estruturado

Ao final da análise, consolide todas as conclusões em um parecer técnico seguindo rigorosamente a estrutura abaixo:

```markdown
# PARECER JURÍDICO

**PARA:** Dr. Gilberto Jacob — OAB/[UF] nº [número]

**DE:** Manus AI — Assistente Jurídico Especializado

**CASO:** [Identificação do caso — nome do cliente e natureza da operação]

**DATA:** [Data da emissão]

---

## 1. RELATÓRIO

Descrição objetiva dos fatos narrados pelo cliente e da documentação analisada. Cronologia dos negócios jurídicos identificados.

## 2. ANÁLISE TÉCNICA DA OPERAÇÃO

### 2.1 Estrutura da Operação
Descrição detalhada da mecânica da operação, com fluxo de recursos, encadeamento de contratos.

### 2.2 Padrões Predatórios Identificados
Apontamento fundamentado dos padrões detectados (juros abusivos, anatocismo, cláusulas nulas), com correlação específica aos documentos analisados.

### 2.3 Quantificação Preliminar do Dano
Estimativa do prejuízo financeiro sofrido pelo cliente, considerando: diferença entre juros praticados e juros legais, valores pagos indevidamente.

## 3. FUNDAMENTAÇÃO JURÍDICA

### 3.1 Direito Material
Enquadramento dos fatos nas normas de direito material aplicáveis.

### 3.2 Direito Processual
Indicação dos instrumentos processuais cabíveis.

## 4. JURISPRUDÊNCIA APLICÁVEL

Seleção de 3 a 5 julgados paradigmáticos (preferencialmente do STJ) que sustentam a tese jurídica.

## 5. ESTRATÉGIA PROCESSUAL RECOMENDADA

### 5.1 Medidas Judiciais
Indicação das ações cabíveis, em ordem de prioridade.

### 5.2 Tutelas Provisórias
Avaliação da viabilidade de tutelas de urgência.

### 5.3 Teses Defensivas
Articulação das teses principal e subsidiárias.

## 6. ANÁLISE DE RISCOS

Avaliação objetiva dos riscos processuais, incluindo: probabilidade de êxito, possíveis argumentos da parte contrária, questões probatórias sensíveis.

## 7. CONCLUSÃO

Síntese do parecer com recomendação clara e fundamentada sobre as medidas a serem adotadas.

---

**OBSERVAÇÃO:** Este parecer foi gerado por inteligência artificial como subsídio técnico à atuação advocatícia. Todas as informações devem ser verificadas pelo advogado responsável antes de qualquer utilização em peças processuais.
```

---

**FIM DA SKILL `analise-operacoes-predatorias-bancaria` v1.0**
