# Checklists Específicos por Tipo de Contrato

## Arrendamento Rural

- [ ] Prazo mínimo de 3 anos (art. 95, II, Estatuto da Terra)
- [ ] Preço dentro do limite de 15% do valor cadastral (art. 95, V e XI)
- [ ] Preço NÃO fixado em quantidade fixa de frutos/produtos (Dec. 59.566/66, art. 18, par. único)
- [ ] Cláusula de preferência na renovação (art. 95, IV)
- [ ] Direito de preferência na alienação do imóvel (art. 92, §3º)
- [ ] Indenização por benfeitorias úteis e necessárias assegurada (art. 95, VIII)
- [ ] Ausência de cláusula de renúncia a direitos do Estatuto da Terra (art. 13, IV)
- [ ] Obrigações de conservação do imóvel definidas
- [ ] Destinação do imóvel especificada
- [ ] Foro competente

## Parceria Agrícola

- [ ] Prazo mínimo de 3 anos (art. 96, I, Estatuto da Terra)
- [ ] Percentuais de partilha dentro dos limites legais (art. 96, VI)
- [ ] Definição clara das obrigações de cada parceiro
- [ ] Forma de apuração e divisão dos frutos
- [ ] Responsabilidade por insumos e custos operacionais
- [ ] Cláusula sobre benfeitorias
- [ ] Ausência de cláusula de renúncia a direitos

## Cédula de Produto Rural (CPR)

- [ ] Denominação "Cédula de Produto Rural" (art. 3º, I, Lei 8.929/94)
- [ ] Data de entrega do produto (art. 3º, II)
- [ ] Nome do credor e cláusula à ordem (art. 3º, III)
- [ ] Promessa pura e simples de entrega do produto (art. 3º, IV)
- [ ] Descrição do produto: tipo, qualidade, quantidade (art. 3º, V)
- [ ] Local e condições de entrega (art. 3º, VI)
- [ ] Descrição dos bens cedularmente vinculados em garantia (art. 3º, VII)
- [ ] Data e lugar de emissão (art. 3º, VIII)
- [ ] Assinatura do emitente (art. 3º, IX)
- [ ] Para CPR-F: valor de liquidação financeira e índice de preços (art. 4º-A)
- [ ] Registro em sistema autorizado pelo BACEN (CPR-F)
- [ ] Verificação de lastro: capacidade produtiva do emitente compatível com a quantidade

## CDCA (Certificado de Direitos Creditórios do Agronegócio)

- [ ] Emissão por cooperativas ou pessoas jurídicas do agronegócio (Lei 11.076/04)
- [ ] Lastro em direitos creditórios originários de negócios do agronegócio
- [ ] Registro em sistema de registro e liquidação financeira
- [ ] Valor nominal, data de vencimento, taxa de juros
- [ ] Garantias vinculadas
- [ ] Verificação da existência e regularidade dos créditos lastro

## Financiamento Rural (Cédula de Crédito Rural)

- [ ] Enquadramento no SNCR (Sistema Nacional de Crédito Rural)
- [ ] Finalidade: custeio, investimento ou comercialização
- [ ] Juros remuneratórios dentro dos limites do CMN (DL 167/67, art. 5º)
- [ ] Juros moratórios limitados a 1% a.a. (DL 167/67, art. 5º, par. único)
- [ ] Verificação de capitalização de juros (vedação ao anatocismo)
- [ ] Garantias proporcionais ao valor do financiamento
- [ ] Direito à prorrogação em caso de frustração de safra (Lei 8.171/91, art. 9º)
- [ ] Verificação de operação mata-mata (desvio de finalidade)

## Compra e Venda de Imóvel Rural

- [ ] Matrícula atualizada do imóvel
- [ ] CCIR quitado (Lei 4.947/66, art. 22)
- [ ] CAR inscrito (Lei 12.651/12)
- [ ] ITR regular (CND ou CPD-EN)
- [ ] Georreferenciamento averbado (Lei 10.267/01)
- [ ] Verificação de ônus e gravames na matrícula
- [ ] Certidões negativas dos vendedores
- [ ] Respeito à fração mínima de parcelamento
- [ ] Verificação de restrições a estrangeiros (Lei 5.709/71)
- [ ] Cláusula sobre reserva legal e APP
