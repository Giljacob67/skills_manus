# Legislação-Chave para Análise de Contratos Rurais

## Preço e Pagamento {#preco-pagamento}

- **Estatuto da Terra (Lei 4.504/64), art. 95, V e XI**: O preço do arrendamento não pode ser superior a 15% do valor cadastral do imóvel (terras de 1ª classe) ou percentuais inferiores conforme a classe de terra.
- **Decreto 59.566/66, art. 18, parágrafo único**: É vedada a fixação do preço do arrendamento em quantidade fixa de frutos ou produtos, ou seu equivalente em dinheiro.
- **Decreto-Lei 167/67, art. 5º**: Juros remuneratórios em cédulas de crédito rural são fixados pelo CMN.
- **Lei 8.929/94, arts. 1º-4º**: Requisitos de validade da CPR (descrição do produto, quantidade, qualidade, local e condições de entrega).
- **Lei 14.905/2024**: Novo regime de juros moratórios legais (taxa SELIC menos IPCA).

## Prazos e Renovação {#prazos-renovacao}

- **Estatuto da Terra, art. 95, II**: Prazo mínimo de 3 anos para arrendamento.
- **Estatuto da Terra, art. 95, IV**: Direito de preferência do arrendatário na renovação, mediante notificação com 6 meses de antecedência.
- **Decreto 59.566/66, art. 22**: Renovação automática do contrato se não houver notificação tempestiva.
- **Estatuto da Terra, art. 96, I**: Prazo mínimo de 3 anos para parceria agrícola.

## Benfeitorias {#benfeitorias}

- **Estatuto da Terra, art. 95, VIII**: Direito à indenização por benfeitorias úteis e necessárias, com direito de retenção.
- **Código Civil, arts. 1.219-1.220**: Regime geral de benfeitorias (possuidor de boa-fé e de má-fé).
- **STJ**: Nulidade da cláusula de renúncia à indenização por benfeitorias necessárias e úteis em contratos agrários (REsp 1.336.293/RS).

## Garantias {#garantias}

- **Lei 9.514/97**: Alienação fiduciária de imóveis — procedimento de consolidação da propriedade.
- **Código Civil, arts. 1.419-1.510**: Regime geral de garantias reais (penhor, hipoteca, anticrese).
- **Decreto-Lei 167/67, arts. 14-16**: Penhor rural (agrícola e pecuário).
- **CF, art. 5º, XXVI**: Impenhorabilidade da pequena propriedade rural familiar (até 4 módulos fiscais).
- **STF, Tema 961**: Impenhorabilidade alcança propriedades de mais de um terreno, desde que contínuos e com área total inferior a 4 módulos fiscais.

## Cláusulas Abusivas {#clausulas-abusivas}

- **Estatuto da Terra, art. 13, IV**: São nulas as cláusulas que importem em renúncia a direitos assegurados pelo Estatuto da Terra.
- **Decreto 59.566/66, art. 13**: Nulidade de cláusulas que contrariem disposições legais de ordem pública.
- **Código Civil, art. 421**: Função social do contrato — limite à liberdade contratual.
- **Código Civil, art. 422**: Boa-fé objetiva nas relações contratuais.
- **Código Civil, arts. 156-157**: Estado de perigo e lesão como vícios do negócio jurídico.
- **Código Civil, art. 478**: Resolução por onerosidade excessiva.
- **CDC, arts. 39 e 51**: Práticas abusivas e cláusulas abusivas (aplicável quando o produtor for destinatário final).
