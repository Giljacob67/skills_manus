---
name: analise-contratos-rurais
description: Realiza análise jurídica estruturada de contratos do agronegócio, como arrendamento, parceria, CPR, CDCA, financiamento e compra e venda. Use quando o usuário fornecer um arquivo de contrato rural e solicitar análise de riscos, validação de cláusulas ou um parecer técnico.
license: Apache-2.0
metadata:
  author: Gilberto Jacob, via Manus
  version: "1.1"
allowed-tools: file(read) shell
---

# Skill: Análise Estruturada de Contratos Rurais

Esta skill capacita o agente a realizar uma análise técnica e aprofundada de contratos agrários, seguindo um roteiro estruturado para identificar elementos essenciais, riscos, e conformidade legal, culminando na geração de um parecer jurídico. A análise se baseia em um framework legislativo específico, detalhado nos arquivos de referência.

## Estrutura da Skill

Esta skill utiliza o princípio de *Progressive Disclosure*. A informação é organizada em níveis para otimizar a performance do agente.

```
analise-contratos-rurais/
├── SKILL.md          # Instruções principais e fluxo de trabalho (este arquivo)
└── references/
    ├── legislacao-chave.md   # Detalhamento dos pontos críticos por lei
    └── checklists-especificos.md # Checklists detalhados por tipo de contrato
```

## Processo de Análise (Workflow Principal)

O agente deve seguir este processo passo a passo, marcando cada item como concluído.

**Fase 1: Setup e Classificação**
- [ ] 1.1. Confirmar o recebimento do arquivo do contrato e ler seu conteúdo integralmente com a ferramenta `file(read)`.
- [ ] 1.2. Classificar o tipo de contrato. Em caso de dúvida, questione o usuário. Tipos primários:
    - [ ] Arrendamento Rural
    - [ ] Parceria Agrícola
    - [ ] Cédula de Produto Rural (CPR)
    - [ ] Certificado de Direitos Creditórios do Agronegócio (CDCA)
    - [ ] Financiamento Rural (e Cédula de Crédito Rural)
    - [ ] Compra e Venda de Imóvel Rural
- [ ] 1.3. Com base na classificação, consultar o checklist específico em `references/checklists-especificos.md`.

**Fase 2: Extração e Validação Estrutural**
- [ ] 2.1. Extrair e qualificar as **Partes**.
- [ ] 2.2. Extrair e descrever o **Objeto** (imóvel, produto, crédito).
- [ ] 2.3. Extrair **Prazo**, **Valor** e **Forma de Pagamento**.
- [ ] 2.4. Extrair e descrever as **Garantias**.

**Fase 3: Análise de Conformidade e Riscos (Core da Skill)**
- [ ] 3.1. **Conformidade Legal:** Validar as cláusulas extraídas contra os requisitos legais. Para cada ponto, consultar `references/legislacao-chave.md`.
    - [ ] Preço e Pagamento: [Verificar Fundamento Legal](references/legislacao-chave.md#preco-pagamento)
    - [ ] Prazos e Renovação: [Verificar Fundamento Legal](references/legislacao-chave.md#prazos-renovacao)
    - [ ] Benfeitorias: [Verificar Fundamento Legal](references/legislacao-chave.md#benfeitorias)
    - [ ] Garantias: [Verificar Fundamento Legal](references/legislacao-chave.md#garantias)
- [ ] 3.2. **Identificação de Cláusulas Abusivas:** Buscar por cláusulas que imponham renúncia a direitos, obrigações desproporcionais ou que violem a boa-fé objetiva. [Consultar Padrões](references/legislacao-chave.md#clausulas-abusivas).
- [ ] 3.3. **Avaliação de Riscos:** Sintetizar os riscos de nulidade, execução patrimonial, inadimplemento e operacionais identificados.

**Fase 4: Geração do Parecer**
- [ ] 4.1. Utilizar o template abaixo para estruturar o parecer final.
- [ ] 4.2. Preencher cada seção do parecer com as informações apuradas, mantendo linguagem técnica, precisa e objetiva.
- [ ] 4.3. Entregar o parecer final ao usuário em um arquivo `.md`.

## Template do Parecer Jurídico

```markdown
# Parecer de Análise Contratual

**Contrato Analisado:** [Nome do Contrato, ex: Contrato de Arrendamento Rural]
**Data da Análise:** [Inserir Data]

## 1. Resumo Estruturado do Contrato

| Elemento          | Descrição                                                                   |
|-------------------|-----------------------------------------------------------------------------|
| **Tipo de Contrato**  | [Ex: Arrendamento Rural]                                                    |
| **Partes**        | **Ativa:** [Nome e qualificação] <br> **Passiva:** [Nome e qualificação]      |
| **Objeto**        | [Descrição detalhada do imóvel (matrícula, CCIR, CAR), produto ou crédito]                         |
| **Prazo**         | Início em DD/MM/AAAA, término em DD/MM/AAAA. [Comentar sobre renovação automática] |
| **Valor e Pagamento** | [Detalhar o preço, indexador, forma de pagamento, juros, etc.]                         |
| **Garantias**     | [Tipo de garantia, descrição do bem e status do registro. Ex: Alienação Fiduciária da Matrícula X, pendente de averbação] |

## 2. Análise de Cláusulas Críticas e Conformidade Legal

Nesta seção, são destacadas e comentadas as cláusulas que exigem maior atenção por seu potencial de gerar conflitos, confrontando-as com o ordenamento jurídico aplicável.

- **Cláusula X (Do Preço):** Análise técnica da cláusula. Ex: "A Cláusula 3.1, ao fixar o pagamento em 500 sacas de soja por alqueire, confronta diretamente a vedação expressa no art. 18, parágrafo único, do Decreto nº 59.566/66, sendo, portanto, nula de pleno direito. A nulidade pode ser arguida a qualquer tempo, implicando a necessidade de arbitramento judicial do valor do arrendamento caso não haja acordo entre as partes."

- **Cláusula Y (Das Garantias):** Análise da formalização e proporcionalidade. Ex: "A alienação fiduciária do imóvel rural, prevista na Cláusula 8, embora legal (Lei 9.514/97), representa um risco elevado de execução extrajudicial. É imperativo verificar se a averbação na matrícula do imóvel foi realizada e se o valor do bem não é desproporcional ao da dívida garantida, o que poderia configurar abuso de direito."

## 3. Matriz de Riscos Identificados

| Risco Identificado        | Nível de Risco (Alto/Médio/Baixo) | Fundamento e Consequências Potenciais                                                                                                                              |
|---------------------------|-----------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Nulidade de Cláusula**  | Alto                              | A cláusula de preço em produto é nula (Dec. 59.566/66, art. 18). Risco de ação revisional para arbitramento de valor, com impacto retroativo no fluxo de caixa.        |
| **Execução Extrajudicial**| Alto                              | A alienação fiduciária permite a consolidação da propriedade pelo credor de forma célere, com pouca margem para defesa judicial em caso de inadimplemento.             |
| **Renovação Automática**  | Médio                             | A ausência de notificação prévia em até 6 meses antes do término, conforme art. 95, IV do Estatuto da Terra, implica renovação automática sob as mesmas condições. |

## 4. Recomendações Estratégicas

1.  **Ação Imediata (Notificação):** Recomenda-se a notificação extrajudicial da outra parte para, no prazo de 15 dias, celebrar termo aditivo visando à retificação da cláusula de preço, convertendo-a para valor pecuniário, sob pena de serem tomadas as medidas judiciais cabíveis para declaração de sua nulidade.

2.  **Análise de Garantias:** Sugere-se a obtenção de uma certidão de inteiro teor atualizada da matrícula do imóvel para confirmar o registro da alienação fiduciária e a existência de outras averbações que possam impactar a garantia.

3.  **Planejamento de Longo Prazo:** Caso o interesse seja na não renovação do contrato ao final do prazo, é crucial enviar a notificação de retomada com 6 meses de antecedência, de forma comprovada, para evitar a renovação automática compulsória ditada pelo Estatuto da Terra.

**Disclaimer:** Este parecer é uma análise técnica preliminar baseada no documento fornecido e não substitui uma consulta jurídica completa, que pode depender de informações e documentos adicionais. A análise de risco é baseada na legislação e jurisprudência majoritária até a presente data.
```
