---
name: "analise-risco-agraria"
description: "Executa análise de risco jurídico em operações e contencioso agrário, classificando probabilidade e impacto, identificando vulnerabilidades processuais e contratuais, e recomendando estratégias de mitigação com geração de parecer estruturado."
license: "Proprietary - Uso exclusivo de Gilberto Jacob"
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: analise-risco-agraria

## Visão Geral

Esta skill atua como uma ferramenta de diagnóstico jurídico, especializada na análise e quantificação de riscos em operações e litígios do agronegócio. Seu objetivo é fornecer ao advogado uma avaliação técnica, estruturada e fundamentada sobre as vulnerabilidades e potenciais impactos financeiros ou operacionais de um determinado caso ou contrato. A skill traduz cenários complexos em dados organizados, como matrizes de risco e pareceres, para apoiar a tomada de decisão estratégica, a negociação e a definição de táticas processuais.

## Workflow Principal

O processo de análise de risco é conduzido em etapas sequenciais para garantir uma avaliação completa e precisa.

1.  **Ativação e Input de Dados**: O usuário invoca a skill `analise-risco-agraria` e fornece o escopo da análise, que pode ser um processo judicial, um contrato, uma operação de M&A ou uma consulta específica. É fundamental o fornecimento de documentos pertinentes (e.g., cópia do processo, contratos, matrículas, Cédula de Produto Rural).

2.  **Processamento e Análise Preliminar**: A skill processa os documentos e o contexto fornecido para identificar os pontos críticos. Nesta fase, ela mapeia os fatos, as relações jurídicas e as teses centrais (no caso de contencioso).

3.  **Identificação e Classificação de Riscos**: Cada risco potencial é identificado e classificado segundo uma matriz de probabilidade (Alta, Média, Baixa) e impacto (Alto, Médio, Baixo). A classificação é fundamentada em análise normativa e, quando aplicável, em pesquisa jurisprudencial direcionada.

4.  **Geração dos Produtos de Análise**: Com base na classificação, a skill gera dois artefatos principais:
    *   Uma **Matriz de Riscos** visual, que oferece um panorama rápido e claro dos pontos mais críticos.
    *   Um **Parecer de Risco Estruturado**, detalhando cada risco, sua fundamentação, as vulnerabilidades identificadas e as estratégias de mitigação recomendadas.

5.  **Entrega e Validação**: Os artefatos são entregues ao usuário para validação técnica. O advogado pode então utilizar o material como suporte para pareceres a clientes, definição de estratégia processual ou como base para negociações.

## Capacidades Detalhadas

-   **Classificar riscos por probabilidade e impacto**: Utiliza um framework qualitativo para categorizar a severidade de cada risco, permitindo a priorização de ações. A probabilidade é aferida com base na solidez das teses e na jurisprudência, enquanto o impacto considera as consequências financeiras e operacionais.

-   **Identificar vulnerabilidades processuais**: Realiza uma varredura técnica no processo em busca de fragilidades como prescrição, decadência, nulidades (de citação, de título), cerceamento de defesa e outras questões que possam reverter o curso da ação.

-   **Analisar risco de perda em contencioso**: Foca especificamente em processos judiciais, avaliando a probabilidade de um resultado desfavorável com base na consistência das provas, nas teses jurídicas apresentadas e no alinhamento com a jurisprudência dos tribunais competentes.

-   **Mapear riscos contratuais**: Analisa instrumentos contratuais (compra e venda, arrendamento, parceria, CPR, etc.) para identificar cláusulas de alto risco, ambiguidades, gatilhos de inadimplemento, cláusulas de rescisão e exequibilidade de garantias.

-   **Recomendar estratégias de mitigação**: Para cada risco identificado, a skill propõe ações concretas e fundamentadas para neutralizá-lo ou reduzir seu impacto. As recomendações podem incluir desde a renegociação de cláusulas até a produção de provas específicas ou a adoção de novas teses jurídicas.

-   **Produzir matriz de riscos visual**: Consolida a análise em um formato de tabela ou gráfico que cruza probabilidade e impacto, facilitando a comunicação do diagnóstico para o cliente final e a definição de prioridades.

-   **Gerar parecer de risco estruturado**: Elabora um documento técnico completo, contendo o resumo do caso/operação, a metodologia de análise, a descrição detalhada de cada risco, a matriz de riscos e as recomendações estratégicas.

## Exemplos de Uso

### Exemplo 1: Análise de Risco em Embargos à Execução

**Prompt do Usuário:**
`> manus, utilize a skill analise-risco-agraria. Anexe a cópia integral dos embargos à execução e do processo de execução. O objetivo é avaliar a probabilidade de êxito dos embargos, identificar as principais vulnerabilidades processuais da execução e gerar um parecer de risco para apresentar ao cliente.`

**Resultado Esperado:**
Um parecer estruturado contendo:
1.  **Síntese do Caso**: Execução de CPR-F com alegação de nulidade por vício de emissão.
2.  **Matriz de Riscos**: 
    - Risco 1 (Alto/Alto): Acolhimento da tese de nulidade da CPR. 
    - Risco 2 (Médio/Baixo): Condenação por litigância de má-fé.
    - Risco 3 (Baixo/Médio): Anulação de ato de penhora por vício formal.
3.  **Detalhamento dos Riscos**: Análise aprofundada de cada ponto, com citação de jurisprudência do tribunal local sobre a matéria.
4.  **Estratégias de Mitigação**: Recomendações para reforçar a defesa, como a juntada de documentos complementares e a preparação para uma eventual sustentação oral focada na tese principal.

## Melhores Práticas e Considerações

-   **Qualidade do Input**: A precisão da análise é diretamente proporcional à qualidade e completude dos documentos fornecidos. Informações parciais ou desatualizadas podem levar a uma avaliação de risco imprecisa.
-   **Ferramenta de Suporte**: Esta skill é uma ferramenta de apoio à decisão e não substitui o julgamento e a experiência do advogado. Os resultados devem ser sempre revisados e validados pelo profissional.
-   **Escopo da Análise**: Defina claramente o escopo da análise. Se o objetivo é analisar apenas o risco de prescrição, informe isso à skill para que ela possa focar seus recursos de forma mais eficiente.
-   **Confidencialidade**: A skill opera no ambiente seguro do Manus, garantindo a confidencialidade das informações processuais e contratuais fornecidas.
