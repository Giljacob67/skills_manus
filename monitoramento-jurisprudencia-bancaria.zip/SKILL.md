---
name: monitoramento-jurisprudencia-bancaria
description: Monitora continuamente a jurisprudência bancária em tribunais selecionados, identifica precedentes relevantes, alerta sobre mudanças de entendimento e gera relatórios periódicos classificados por impacto.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Monitoramento de Jurisprudência Bancária

## 1. Overview

Esta skill realiza um monitoramento sistemático e contínuo da jurisprudência relacionada ao Direito Bancário nos principais tribunais do país (STJ, STF e TJs estaduais). O objetivo é identificar, analisar e reportar decisões recentes, mudanças de entendimento e novos precedentes sobre temas críticos, fornecendo ao advogado uma ferramenta estratégica para antecipação de riscos e oportunidades.

A skill é projetada para ser executada de forma autônoma (agendada) ou sob demanda, culminando na produção de um relatório analítico.

## 2. When to Use

Utilize esta skill para:

- **Manter-se atualizado** sobre as últimas decisões em matéria bancária sem a necessidade de pesquisa manual extensiva.
- **Detectar mudanças de posicionamento** dos tribunais em teses jurídicas relevantes para a sua prática.
- **Identificar precedentes estratégicos** que possam ser aplicados em casos concretos.
- **Analisar divergências jurisprudenciais** entre diferentes tribunais.
- **Produzir inteligência jurídica** para clientes, como parte de um serviço de consultoria preventiva.

## 3. How to Use

A skill opera em um fluxo de trabalho automatizado, que pode ser agendado ou invocado manualmente.

### Gatilhos (Triggers)

- **Agendado:** A skill pode ser configurada para rodar em intervalos definidos (e.g., semanalmente).
- **Manual:** O usuário pode invocar a skill com um prompt direto.

### Fluxo de Execução

**Etapa 1: Pesquisa (Search)**
- A skill utiliza a ferramenta `search` para consultar portais de tribunais, diários de justiça eletrônicos e bases de dados jurídicas.
- As queries são construídas a partir dos temas críticos definidos:
  - `juros abusivos operações bancárias`
  - `capitalização de juros anatocismo`
  - `prescrição intercorrente execução`
  - `nulidade duplicata nota promissória`
  - `embargos à execução juros`
  - `taxa média de mercado juros`
  - `cláusulas abusivas contrato bancário`
  - `responsabilidade civil bancária`

**Etapa 2: Análise e Classificação (Analysis & Classification)**
- Para cada resultado relevante, a skill utiliza o `browser` para acessar a URL e extrair o inteiro teor da decisão.
- O conteúdo é analisado para:
  - **Extrair a tese jurídica central:** Qual foi o entendimento firmado?
  - **Verificar aderência aos temas críticos:** A decisão se encaixa em um dos tópicos monitorados?
  - **Identificar o tribunal e a turma/câmara julgadora.**
  - **Avaliar o impacto:** A decisão tem potencial para alterar práticas, criar precedentes ou impactar um grande número de casos? A classificação é feita em três níveis:
    - **Alto:** Mudança de jurisprudência consolidada, decisão de órgão especial, repercussão geral, etc.
    - **Médio:** Reforça entendimento existente, mas com novos fundamentos.
    - **Baixo:** Decisão de caso isolado, sem grande inovação.
  - **Sinalizar divergência:** O entendimento diverge de outro tribunal relevante?

**Etapa 3: Geração do Relatório (Report Generation)**
- As informações coletadas e analisadas são consolidadas em um relatório estruturado em Markdown.

## 4. Output Exemplo (Estrutura do Relatório)

```markdown
# Relatório de Monitoramento de Jurisprudência Bancária

**Período de Análise:** DD/MM/AAAA a DD/MM/AAAA

---

## Decisões de Alto Impacto

### 1. Juros Abusivos em Operações Bancárias (STJ)

- **Processo:** REsp X.XXX.XXX/XX
- **Tese Firmada:** O STJ reafirmou que juros significativamente acima da taxa média de mercado (Res. CMN 3.517/07) são abusivos e podem ser revisados judicialmente com base no CDC.
- **Análise de Impacto:** Consolida a proteção do consumidor e limita o alcance de cláusulas de juros em contratos bancários. Alerta para revisão de contratos com juros acima da taxa média.
- **Link:** [URL da decisão]

---

## Decisões de Médio Impacto

### 1. Capitalização de Juros em Contrato Bancário (TJSP)

- **Processo:** Apelação Cível n.º XXXX-XX.XXXX.X.XX.XXXX
- **Tese Firmada:** O TJSP manteve a capitalização de juros conforme Súmula 382/STJ, desde que expressamente pactuada.
- **Análise de Impacto:** Reforça a Súmula 382/STJ, mas com ressalvas sobre a necessidade de pactuação expressa. Risco para contratos com capitalização não explícita.
- **Link:** [URL da decisão]

---

## Divergências Notáveis

### 1. Prescrição Intercorrente em Execução de Duplicata

- **Posição STJ:** Prescrição intercorrente (art. 921, CPC) é aplicável a execuções de duplicata após 1 ano de inatividade processual.
- **Posição TJSP:** Tende a ser mais restritiva, exigindo demonstração clara de inatividade absoluta.
- **Análise:** A divergência abre espaço para discussão em recursos especiais e exige estratégia processual adaptada a cada jurisdição.

---

## Recomendações Estratégicas

1. **Ação Imediata:** [Recomendações para clientes ou estratégia processual]
2. **Monitoramento Contínuo:** [Temas a acompanhar nos próximos meses]
3. **Revisão de Contratos:** [Cláusulas que podem ser impactadas pelas novas decisões]
```

## 5. Limitações

- A skill depende da disponibilidade e do formato das informações nos sites dos tribunais.
- A análise de "impacto" é uma avaliação técnica baseada em critérios predefinidos, mas a interpretação final cabe ao advogado.
- A skill não substitui a leitura aprofundada do inteiro teor das decisões mais estratégicas.

## 6. Temas Prioritários de Monitoramento

- Juros abusivos em operações bancárias
- Capitalização de juros (anatocismo)
- Prescrição intercorrente em execução de títulos
- Nulidade de duplicata, nota promissória, cheque
- Embargos à execução (juros, prescrição, vício formal)
- Responsabilidade civil bancária
- Cláusulas abusivas em contratos bancários
- Juros moratórios e taxa média de mercado
- Operações de crédito e financiamento
- Contratos de leasing e desconto de títulos

---

**FIM DA SKILL `monitoramento-jurisprudencia-bancaria` v1.0**
