---
name: analise-contratos-bancarios
description: Realiza análise jurídica estruturada de contratos bancários, incluindo operações de crédito, financiamentos, empréstimos, contratos de abertura de crédito, cédulas de crédito bancário, e títulos de crédito (duplicata, nota promissória, cheque). Identifica cláusulas abusivas, juros ilegais, e gera parecer técnico com recomendações.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Análise de Contratos Bancários

Esta skill capacita o agente a realizar uma análise técnica e aprofundada de contratos bancários, seguindo um roteiro estruturado para identificar elementos essenciais, riscos, conformidade legal e cláusulas abusivas, culminando na geração de um parecer jurídico.

## Processo de Análise (Workflow Principal)

O agente deve seguir este processo passo a passo:

**Fase 1: Setup e Classificação**
- [ ] Confirmar o recebimento do arquivo do contrato e ler seu conteúdo integralmente.
- [ ] Classificar o tipo de contrato. Tipos primários:
    - [ ] Contrato de Abertura de Crédito
    - [ ] Contrato de Financiamento (Pessoa Física e Jurídica)
    - [ ] Cédula de Crédito Bancário (CCB)
    - [ ] Contrato de Empréstimo Pessoal
    - [ ] Contrato de Leasing
    - [ ] Contrato de Desconto de Títulos
    - [ ] Contrato de Mútuo Bancário

**Fase 2: Extração e Validação Estrutural**
- [ ] Extrair e qualificar as **Partes**.
- [ ] Extrair e descrever o **Objeto** (crédito, financiamento, taxa).
- [ ] Extrair **Prazo**, **Valor** e **Forma de Pagamento**.
- [ ] Extrair e descrever as **Garantias**.
- [ ] Extrair **Taxas de Juros** (remuneratórios e moratórios).
- [ ] Extrair **Encargos Adicionais** (IOF, TAC, seguro, etc.).

**Fase 3: Análise de Conformidade e Riscos (Core da Skill)**
- [ ] **Conformidade Legal:** Validar as cláusulas extraídas contra os requisitos legais.
    - [ ] Juros: Limite de 12% a.a. (Decreto 22.626/33), taxa média de mercado (Res. CMN 3.517/07)
    - [ ] Capitalização de Juros: Vedação ao anatocismo (MP 2.170-36/01)
    - [ ] Encargos: Transparência e razoabilidade
    - [ ] Garantias: Proporcionalidade ao valor do crédito
    - [ ] Cláusulas de Vencimento Antecipado: Requisitos legais
- [ ] **Identificação de Cláusulas Abusivas:** Buscar por cláusulas que violem o CDC (arts. 39, 51), renúncia a direitos, obrigações desproporcionais.
- [ ] **Avaliação de Riscos:** Sintetizar os riscos de nulidade, execução patrimonial, inadimplemento e operacionais.

**Fase 4: Geração do Parecer**
- [ ] Utilizar o template abaixo para estruturar o parecer final.
- [ ] Preencher cada seção do parecer com as informações apuradas.
- [ ] Entregar o parecer final ao usuário em um arquivo `.md`.

## Template do Parecer Jurídico

```markdown
# Parecer de Análise Contratual Bancária

**Contrato Analisado:** [Nome do Contrato]
**Data da Análise:** [Inserir Data]

## 1. Resumo Estruturado do Contrato

| Elemento          | Descrição                                                                   |
|-------------------|-----------------------------------------------------------------------------|
| **Tipo de Contrato**  | [Ex: Contrato de Abertura de Crédito]                                      |
| **Partes**        | **Credor:** [Nome e CNPJ do banco] <br> **Devedor:** [Nome e CPF/CNPJ]      |
| **Objeto**        | [Descrição detalhada do crédito, financiamento ou operação]                 |
| **Valor**         | R$ [Valor nominal]                                                          |
| **Prazo**         | Início em DD/MM/AAAA, término em DD/MM/AAAA                                 |
| **Juros Remuneratórios** | [Taxa nominal e efetiva, período de capitalização]                  |
| **Juros Moratórios** | [Taxa, período de incidência]                                              |
| **Encargos Adicionais** | [IOF, TAC, seguro, etc.]                                                   |
| **Garantias**     | [Tipo de garantia, descrição do bem e status do registro]                   |

## 2. Análise de Cláusulas Críticas e Conformidade Legal

Nesta seção, são destacadas e comentadas as cláusulas que exigem maior atenção.

- **Cláusula X (Das Taxas de Juros):** Análise técnica. Ex: "A Cláusula 3.1 estabelece juros remuneratórios de 2,5% a.m., correspondendo a 34,49% a.a., superior à taxa média de mercado para operações similares (Res. CMN 3.517/07). Risco de revisão judicial com base no CDC, art. 51, IV."

- **Cláusula Y (Das Garantias):** Análise da formalização e proporcionalidade. Ex: "A alienação fiduciária do imóvel, embora legal (Lei 9.514/97), representa um risco elevado de execução extrajudicial. Verificar se a averbação foi realizada e se o valor do bem não é desproporcional ao da dívida."

## 3. Matriz de Riscos Identificados

| Risco Identificado        | Nível de Risco | Fundamento e Consequências Potenciais                                                                              |
|---------------------------|----------------|--------------------------------------------------------------------------------------------------------------------|
| **Juros Acima da Taxa Média**  | Alto           | Risco de revisão judicial com base no CDC e Res. CMN 3.517/07. Possível redução de juros com efeito retroativo.    |
| **Capitalização de Juros**     | Alto           | Vedação ao anatocismo (MP 2.170-36/01). Risco de nulidade da cláusula e recalcificação do saldo devedor.           |
| **Encargos Não Transparentes** | Médio          | Violação do CDC, art. 46. Risco de ação revisional para exclusão de encargos abusivos.                             |
| **Vencimento Antecipado**      | Médio          | Verificar se há cláusula de vencimento antecipado e se atende aos requisitos legais (CC, art. 333).                |

## 4. Recomendações Estratégicas

1. **Ação Imediata (Se Credor):** [Recomendações para cobrança ou execução]
2. **Ação Imediata (Se Devedor):** [Recomendações para defesa ou revisão]
3. **Análise de Garantias:** [Verificações adicionais necessárias]
4. **Planejamento de Longo Prazo:** [Estratégia processual recomendada]

**Disclaimer:** Este parecer é uma análise técnica preliminar baseada no documento fornecido e não substitui uma consulta jurídica completa.
```

## Melhores Práticas

- **Precisão dos Inputs:** A qualidade do resultado depende da precisão dos dados fornecidos.
- **Documentação de Suporte:** Sempre solicitar contrato integral, extratos, comprovantes de pagamento.
- **Especificidade Jurisprudencial:** Indicar o tribunal e, se possível, a tese de interesse para refinar a análise.
- **Natureza da Ferramenta:** Esta skill é uma ferramenta de apoio técnico e não substitui a análise jurídica do caso concreto.
