---
name: "analise-loteamentos-rurais"
description: "Realiza análise de viabilidade jurídica de loteamentos rurais, validando conformidade com a legislação de parcelamento do solo, Estatuto da Terra, restrições a estrangeiros e normas ambientais, com emissão de parecer."
license: "Proprietary - Uso exclusivo de Gilberto Jacob"
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: analise-loteamentos-rurais

## Visão Geral

Esta skill realiza uma análise jurídica completa sobre a viabilidade de loteamentos em áreas rurais. O objetivo é fornecer um diagnóstico técnico-jurídico que identifique a conformidade do empreendimento com a legislação aplicável, avalie os riscos associados e fundamente a emissão de um parecer de viabilidade. A análise abrange o parcelamento do solo, restrições a estrangeiros, legislação agrária e ambiental, além da estrutura contratual.

## Workflow Principal

O workflow foi desenhado para garantir uma análise estruturada e exaustiva, culminando em um parecer técnico fundamentado.

1.  **Coleta de Dados e Documentação:** O usuário fornece a matrícula do imóvel, o projeto do loteamento, o memorial descritivo e, se houver, a minuta do contrato de compra e venda.
2.  **Análise Normativa Estruturada:** A skill executa uma sequência de verificações, cruzando os dados do empreendimento com as seguintes bases legais:
    *   **Parcelamento do Solo:** Análise da Lei nº 6.766/79 e sua aplicabilidade analógica, com foco nos requisitos urbanísticos, áreas institucionais e aprovações necessárias.
    *   **Legislação Agrária:** Verificação do respeito à fração mínima de parcelamento (módulo rural), descaracterização do imóvel rural (art. 53 do Decreto-Lei nº 3.365/41) e conformidade com o Estatuto da Terra (Lei nº 4.504/64).
    *   **Restrições a Estrangeiros:** Cruzamento com a Lei nº 5.709/71 para identificar limitações à aquisição de lotes por pessoas físicas ou jurídicas estrangeiras.
    *   **Legislação Ambiental:** Análise das áreas de preservação permanente (APP), reserva legal, e a necessidade de licenciamento ambiental, conforme o Código Florestal (Lei nº 12.651/2012) e resoluções CONAMA.
3.  **Análise Contratual:** Revisão da minuta do contrato de compra e venda para identificar cláusulas de risco, conformidade com o Código de Defesa do Consumidor e garantias para o adquirente e o loteador.
4.  **Identificação de Riscos:** Com base nas análises anteriores, a skill consolida um mapa de riscos, classificando as contingências como baixas, médias ou altas, e apontando as possíveis consequências (e.g., nulidade do loteamento, responsabilidade civil/ambiental, multas).
5.  **Geração do Parecer:** A skill sintetiza todos os pontos analisados em um parecer de viabilidade jurídica, que inclui a fundamentação legal, a análise dos riscos e uma conclusão objetiva sobre a factibilidade do empreendimento.

## Capacidades Detalhadas

*   **Validar conformidade com Lei 6.766/79:** Examina a aplicação analógica da lei de parcelamento do solo urbano a loteamentos rurais, verificando requisitos como aprovação municipal, infraestrutura mínima e destinação de áreas públicas.
*   **Analisar restrições da Lei 5.709/71:** Identifica se o projeto prevê a venda a estrangeiros e analisa as implicações legais, incluindo a necessidade de autorização do INCRA ou do Congresso Nacional.
*   **Verificar conformidade com Estatuto da Terra:** Assegura que o parcelamento não infrinja as normas sobre a função social da propriedade e o módulo de exploração rural, prevenindo a criação de minifúndios improdutivos.
*   **Identificar riscos de nulidade do loteamento:** Mapeia pontos críticos que podem levar à nulidade do registro do loteamento, como a ausência de aprovações, desrespeito a áreas protegidas ou fraude à lei.
*   **Analisar questões ambientais:** Realiza uma varredura completa das obrigações ambientais, incluindo a demarcação correta de APPs, a averbação da Reserva Legal e a verificação da existência e validade das licenças ambientais aplicáveis.
*   **Verificar infraestrutura exigida e responsabilidades:** Checa as obrigações do loteador quanto à implantação de infraestrutura (vias de acesso, energia, saneamento) e se estas estão devidamente registradas no memorial descritivo e no contrato.
*   **Analisar contratos de compra e venda:** Efetua uma análise crítica das cláusulas contratuais, focando em aspectos como preço, forma de pagamento, rescisão, direito de arrependimento e transferência de posse e propriedade.
*   **Gerar parecer de viabilidade jurídica:** Consolida toda a análise em um documento técnico, estruturado para suportar a tomada de decisão, com conclusões claras e fundamentadas na legislação e jurisprudência.

## Exemplos de Uso

**Exemplo 1: Análise Preliminar de Viabilidade**

*   **Usuário Invoca:** `"Manus, analise a viabilidade do loteamento 'Fazenda Bela Vista', matrícula 12.345 do CRI de Cristalina-GO. Foco na conformidade com o Estatuto da Terra e legislação ambiental."`
*   **Ação da Skill:** A skill solicita o projeto e memorial, executa as análises focadas e retorna um relatório preliminar.
*   **Resultado Esperado:** `"Análise preliminar do loteamento 'Fazenda Bela Vista' indica: 1) Risco de violação da fração mínima de parcelamento em 30% dos lotes projetados, contrariando o módulo rural da região. 2) Ausência de averbação da Reserva Legal na matrícula. Recomenda-se readequação do projeto e regularização da Reserva Legal antes de prosseguir. Parecer completo pode ser gerado mediante análise de toda a documentação."`

## Melhores Práticas e Considerações

*   **Documentação Completa:** A precisão da análise é diretamente proporcional à qualidade da documentação fornecida. Matrículas atualizadas, projetos georreferenciados e memoriais descritivos detalhados são essenciais.
*   **Análise Local:** A skill fornece uma análise baseada na legislação federal, mas é crucial complementá-la com a verificação do Plano Diretor e da legislação municipal específica, que podem impor restrições adicionais.
*   **Natureza do Loteamento:** A análise diferencia loteamentos para fins de recreio (chácaras) de parcelamentos com finalidade agrícola, pois o enquadramento legal e as exigências são distintas.
*   **Jurisprudência:** A skill se baseia em teses consolidadas, mas a jurisprudência sobre loteamentos rurais é dinâmica. A conclusão do parecer deve ser ponderada com o entendimento dos tribunais locais.
