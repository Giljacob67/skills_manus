---
name: maestro-agrario
description: Orquestra o fluxo de trabalho para casos de Direito Agrário, acionando as skills especialistas corretas desde a análise inicial até a entrega final do relatório consolidado.
license: MIT
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0.0"
  tags: ["direito-agrario", "orquestrador", "workflow", "gestao-casos"]
---

# Skill: Maestro Agrário (Orquestrador)

## 1. Overview

O **Maestro Agrário** é uma skill orquestradora de alto nível projetada para atuar como o ponto central de comando para a análise e processamento de casos de Direito Agrário. Ele recebe a descrição de uma demanda e coordena um fluxo de trabalho completo, acionando as skills especialistas apropriadas na ordem correta, desde a pesquisa inicial até a produção e revisão de documentos.

Seu objetivo é automatizar a gestão do fluxo de trabalho, garantir que as ferramentas certas sejam usadas para cada etapa e consolidar todos os outputs em um relatório final coeso e integrado, otimizando o tempo e a eficiência do advogado.

## 2. When to Use

Utilize esta skill como ponto de partida para qualquer nova demanda ou caso em Direito Agrário, especialmente quando o trabalho envolve múltiplas etapas, como:

- **Análise de Casos Contenciosos:** Desde a pesquisa de jurisprudência até a elaboração e revisão da peça processual.
- **Elaboração de Pareceres Consultivos:** Quando a resposta exige pesquisa e análise aprofundada.
- **Due Diligence de Imóveis Rurais:** Para coordenar a análise de documentos, riscos e conformidade.
- **Análise e Elaboração de Contratos Agrários:** Integrando a análise contratual com a avaliação de riscos.
- **Investigação de Operações Predatórias:** Orquestrando a análise da operação, pesquisa de precedentes e cálculo de passivos.

## 3. How to Use

O Maestro é invocado com a descrição do caso. Ele então gerencia o fluxo, interagindo com o usuário para obter informações e com outras skills para executar as tarefas.

### Etapa 1: Recepção e Classificação (Input & Triage)

1.  **Recepção do Caso:** O usuário inicia a skill com um prompt descrevendo a demanda.
    - **Exemplo:** `/maestro-agrario "Analisar minuta de contrato de arrendamento rural para a Fazenda Boa Esperança, com foco em cláusulas de risco e garantias."`
2.  **Análise e Validação:** O Maestro analisa a descrição inicial e verifica se possui as informações mínimas para prosseguir:
    - `Tipo de demanda` (contencioso, consultivo, contratual, due diligence)
    - `Partes envolvidas`
    - `Fatos relevantes`
    - `Tribunal` (se aplicável)
    - `Fase processual` (se aplicável)
3.  **Interação com Usuário:** Se informações cruciais estiverem faltando, o Maestro utiliza a ferramenta `message` para solicitá-las antes de continuar. O usuário pode ajustar o fluxo ou pular etapas neste momento.

### Etapa 2: Roteamento e Execução (Routing & Execution)

Com as informações completas, o Maestro seleciona e executa a sequência de skills apropriada, informando ao usuário cada passo. A lógica de roteamento segue as regras predefinidas:

| Tipo de Demanda | Fluxo de Skills Acionadas |
| :--- | :--- |
| **Consulta Simples** | `direito-agrario-avancado` |
| **Contencioso Geral** | `jurisprudencia-agraria-pesquisa` → `analise-risco-agraria` → `peticoes-agronegocio-completo` → `petition-audit` |
| **Embargos à Execução** | `jurisprudencia-agraria-pesquisa` → `analise-operacoes-predatorias-agraria` → `embargos-agrarios-tjpr` ou `peticoes-agronegocio-completo` → `petition-audit` |
| **Análise de Contrato** | `analise-contratos-rurais` → `analise-risco-agraria` |
| **Due Diligence Rural** | `due-diligence-rural` → `analise-risco-agraria` |
| **Operação Predatória** | `jurisprudencia-agraria-pesquisa` → `analise-operacoes-predatorias-agraria` → `calculo-liquidacao-agraria` |

### Etapa 3: Consolidação e Entrega (Consolidation & Delivery)

1.  **Agregação:** O Maestro coleta os outputs de todas as skills executadas (e.g., relatório de jurisprudência, análise de risco, minuta de petição).
2.  **Relatório Final:** As informações são consolidadas em um único relatório integrado, estruturado em Markdown.
3.  **Suporte:** Se aplicável, a skill `gestao-prazos-agraria` é acionada para sugerir um calendário de atividades.
4.  **Entrega:** O relatório final e todos os artefatos gerados são entregues ao usuário.

## 4. Dependências

Esta skill depende da existência e do correto funcionamento das seguintes skills especialistas:

- `jurisprudencia-agraria-pesquisa`
- `analise-contratos-rurais`
- `analise-operacoes-predatorias-agraria`
- `due-diligence-rural`
- `analise-loteamentos-rurais`
- `analise-risco-agraria`
- `direito-agrario-avancado`
- `peticoes-agronegocio-completo`
- `embargos-agrarios-tjpr`
- `calculo-liquidacao-agraria`
- `petition-audit`
- `gestao-prazos-agraria`

## 5. Output (Relatório Consolidado)

O output principal é um arquivo Markdown (`relatorio_caso_XXXX.md`) contendo:

- **Sumário do Caso:** Resumo da demanda e informações chave.
- **Fluxo Executado:** Lista das skills acionadas e o porquê.
- **Resultados da Pesquisa:** Seção com os principais precedentes encontrados.
- **Análise Técnica:** Compilação das análises das skills especialistas (riscos, cláusulas, etc.).
- **Documentos Produzidos:** Links para as minutas de petições ou pareceres gerados.
- **Próximos Passos:** Sugestões de calendário e ações futuras.

## 6. Limitações

- A eficácia do Maestro depende diretamente da qualidade e precisão das informações fornecidas pelo usuário na etapa de recepção.
- A performance está atrelada à disponibilidade e ao correto funcionamento das skills especialistas que ele orquestra.
- O usuário deve revisar criticamente todos os outputs, especialmente as peças processuais, antes de qualquer uso prático.
