---
name: due-diligence-rural
description: Executa uma análise completa de due diligence para imóveis rurais, cobrindo aspectos registrais, ambientais, tributários e de litígio, e gera um relatório estruturado de riscos e recomendações.
---

# Skill: Due Diligence de Imóvel Rural

## 1. Objetivo

Esta skill orienta a execução de uma auditoria jurídica (due diligence) completa sobre um imóvel rural, com o objetivo de identificar e analisar riscos, contingências e passivos que possam afetar a segurança jurídica da aquisição, posse ou exploração do bem. O processo culmina na elaboração de um relatório técnico detalhado.

## 2. Workflow de Execução

O agente deve seguir estritamente as seguintes etapas, utilizando as ferramentas e fontes de dados apropriadas para cada uma.

### Etapa 1: Coleta e Organização de Documentos Essenciais

Antes de iniciar a análise, o agente deve solicitar e organizar a seguinte documentação-base:

- **Matrícula do imóvel**: Cópia atualizada (emitida há menos de 30 dias) com certidão de ônus e ações reais e pessoais reipersecutórias.
- **CCIR (Certificado de Cadastro de Imóvel Rural)**: Emitido pelo INCRA, devidamente quitado.
- **CAR (Cadastro Ambiental Rural)**: Recibo de inscrição e, se houver, o status da análise.
- **ITR (Imposto sobre a Propriedade Territorial Rural)**: Certidão Negativa de Débitos (CND) ou Positiva com Efeitos de Negativa (CPD-EN) e os comprovantes de declaração dos últimos 5 anos (DITR).
- **Georreferenciamento**: Planta e memorial descritivo, com prova de averbação na matrícula (para imóveis com área superior ao módulo fiscal da região ou conforme exigência legal).
- **Certidões dos vendedores (pessoa física ou jurídica)**: CNDs federal, estadual e municipal; certidões de distribuidores cíveis, fiscais, trabalhistas e criminais.

### Etapa 2: Análise da Matrícula e da Cadeia Dominial

1.  **Verificar a titularidade**: Confirmar se o vendedor é o legítimo proprietário do imóvel.
2.  **Analisar a cadeia dominial**: Rastrear o histórico de proprietários do imóvel, buscando por irregularidades, títulos precários, indícios de grilagem ou sobreposição de áreas. A análise deve retroceder, no mínimo, 20 anos ou até a origem do título, se possível.
3.  **Confrontar descrições**: Comparar a descrição do imóvel na matrícula com a planta, o memorial descritivo do georreferenciamento e o CCIR, identificando inconsistências de área ou localização.

### Etapa 3: Identificação de Gravames e Ônus Reais

Examinar a matrícula em busca de:

- **Hipotecas, Penhoras, Arrestos, Sequestros**: Identificar a natureza, o valor e o status do processo judicial ou da dívida que originou o gravame.
- **Alienação Fiduciária**: Verificar se o imóvel está alienado a um credor fiduciário.
- **Usufruto, Uso, Habitação, Servidões**: Analisar a existência de direitos reais que limitam o uso e a disposição da propriedade.
- **Cláusulas de Inalienabilidade, Impenhorabilidade e Incomunicabilidade**: Identificar restrições voluntárias ou judiciais à transferência do bem.
- **Existência de Ações Judiciais**: Verificar a averbação de ações que possam afetar o imóvel.

### Etapa 4: Análise da Regularidade Fundiária e Ambiental

1.  **Georreferenciamento (Lei 10.267/01)**: Confirmar se a averbação do georreferenciamento foi realizada e se não há notificações de sobreposição do SIGEF/INCRA.
2.  **CCIR**: Checar se os dados do CCIR (área, titular, etc.) estão consistentes com a matrícula e se o certificado está válido e quitado.
3.  **CAR (Lei 12.651/12 - Código Florestal)**: Analisar o recibo do CAR para verificar a área declarada de Reserva Legal (RL) e de Preservação Permanente (APP). Identificar se há passivos ambientais declarados (áreas a serem recuperadas) e qual o status da análise pelo órgão ambiental.
4.  **ITR**: Confirmar a regularidade fiscal do imóvel perante a Receita Federal, analisando a CND e as últimas 5 declarações.

### Etapa 5: Análise de Riscos e Restrições Específicas

1.  **Riscos de Posse**: Investigar a existência de posseiros, invasões, conflitos agrários ou litigiosidade na região.
2.  **Terras de Fronteira (Lei 5.709/71)**: Verificar se o imóvel está localizado em faixa de fronteira e, em caso de aquisição por estrangeiro, se as restrições legais foram observadas.
3.  **Terras Indígenas, Quilombolas e Unidades de Conservação**: Consultar os bancos de dados da FUNAI, Fundação Palmares e ICMBio para verificar se o imóvel se sobrepõe a áreas protegidas ou em processo de demarcação/criação.

### Etapa 6: Verificação de Débitos e Passivos

1.  **Débitos de ITR**: Já verificado na Etapa 4.
2.  **Dívidas Trabalhistas Rurais**: Analisar as certidões da Justiça do Trabalho em nome do proprietário atual e dos antecessores (se houver risco de sucessão).
3.  **Execuções Fiscais**: Analisar as certidões da Justiça Federal e Estadual.

### Etapa 7: Elaboração do Relatório de Due Diligence

Consolidar todas as informações coletadas e as análises realizadas em um relatório estruturado, conforme o modelo abaixo.

## 3. Estrutura do Relatório de Due Diligence

O relatório final deve ser gerado em Markdown e conter as seguintes seções:

```markdown
# Relatório de Due Diligence – Imóvel Rural [Nome do Imóvel]

**Data de Emissão:** [Inserir Data]

**Solicitante:** Dr. Gilberto Jacob

## 1. Resumo Executivo

- **Identificação do Imóvel**: [Nome, Matrícula, Município/UF, Área Total]
- **Proprietário(s) Atual(is)**: [Nome(s) e CPF/CNPJ]
- **Classificação de Risco Geral**: [Baixo / Médio / Alto]
- **Principais Riscos Identificados**: [Listar de 1 a 3 principais pontos de atenção]
- **Recomendações Preliminares**: [Listar ações imediatas sugeridas]

## 2. Análise Detalhada

### 2.1. Situação Registral e Cadeia Dominial

- **Análise da Matrícula**: [Descrever a situação da matrícula, eventuais inconsistências e o resultado da análise da cadeia dominial.]
- **Conclusão**: [Avaliação sobre a segurança e a regularidade da titularidade.]

### 2.2. Gravames e Ônus Reais

- **Descrição dos Gravames**: [Detalhar cada gravame encontrado, seu status e o risco associado.]
- **Conclusão**: [Avaliação do impacto dos gravames na negociação.]

### 2.3. Regularidade Fundiária e Ambiental

- **Georreferenciamento**: [Status e conformidade.]
- **CCIR**: [Status e conformidade.]
- **CAR**: [Status, análise de RL e APP, existência de passivos.]
- **ITR**: [Status da regularidade fiscal.]
- **Conclusão**: [Avaliação geral da regularidade do imóvel perante os órgãos competentes.]

### 2.4. Riscos, Restrições e Passivos

- **Riscos de Posse e Litígios**: [Descrição dos achados.]
- **Restrições Específicas (Fronteira, Áreas Protegidas)**: [Descrição dos achados.]
- **Débitos (Trabalhistas, Fiscais)**: [Descrição dos achados.]
- **Conclusão**: [Avaliação consolidada dos riscos externos ao imóvel.]

## 3. Classificação de Risco e Recomendações

| Categoria | Risco Identificado | Nível de Risco (Baixo/Médio/Alto) | Recomendação Estratégica |
| :--- | :--- | :--- | :--- |
| Registral | [Ex: Cadeia dominial interrompida] | Alto | [Ex: Aprofundar investigação ou não prosseguir] |
| Ambiental | [Ex: Passivo de Reserva Legal a recuperar] | Médio | [Ex: Quantificar custo de recuperação e negociar abatimento] |
| Tributário | [Ex: Débito de ITR em aberto] | Baixo | [Ex: Exigir quitação antes da assinatura do contrato] |
| ... | ... | ... | ... |

## 4. Conclusão Final

[Parecer final sobre a viabilidade e segurança da operação, com as ressalvas e condições necessárias para a mitigação dos riscos identificados.]

## 5. Anexos

- [Link para a Matrícula Atualizada]
- [Link para o CCIR]
- [Link para o Recibo do CAR]
- [Link para a CND de ITR]

```

## 4. Referências Normativas

- **Lei nº 10.267/2001**: Altera a Lei nº 6.015/73 (Lei de Registros Públicos) e institui o georreferenciamento.
- **Lei nº 12.651/2012**: Novo Código Florestal (institui o CAR, define APP e Reserva Legal).
- **Lei nº 5.709/1971**: Regula a aquisição de imóvel rural por estrangeiro.
- **Lei nº 9.393/1996**: Dispõe sobre o Imposto sobre a Propriedade Territorial Rural - ITR.
- **Instruções Normativas do INCRA e da Receita Federal** sobre CCIR, georreferenciamento e ITR.
