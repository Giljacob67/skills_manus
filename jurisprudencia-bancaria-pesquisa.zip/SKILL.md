---
name: jurisprudencia-bancaria-pesquisa
description: Pesquisa avançada de jurisprudência em Direito Bancário e Cobrança brasileiro, integrando API DATAJUD com web scraping de JusBrasil e sites de tribunais. Cobre STF, STJ e TJs estaduais. Produz síntese crítica dos precedentes, mapeamento de tendências (consolidado vs. divergente vs. superado) e conclusão estratégica. Use quando solicitar pesquisa de jurisprudência sobre juros bancários, prescrição intercorrente, nulidade de títulos, capitalização de juros, embargos à execução e temas conexos.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Pesquisa de Jurisprudência Bancária

Skill de pesquisa jurisprudencial multifonte, otimizada para Direito Bancário e Cobrança brasileiro. Integra consulta estruturada via API DATAJUD com web scraping inteligente, produzindo análise crítica e mapeamento de tendências.

## 1. Análise da Solicitação

Antes de iniciar qualquer busca, extrair da mensagem do usuário:

- **Tema jurídico central** — Identificar o instituto bancário (ex: "juros abusivos em operações bancárias", "prescrição intercorrente em execução de duplicata").
- **Termos de busca primários** — Palavras-chave e expressões jurídicas exatas.
- **Termos de busca secundários** — Sinônimos, variações e termos correlatos.
- **Filtros** — Tribunais específicos, período temporal, turma/câmara.
- **Objetivo** — Verificar se o usuário quer um panorama geral, confirmação de tese específica, ou mapeamento de divergência.

## 2. Pesquisa via API DATAJUD

A API DATAJUD é baseada em Elasticsearch e fornece metadados processuais. Usar como fonte primária para identificar processos relevantes.

### 2.1 Endpoints por Tribunal

| Tribunal | Alias | Endpoint Completo |
|:---------|:------|:------------------|
| STJ | `api_publica_stj` | `https://api-publica.datajud.cnj.jus.br/api_publica_stj/_search` |
| STF | `api_publica_stf` | `https://api-publica.datajud.cnj.jus.br/api_publica_stf/_search` |
| TJSP | `api_publica_tjsp` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjsp/_search` |
| TJRJ | `api_publica_tjrj` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjrj/_search` |
| TJMG | `api_publica_tjmg` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjmg/_search` |
| TJBA | `api_publica_tjba` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjba/_search` |
| TJRS | `api_publica_tjrs` | `https://api-publica.datajud.cnj.jus.br/api_publica_tjrs/_search` |

### 2.2 Autenticação e Headers

```
Authorization: APIKey cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw==
Content-Type: application/json
```

### 2.3 Ordem de Consulta (Priorização)

1. **STJ** — Fonte primária. Buscar sempre.
2. **TJSP, TJRJ, TJMG, TJBA, TJRS** — TJs de grande porte com jurisprudência relevante.
3. **STF** — Buscar apenas se envolver questão constitucional.

## 3. Busca do Inteiro Teor (JusBrasil + Sites dos Tribunais)

### 3.1 Busca no JusBrasil

O JusBrasil é a fonte principal para obter ementas e inteiro teor.

**URLs de busca:**

| Tipo de Busca | URL |
|:--------------|:----|
| Busca geral | `https://www.jusbrasil.com.br/jurisprudencia/busca?q={{TERMOS}}` |
| Filtro por tribunal | Adicionar `&tribunal={{SIGLA}}` à URL |
| Busca por número | `https://www.jusbrasil.com.br/jurisprudencia/busca?q={{NUMERO_PROCESSO}}` |

**Procedimento:**

1. Navegar para a URL de busca do JusBrasil com os termos-chave.
2. Aplicar filtros de tribunal (STJ, TJSP, TJRJ, etc.) e período.
3. Para cada resultado relevante, abrir a página do acórdão e extrair: ementa, relatório, voto, dispositivo.
4. Salvar o conteúdo extraído em `/home/ubuntu/jurisprudencia/` com nomenclatura padronizada.

**Critérios de relevância para seleção de resultados:**

- Presença dos termos-chave no corpo da ementa ou do voto.
- Tribunal pertencente à lista prioritária.
- Data de julgamento recente (preferir últimos 5 anos, mas incluir precedentes paradigmáticos mais antigos).
- Classe processual relevante (Recurso Especial, Apelação, Agravo de Instrumento).
- Citação de dispositivos legais bancários (Decreto 22.626/33, Lei 5.474/68, Lei 7.357/85, Res. CMN 3.517/07, MP 2.170-36/01, CDC).

### 3.2 Busca Direta nos Sites dos Tribunais (Fallback)

| Tribunal | URL de Jurisprudência |
|:---------|:----------------------|
| STJ | `https://scon.stj.jus.br/SCON/` |
| STF | `https://jurisprudencia.stf.jus.br/pages/search` |
| TJSP | `https://esaj.tjsp.jus.br/cjsg/consultaCompleta.do` |
| TJRJ | `https://www1.tjrj.jus.br/jurisprudencia/` |
| TJMG | `https://www5.tjmg.jus.br/jurisprudencia/` |
| TJBA | `https://jurisprudencia.tjba.jus.br/` |
| TJRS | `https://www.tjrs.jus.br/novo/jurisprudencia/` |

## 4. Síntese Crítica e Mapeamento de Tendências

### 4.1 Fichamento Estruturado

Para cada acórdão selecionado, registrar:

```markdown
## [Tribunal] - [Número do Processo]

**Classe:** [Recurso Especial / Apelação / etc.]
**Relator(a):** [Nome]
**Órgão Julgador:** [Turma/Câmara]
**Data do Julgamento:** [DD/MM/AAAA]
**Resultado:** [Provido / Improvido / Parcialmente Provido]

### Tese Jurídica Central
[Resumo da tese em 2-3 frases]

### Fundamentação Principal
[Dispositivos legais, precedentes citados, ratio decidendi]

### Trecho-Chave
> "[Citação direta do trecho mais relevante do acórdão]"

### Classificação
- **Status:** [Consolidado / Divergente / Isolado / Superado]
- **Precedente Qualificado:** [Sim/Não]
- **Relevância para o Caso:** [Alta / Média / Baixa]
```

### 4.2 Mapeamento de Tendências

Após o fichamento de todos os acórdãos, analisar o conjunto para identificar:

- **Entendimentos consolidados** — Teses aplicadas de forma uniforme por múltiplos órgãos julgadores.
- **Divergências ativas** — Teses conflitantes entre tribunais diferentes.
- **Evolução temporal** — Mudanças de entendimento ao longo do tempo.
- **Lacunas** — Temas sobre os quais não há jurisprudência consolidada.

## 5. Elaboração do Relatório Final

Gerar o relatório em `/home/ubuntu/relatorio_jurisprudencial.md` com a seguinte estrutura:

```markdown
# Relatório de Pesquisa Jurisprudencial
## [Tema Pesquisado]

**Data da Pesquisa:** [DD/MM/AAAA]
**Fontes Consultadas:** [DATAJUD, JusBrasil, SCON/STJ, etc.]
**Tribunais Pesquisados:** [Lista]
**Período:** [Intervalo temporal]

---

## 1. Síntese Executiva
[Parágrafo resumindo os principais achados]

## 2. Quadro de Precedentes

| # | Tribunal | Processo | Relator(a) | Data | Tese Central | Status |
|:--|:---------|:---------|:-----------|:-----|:-------------|:-------|
| 1 | STJ | REsp ... | Min. ... | ... | ... | Consolidado |

## 3. Análise Crítica

### 3.1 Entendimentos Consolidados
[Análise discursiva com citações dos acórdãos]

### 3.2 Divergências Identificadas
[Análise das correntes conflitantes]

### 3.3 Evolução Jurisprudencial
[Análise temporal, se aplicável]

## 4. Conclusão Estratégica
[Recomendações argumentativas com base na jurisprudência mapeada]

## 5. Referências
[Lista completa dos acórdãos citados com links]
```

## 6. Temas Bancários Prioritários

- Juros abusivos em operações bancárias
- Capitalização de juros (anatocismo)
- Prescrição intercorrente em execução de títulos
- Nulidade de duplicata, nota promissória, cheque
- Embargos à execução (juros, prescrição, vício formal)
- Responsabilidade civil bancária
- Cláusulas abusivas em contratos bancários
- Juros moratórios e taxa média de mercado

---

**FIM DA SKILL `jurisprudencia-bancaria-pesquisa` v1.0**
