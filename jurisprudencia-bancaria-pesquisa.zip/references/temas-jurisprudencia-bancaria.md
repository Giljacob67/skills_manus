# Temas Bancários Prioritários — Termos de Busca

## 1. Juros Abusivos em Operações Bancárias

| Campo | Termos |
|:------|:-------|
| Termos primários | `juros abusivos operações bancárias`, `taxa média mercado juros` |
| Termos secundários | `juros acima taxa média`, `juros ilegais banco`, `revisão juros contrato` |
| Assuntos TPU | `Juros`, `Operações Bancárias`, `Contrato Bancário` |
| Dispositivos-chave | Decreto 22.626/33; Res. CMN 3.517/07; CDC arts. 39, 51 |

## 2. Capitalização de Juros (Anatocismo)

| Campo | Termos |
|:------|:-------|
| Termos primários | `capitalização juros anatocismo`, `juros sobre juros banco` |
| Termos secundários | `capitalização mensal juros`, `juros compostos crédito rural`, `anatocismo operação bancária` |
| Assuntos TPU | `Juros`, `Capitalização de Juros`, `Anatocismo` |
| Dispositivos-chave | MP 2.170-36/01, art. 5º; Súmula 382/STJ |

## 3. Prescrição Intercorrente em Execução de Títulos

| Campo | Termos |
|:------|:-------|
| Termos primários | `prescrição intercorrente execução`, `inatividade processual execução` |
| Termos secundários | `prescrição intercorrente duplicata`, `prescrição intercorrente nota promissória`, `art. 921 CPC` |
| Assuntos TPU | `Prescrição`, `Execução`, `Prescrição Intercorrente` |
| Dispositivos-chave | CPC arts. 921-924 |

## 4. Nulidade de Duplicata

| Campo | Termos |
|:------|:-------|
| Termos primários | `nulidade duplicata vício formal`, `duplicata requisitos essenciais` |
| Termos secundários | `duplicata sem série`, `duplicata sem número sequencial`, `duplicata sem descrição mercadoria` |
| Assuntos TPU | `Duplicata`, `Nulidade`, `Títulos de Crédito` |
| Dispositivos-chave | Lei 5.474/68, arts. 2º-3º, 15 |

## 5. Nulidade de Nota Promissória

| Campo | Termos |
|:------|:-------|
| Termos primários | `nulidade nota promissória`, `nota promissória vício formal` |
| Termos secundários | `nota promissória sem assinatura`, `nota promissória sem data` |
| Assuntos TPU | `Nota Promissória`, `Nulidade`, `Títulos de Crédito` |
| Dispositivos-chave | Lei Uniforme de Genebra, arts. 75-84 |

## 6. Nulidade de Cheque

| Campo | Termos |
|:------|:-------|
| Termos primários | `nulidade cheque vício formal`, `cheque requisitos essenciais` |
| Termos secundários | `cheque pós-datado execução`, `cheque sem fundos` |
| Assuntos TPU | `Cheque`, `Nulidade`, `Títulos de Crédito` |
| Dispositivos-chave | Lei 7.357/85, arts. 1º-2º, 59 |

## 7. Embargos à Execução — Juros Abusivos

| Campo | Termos |
|:------|:-------|
| Termos primários | `embargos execução juros abusivos`, `embargos execução excesso cobrança` |
| Termos secundários | `embargos execução capitalização juros`, `embargos execução taxa média mercado` |
| Assuntos TPU | `Embargos à Execução`, `Juros`, `Execução` |
| Dispositivos-chave | CPC arts. 914-920 |

## 8. Embargos à Execução — Prescrição Intercorrente

| Campo | Termos |
|:------|:-------|
| Termos primários | `embargos execução prescrição intercorrente`, `embargos execução inatividade processual` |
| Termos secundários | `embargos execução art. 921 CPC` |
| Assuntos TPU | `Embargos à Execução`, `Prescrição Intercorrente` |
| Dispositivos-chave | CPC arts. 914-920, 921 |

## 9. Responsabilidade Civil Bancária

| Campo | Termos |
|:------|:-------|
| Termos primários | `responsabilidade civil banco`, `danos morais banco` |
| Termos secundários | `inscrição indevida SPC banco`, `cobrança abusiva banco`, `constrangimento banco` |
| Assuntos TPU | `Responsabilidade Civil`, `Danos Morais`, `Instituição Financeira` |
| Dispositivos-chave | CC arts. 186-188, 927; CDC arts. 14-17 |

## 10. Cláusulas Abusivas em Contratos Bancários

| Campo | Termos |
|:------|:-------|
| Termos primários | `cláusula abusiva contrato banco`, `cláusula nula contrato bancário` |
| Termos secundários | `renúncia direitos contrato banco`, `vencimento antecipado cláusula abusiva` |
| Assuntos TPU | `Cláusula Abusiva`, `Contrato Bancário`, `Nulidade` |
| Dispositivos-chave | CDC arts. 39, 51; CC art. 421 |

## 11. Operações de Crédito — Juros Moratórios

| Campo | Termos |
|:------|:-------|
| Termos primários | `juros moratórios crédito bancário`, `taxa moratória limite legal` |
| Termos secundários | `juros moratórios 1% ao mês`, `juros moratórios taxa média` |
| Assuntos TPU | `Juros Moratórios`, `Crédito Bancário` |
| Dispositivos-chave | DL 167/67, art. 5º; Lei 14.905/24 |

## 12. Financiamento Pessoa Física — Juros

| Campo | Termos |
|:------|:-------|
| Termos primários | `financiamento pessoa física juros`, `crédito pessoa física taxa média` |
| Termos secundários | `crédito consignado juros`, `crédito pessoal taxa` |
| Assuntos TPU | `Financiamento`, `Crédito Pessoa Física`, `Juros` |
| Dispositivos-chave | Res. CMN 3.517/07 |

## 13. Alienação Fiduciária — Execução

| Campo | Termos |
|:------|:-------|
| Termos primários | `alienação fiduciária execução`, `consolidação propriedade fiduciária` |
| Termos secundários | `execução extrajudicial bem fiduciário`, `leilão bem fiduciário` |
| Assuntos TPU | `Alienação Fiduciária`, `Execução`, `Propriedade` |
| Dispositivos-chave | Lei 9.514/97 |

## 14. Leasing — Juros e Encargos

| Campo | Termos |
|:------|:-------|
| Termos primários | `leasing juros abusivos`, `contrato leasing cláusula nula` |
| Termos secundários | `leasing taxa média mercado`, `leasing encargos ilegais` |
| Assuntos TPU | `Leasing`, `Juros`, `Contrato Financeiro` |
| Dispositivos-chave | Lei 7.132/83 |

## 15. Desconto de Títulos — Juros

| Campo | Termos |
|:------|:-------|
| Termos primários | `desconto títulos juros`, `desconto duplicata taxa` |
| Termos secundários | `desconto cheque taxa média mercado` |
| Assuntos TPU | `Desconto de Títulos`, `Juros`, `Operações Bancárias` |
| Dispositivos-chave | Res. CMN 3.517/07 |
