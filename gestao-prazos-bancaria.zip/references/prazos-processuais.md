# Prazos Processuais — Direito Bancário e Cobrança

## Prazos em Dias Úteis (Regra Geral)

Todos os prazos processuais em matéria de cobrança e execução são contados em **dias úteis**, conforme art. 219 do CPC/2015.

| Ato Processual | Prazo | Fundamento Legal | Observações |
|:---------------|:------|:-----------------|:------------|
| **Contestação** (Execução) | 15 dias úteis | Art. 833, CPC | Contado da juntada do mandado de citação |
| **Embargos à Execução** | 15 dias úteis | Art. 915, CPC | Contado da juntada do mandado de citação |
| **Apelação** | 15 dias úteis | Art. 1.003, §5º, CPC | Contado da publicação da sentença |
| **Agravo de Instrumento** | 15 dias úteis | Art. 1.003, §5º, CPC | Contado da publicação da decisão agravada |
| **Agravo Interno** | 15 dias úteis | Art. 1.003, §5º, CPC | Contado da publicação da decisão monocrática |
| **Embargos de Declaração** | 5 dias úteis | Art. 1.023, CPC | Contado da publicação da decisão |
| **Recurso Especial (REsp)** | 15 dias úteis | Art. 1.003, §5º, CPC | Contado da publicação da decisão do tribunal de origem |
| **Recurso Extraordinário (RE)** | 15 dias úteis | Art. 1.003, §5º, CPC | Contado da publicação da decisão do tribunal de origem |

## Prazos em Dias Corridos (Exceções)

Alguns atos processuais são contados em **dias corridos**:

| Ato Processual | Prazo | Fundamento Legal |
|:---------------|:------|:-----------------|
| **Cumprimento de Sentença** (Pagamento Voluntário) | 15 dias corridos | Art. 496, CPC |
| **Manifestação sobre Embargos à Execução** | 15 dias corridos | Art. 917, CPC |
| **Impugnação ao Cumprimento de Sentença** | 15 dias corridos | Art. 525, CPC |

## Prescrição Intercorrente

| Situação | Prazo | Fundamento Legal | Observações |
|:---------|:------|:-----------------|:------------|
| **Inatividade Processual em Execução** | 1 ano | Art. 921, CPC | Sem movimentação processual |
| **Suspensão da Prescrição Intercorrente** | — | Art. 921, §1º, CPC | Citação válida, protesto, reconhecimento de dívida |

## Prescrição Ordinária de Títulos de Crédito

| Título | Prazo | Fundamento Legal |
|:-------|:------|:-----------------|
| **Duplicata** | 3 anos | Lei 5.474/68, art. 26 |
| **Nota Promissória** | 3 anos | Lei Uniforme de Genebra, art. 75 |
| **Cheque** | 6 meses | Lei 7.357/85, art. 59 |

## Calendário Forense — Suspensão de Prazos

Os prazos processuais são suspensos durante:

- **Recesso Forense:** Período entre 20 de dezembro e 20 de janeiro (art. 220, CPC).
- **Feriados Nacionais e Estaduais:** Conforme Lei 9.093/95 e legislação estadual.
- **Pontos Facultativos:** Conforme decisão do tribunal.
- **Suspensão Excepcional:** Decisão do tribunal (art. 220, §2º, CPC).

**Observação:** Cada tribunal possui seu próprio calendário forense. Verificar sempre no site do tribunal a data exata de suspensão.

## Contagem de Prazos — Regras Essenciais

1. **Termo Inicial:** O prazo começa a contar no primeiro dia útil subsequente ao evento que o dispara (art. 219, §1º, CPC).

2. **Termo Final:** O prazo termina no último dia útil, considerando-se prorrogado para o primeiro dia útil subsequente se o último cair em feriado ou fim de semana (art. 219, §2º, CPC).

3. **Dias Úteis:** Não são contados sábados, domingos e feriados (art. 219, §1º, CPC).

4. **Horário de Encerramento:** Os atos processuais devem ser praticados até as 23h59 do último dia do prazo (art. 219, §4º, CPC).

## Exemplo Prático de Cálculo

**Cenário:** Embargos à Execução — Juntada do mandado de citação em 10/03/2026 (segunda-feira).

**Cálculo:**

- Termo inicial: 11/03/2026 (terça-feira — primeiro dia útil subsequente)
- Contagem de 15 dias úteis:
  - Semana 1: 11, 12, 13, 16, 17 (5 dias — 14 e 15 são sábado e domingo)
  - Semana 2: 18, 19, 20, 23, 24 (5 dias — 21 e 22 são sábado e domingo)
  - Semana 3: 25, 26, 27 (3 dias — faltam 2 dias)
  - Semana 4: 30, 31 (2 dias — 28 e 29 são sábado e domingo)
- **Termo final: 31/03/2026 (quarta-feira)**

**Prazo Final para Oposição de Embargos: 31/03/2026**

## Alertas Críticos

- **Preclusão:** O não cumprimento do prazo implica perda do direito de praticar o ato (preclusão consumativa).
- **Deserção:** Em recursos, o não recolhimento de custas implica deserção (perda do direito de recorrer).
- **Prescrição Intercorrente:** Monitorar continuamente períodos de inatividade processual em execuções.
- **Verificação Dupla:** Sempre verificar o calendário forense do tribunal antes de calcular prazos.
