---
name: gestao-prazos-bancaria
description: Gerencia e calcula prazos processuais em contencioso bancário e cobrança, considerando o CPC, calendários forenses, e particularidades das justiças estadual e federal. Alerta sobre preclusões, prescrição intercorrente e integra com Google Calendar.
license: Proprietary - Uso exclusivo de Gilberto Jacob
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: Gestão de Prazos Bancária

## Visão Geral

A skill `gestao-prazos-bancaria` é uma ferramenta técnica de alta precisão para a gestão e o cálculo de prazos no contencioso bancário e cobrança. Desenvolvida para advogados que atuam na área, a skill automatiza a contagem de prazos processuais com base no Código de Processo Civil (CPC), calendários forenses específicos, e as normativas aplicáveis. Sua função principal é eliminar a margem de erro no controle de prazos fatais, alertar sobre riscos de preclusão e prescrição intercorrente, e integrar-se a ferramentas de produtividade como o Google Calendar.

## Workflow Principal

O fluxo de trabalho foi desenhado para ser direto e eficiente, partindo da entrada de dados mínimos para a entrega de um resultado completo e integrado.

1. **Iniciação e Coleta de Dados:** O usuário invoca a skill e fornece os dados essenciais do processo: número do processo (para consulta automática, se disponível), tribunal, data de início da contagem do prazo (e.g., data da publicação da decisão ou da juntada do AR), e a natureza do prazo a ser calculado (e.g., Embargos à Execução, Contestação, Apelação).

2. **Consulta e Análise de Calendário:** A skill acessa a base de dados de calendários forenses correspondente ao tribunal informado. Ela identifica feriados locais, nacionais, recessos, suspensões de prazo e outras particularidades.

3. **Cálculo do Prazo:** Com base no CPC (considerando se o prazo é em dias úteis ou corridos) e nos dados do calendário forense, a skill realiza o cálculo preciso da data final para a prática do ato processual.

4. **Geração de Alertas e Relatório:** A skill apresenta um relatório detalhado contendo:
    - Data de início da contagem.
    - Data final do prazo.
    - Memorial de cálculo, discriminando os dias úteis e os dias não considerados.
    - Alerta sobre o risco de preclusão.
    - Alerta sobre prescrição intercorrente (se aplicável).

5. **Integração com Agenda (Opcional):** Mediante autorização, a skill utiliza o Google Calendar para criar um ou mais eventos na agenda do usuário com alertas automáticos.

6. **Geração de Calendário Completo (Opcional):** O usuário pode solicitar a criação de um calendário processual completo para o caso, mapeando os principais prazos subsequentes esperados.

## Capacidades Detalhadas

- **Cálculo de Prazos Processuais:** Calcula com precisão os prazos para as principais manifestações em processos de cobrança e execução, como Embargos à Execução, Contestação, Recursos (Apelação, Agravo de Instrumento), e atos da fase de execução.

- **Consideração de Calendário Forense:** Acessa e processa informações de calendários do Poder Judiciário, incluindo feriados, pontos facultativos, recessos e suspensões de prazo específicas de cada tribunal.

- **Alerta sobre Preclusões:** Informa de maneira explícita a data limite para a prática do ato, funcionando como uma camada adicional de segurança.

- **Alerta sobre Prescrição Intercorrente:** Identifica períodos de inatividade processual que possam configurar prescrição intercorrente (art. 921, CPC).

- **Integração com Google Calendar:** Automatiza a criação de eventos e lembretes na agenda do usuário.

- **Diferenciação de Contagem (Dias Úteis vs. Corridos):** Aplica a regra de contagem correta com base na natureza do prazo.

- **Particularidades de Justiça Estadual vs. Federal:** Distingue e aplica os calendários e normativas específicas dos Tribunais de Justiça e dos Tribunais Regionais Federais.

- **Geração de Calendário Processual do Caso:** Projeta um cronograma estimado das fases processuais futuras.

## Exemplos de Uso

**Exemplo 1: Cálculo de Prazo para Embargos à Execução**

> **Usuário:** "Preciso calcular o prazo para oposição de Embargos à Execução. A juntada do mandado de citação no processo nº 0012345-67.2026.8.26.0100 (TJSP) ocorreu em 10 de março de 2026."

> **Resultado da Skill (síntese):**
> ```
> **Análise de Prazo Processual**
> 
> *   **Ato:** Embargos à Execução
> *   **Fundamento:** Art. 915, CPC (15 dias úteis)
> *   **Termo Inicial:** 11/03/2026 (primeiro dia útil subsequente à juntada)
> *   **Tribunal:** TJSP
> 
> **Memorial de Cálculo:**
> *   Dias úteis considerados: [Lista de dias]
> *   Feriados/Suspensões no período: [Lista de feriados]
> 
> *   **Prazo Final (Preclusão):** 02/04/2026
> 
> **Ação Sugerida:** Deseja adicionar um evento com alerta no Google Calendar para 02/04/2026?
> ```

**Exemplo 2: Integração com Google Calendar**

> **Usuário:** "Sim, adicione o evento no Google Calendar com alertas 5 dias e 1 dia antes."

> **Resultado da Skill:**
> ```
> Evento "[URGENTE] Prazo Final - Embargos Proc. 0012345-67.2026.8.26.0100" criado com sucesso em sua agenda para 02/04/2026. Alertas configurados para 28/03/2026 e 01/04/2026.
> ```

## Melhores Práticas e Considerações

- **Verificação Dupla:** Embora a skill seja projetada para alta precisão, a conferência humana do prazo final no sistema do tribunal permanece como prática de segurança indispensável.

- **Dados de Entrada:** A precisão do cálculo depende diretamente da exatidão dos dados fornecidos. Sempre confirme a data do evento que dispara o início da contagem.

- **Atualização de Calendários:** A base de dados de calendários forenses é atualizada continuamente. No entanto, suspensões de prazo não programadas podem não ser capturadas em tempo real.

- **Uso Estratégico:** Utilize a função de "Calendário Processual Completo" no início de um caso para ter uma visão macro dos prazos e planejar a estratégia processual com antecedência.

- **Prescrição Intercorrente:** Fique atento aos períodos de inatividade processual que possam configurar prescrição intercorrente (art. 921, CPC). A skill alertará automaticamente sobre datas críticas.

---

**FIM DA SKILL `gestao-prazos-bancaria` v1.0**
