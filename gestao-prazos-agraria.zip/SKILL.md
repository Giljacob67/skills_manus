---
name: "gestao-prazos-agraria"
description: "Gerencia e calcula prazos processuais em contencioso agrário, considerando o CPC, calendários forenses, e particularidades das justiças estadual e federal. Alerta sobre preclusões e integra com Google Calendar."
license: "Proprietary - Uso exclusivo de Gilberto Jacob"
metadata:
  author: "Manus AI para Gilberto Jacob"
  version: "1.0"
---

# Skill: gestao-prazos-agraria

## Visão Geral

A skill `gestao-prazos-agraria` é uma ferramenta técnica de alta precisão para a gestão e o cálculo de prazos no contencioso agrário. Desenvolvida para advogados que atuam na área, a skill automatiza a contagem de prazos processuais com base no Código de Processo Civil (CPC), calendários forenses específicos (Tribunais de Justiça e Tribunais Federais), e as normativas aplicáveis. Sua função principal é eliminar a margem de erro no controle de prazos fatais, alertar sobre riscos de preclusão e integrar-se a ferramentas de produtividade como o Google Calendar para garantir o cumprimento rigoroso das obrigações processuais.

## Workflow Principal

O fluxo de trabalho foi desenhado para ser direto e eficiente, partindo da entrada de dados mínimos para a entrega de um resultado completo e integrado.

1.  **Iniciação e Coleta de Dados:** O usuário invoca a skill e fornece os dados essenciais do processo: número do processo (para consulta automática, se disponível), tribunal, data de início da contagem do prazo (e.g., data da publicação da decisão ou da juntada do AR), e a natureza do prazo a ser calculado (e.g., Embargos à Execução, Contestação, Apelação).

2.  **Consulta e Análise de Calendário:** A skill acessa a base de dados de calendários forenses correspondente ao tribunal informado (estadual ou federal). Ela identifica feriados locais, nacionais, recessos, suspensões de prazo e outras particularidades que impactam a contagem.

3.  **Cálculo do Prazo:** Com base no CPC (considerando se o prazo é em dias úteis ou corridos) e nos dados do calendário forense, a skill realiza o cálculo preciso da data final para a prática do ato processual.

4.  **Geração de Alertas e Relatório:** A skill apresenta um relatório detalhado contendo:
    *   Data de início da contagem.
    *   Data final do prazo.
    *   Memorial de cálculo, discriminando os dias úteis e os dias não considerados (feriados, suspensões).
    *   Alerta sobre o risco de preclusão.

5.  **Integração com Agenda (Opcional):** Mediante autorização, a skill utiliza a integração com o Google Calendar para criar um ou mais eventos na agenda do usuário. Os eventos são configurados com a data final do prazo e alertas automáticos (e.g., 5 dias antes, 1 dia antes) para mitigar o risco de esquecimento.

6.  **Geração de Calendário Completo (Opcional):** O usuário pode solicitar a criação de um calendário processual completo para o caso, mapeando os principais prazos subsequentes esperados no rito processual.

## Capacidades Detalhadas

*   **Cálculo de Prazos Processuais:** Calcula com precisão os prazos para as principais manifestações em processos agrários, como Embargos à Execução, Contestação, Recursos (Apelação, Agravo de Instrumento), e atos da fase de execução, em conformidade com o CPC/2015.

*   **Consideração de Calendário Forense:** Acessa e processa informações de calendários do Poder Judiciário, incluindo feriados, pontos facultativos, recessos e suspensões de prazo específicas de cada tribunal, garantindo que a contagem reflita a realidade forense.

*   **Alerta sobre Preclusões:** Informa de maneira explícita a data limite para a prática do ato, funcionando como uma camada adicional de segurança contra a perda de prazos fatais.

*   **Integração com Google Calendar:** Automatiza a criação de eventos e lembretes na agenda do usuário, traduzindo o resultado do cálculo em um compromisso acionável e com notificações programadas.

*   **Diferenciação de Contagem (Dias Úteis vs. Corridos):** Aplica a regra de contagem correta (dias úteis, conforme regra geral do Art. 219 do CPC, ou dias corridos, em exceções legais) com base na natureza do prazo.

*   **Particularidades de Justiça Estadual vs. Federal:** Distingue e aplica os calendários e normativas específicas dos Tribunais de Justiça e dos Tribunais Regionais Federais, que possuem calendários e regras de suspensão distintos.

*   **Geração de Calendário Processual do Caso:** Projeta um cronograma estimado das fases processuais futuras, fornecendo uma visão estratégica de longo prazo sobre os principais atos e prazos a serem observados no processo.

## Exemplos de Uso

**Exemplo 1: Cálculo de Prazo para Embargos à Execução no TJPR**

> **Usuário:** "Preciso calcular o prazo para oposição de Embargos à Execução. A juntada do mandado de citação no processo nº 0012345-67.2026.8.16.0001 (TJPR) ocorreu em 10 de março de 2026."

> **Resultado da Skill (síntese):**
> ```
> **Análise de Prazo Processual**
> 
> *   **Ato:** Embargos à Execução
> *   **Fundamento:** Art. 915, CPC (15 dias úteis)
> *   **Termo Inicial:** 11/03/2026 (primeiro dia útil subsequente à juntada)
> *   **Tribunal:** TJPR
> 
> **Memorial de Cálculo:**
> *   Dias úteis considerados: [Lista de dias]
> *   Feriados/Suspensões no período: [Lista de feriados, ex: Semana Santa]
> 
> *   **Prazo Final (Preclusão):** 02/04/2026
> 
> **Ação Sugerida:** Deseja adicionar um evento com alerta no Google Calendar para 02/04/2026?
> ```

**Exemplo 2: Integração com Google Calendar**

> **Usuário:** "Sim, adicione o evento no Google Calendar com alertas 5 dias e 1 dia antes."

> **Resultado da Skill:**
> ```
> Evento "[URGENTE] Prazo Final - Embargos Proc. 0012345-67.2026.8.16.0001" criado com sucesso em sua agenda para 02/04/2026. Alertas configurados para 28/03/2026 e 01/04/2026.
> ```

## Melhores Práticas e Considerações

*   **Verificação Dupla:** Embora a skill seja projetada para alta precisão, a conferência humana do prazo final no sistema do tribunal (e.g., Projudi, E-proc) permanece como prática de segurança indispensável.
*   **Dados de Entrada:** A precisão do cálculo depende diretamente da exatidão dos dados fornecidos. Sempre confirme a data do evento que dispara o início da contagem (publicação, juntada, ciência inequívoca).
*   **Atualização de Calendários:** A base de dados de calendários forenses é atualizada continuamente. No entanto, suspensões de prazo não programadas (e.g., por problemas técnicos no sistema do tribunal) podem não ser capturadas em tempo real. Fique atento aos comunicados oficiais do tribunal.
*   **Uso Estratégico:** Utilize a função de "Calendário Processual Completo" no início de um caso para ter uma visão macro dos prazos e planejar a estratégia processual com antecedência.
